(function(){'use strict';
/* revendedores-admin.js · Categoría "Revendedores" en Sublichat HQ
   ------------------------------------------------------------------
   Edita precios, vendedores y clientes de TODA la red de revendedores
   sin salir de Sublichat. Habla con /api/revendedores-admin (puente que
   valida el usuario y reenvía al backend en Render). Solo visible para
   el usuario sublicuentas — ver can('revendedores') en index.html.

   Reusa las clases .cr-* de catalogo-relojes-admin.css (ya cargado en
   la página) para no repetir estilos. */

const API='/api/revendedores-admin';
const TARIFA_ESPECIAL='propietarios_2026';
const state={tab:'precios',tarifa:'general',precios:null,vendedores:null,clientes:null,recompensas:null,promociones:null,pedidos:null,pedidoFiltro:'todos',clienteQ:'',clienteSel:null,precioQ:'',loading:false};
const $=s=>document.querySelector(s);
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const host=()=>document.getElementById('rbac-revendedores');
const money=v=>v==null?'—':`L${Number(v).toLocaleString('es-HN')}`;

const fmtDate=v=>{if(!v)return'Sin vencimiento';const d=new Date(v);return Number.isNaN(d.getTime())?'Sin vencimiento':d.toLocaleString('es-HN',{year:'numeric',month:'short',day:'numeric',hour:'numeric',minute:'2-digit'})};
function promoTextLines(v){const raw=String(v||'').replace(/\r/g,'\n').trim();if(!raw)return[];const byLine=raw.split(/\n+/).map(x=>x.replace(/^[-•*\s]+/,'').trim()).filter(Boolean);if(byLine.length>1)return byLine.slice(0,5);return raw.replace(/\s+/g,' ').split(/(?:\.\s+|!\s+|\?\s+|;\s+)/).map(x=>x.replace(/^[-•*\s]+/,'').trim()).filter(Boolean).slice(0,5)}
function promoPreviewHtml(v){const lines=promoTextLines(v);return lines.length?`<ul class="promo-preview">${lines.map(line=>`<li>${esc(line)}</li>`).join('')}</ul>`:''}
function promoMetaHtml(p){const items=[];if(p.precioNormal)items.push(`🧾 <b>Normal:</b> ${money(p.precioNormal)}`);if(p.precioPromo)items.push(`💰 <b>Socio:</b> ${money(p.precioPromo)}`);if(p.cupos)items.push(`📦 <b>Cupos:</b> ${Number(p.cupos)}`);items.push(`⏳ <b>Vigencia:</b> ${esc(fmtDate(p.vigencia))}`);return `<div class="promo-meta">${items.map(item=>`<span>${item}</span>`).join('')}</div>`}
function promoLocalDateValue(v){if(!v)return'';const d=new Date(v);if(Number.isNaN(d.getTime()))return'';const p=n=>String(n).padStart(2,'0');return `${d.getFullYear()}-${p(d.getMonth()+1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`}
function promoPayloadFromModal(m,imagenData,imagenUrl='',fallbackDestinatarios=[]){const all=[...m.querySelectorAll('[data-pr-dest]')];const destinatarios=all.length?[...m.querySelectorAll('[data-pr-dest]:checked')].map(x=>x.value):[...(fallbackDestinatarios||[])];return {titulo:m.querySelector('#prTitulo').value.trim(),plataforma:m.querySelector('#prPlataforma').value.trim(),precioNormal:Number(m.querySelector('#prNormal').value)||0,precioPromo:Number(m.querySelector('#prPromo').value)||0,cupos:Number(m.querySelector('#prCupos').value)||0,vigencia:m.querySelector('#prVigencia').value?new Date(m.querySelector('#prVigencia').value).toISOString():'',texto:m.querySelector('#prTexto').value.trim(),destinatarios,imagenData,imagenUrl}}

async function api(method,ruta,body,params){
  const qs=new URLSearchParams({ruta,...(params||{}),_ts:String(Date.now())});
  const opts={method,cache:'no-store',headers:{'Content-Type':'application/json','Cache-Control':'no-cache'}};
  if(body!==undefined) opts.body=JSON.stringify(body);
  const r=await fetch(API+'?'+qs.toString(),opts);
  const t=await r.text();
  let d={}; try{d=JSON.parse(t)}catch(_){d={error:t}}
  if(!r.ok){const e=new Error((d&&d.error)||`HTTP ${r.status}`);e.data=d;e.status=r.status;throw e;}
  return d;
}

function shell(){
  const h=host(); if(!h||h.dataset.ready) return; h.dataset.ready='1';
  h.innerHTML=`
    <style>
      #rbac-revendedores .promo-grid{grid-template-columns:repeat(auto-fill,minmax(320px,420px));align-items:start}
      #rbac-revendedores .promo-card{min-width:0}
      #rbac-revendedores .promo-summary{display:grid;grid-template-columns:112px minmax(0,1fr);gap:12px;align-items:start}
      #rbac-revendedores .promo-thumb{display:block;width:112px;height:112px;object-fit:contain;background:#f7f7f8;border:1px solid #ececf0;border-radius:14px}
      #rbac-revendedores .promo-copy{min-width:0;display:grid;gap:9px}
      #rbac-revendedores .promo-copy p{margin:0;overflow-wrap:anywhere}
      #rbac-revendedores .promo-platform{font-weight:800;color:#182230}
      #rbac-revendedores .promo-meta{display:grid;gap:6px}
      #rbac-revendedores .promo-meta span{display:block;padding:8px 10px;border-radius:11px;background:#f8fafc;color:#344054;font-size:13px;line-height:1.35;overflow-wrap:anywhere}
      #rbac-revendedores .promo-preview{margin:0;padding-left:18px;display:grid;gap:4px;color:#475467;font-size:13px;line-height:1.45}
      #rbac-revendedores .promo-preview li{margin:0}
      #rbac-revendedores .promo-preview-title{font-size:12px;color:#667085;font-weight:700;letter-spacing:.02em;text-transform:uppercase}
      #rbac-revendedores .promo-template-note{grid-column:1/-1;padding:12px 14px;border:1px solid #d9e2f2;background:#f8fbff;border-radius:14px;color:#344054;font-size:13px;line-height:1.45}
      #rbac-revendedores .promo-template-note b{display:block;color:#101828;margin-bottom:3px}
      #rbac-revendedores .promo-live{grid-column:1/-1;border:1px solid #e4e7ec;background:#fff;border-radius:16px;padding:14px;display:grid;gap:8px}
      #rbac-revendedores .promo-live-head{display:flex;align-items:center;justify-content:space-between;gap:10px}
      #rbac-revendedores .promo-live-box{background:#1f2937;color:#fff;border-radius:14px;padding:14px;font-size:13px;line-height:1.5;white-space:pre-wrap;overflow-wrap:anywhere}
      #rbac-revendedores .promo-existing-image{display:flex;gap:10px;align-items:center;margin-top:8px}
      #rbac-revendedores .promo-existing-image img{width:76px;height:76px;object-fit:contain;border:1px solid #e4e7ec;border-radius:12px;background:#f8fafc}
      #rbac-revendedores .order-grid{display:grid;gap:12px}
      #rbac-revendedores .order-card{border-left:4px solid #d92d20}
      #rbac-revendedores .order-card[data-status="entregado"]{border-left-color:#12b76a}
      #rbac-revendedores .order-card[data-status="en proceso"]{border-left-color:#2e90fa}
      #rbac-revendedores .order-card[data-status="pago confirmado"]{border-left-color:#17A052}
      #rbac-revendedores .order-card[data-status="falta información"]{border-left-color:#f79009}
      #rbac-revendedores .order-card[data-status="cancelado"]{border-left-color:#667085}
      #rbac-revendedores .order-metrics{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px;margin:10px 0}
      #rbac-revendedores .order-metric{padding:9px 10px;border-radius:11px;background:#f8fafc;font-size:12px;color:#475467}
      #rbac-revendedores .order-metric b{display:block;color:#101828;font-size:14px}
      #rbac-revendedores .order-status-tools{display:grid;grid-template-columns:minmax(150px,210px) minmax(180px,1fr) auto;gap:8px;align-items:end}
      #rbac-revendedores .perm-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:7px 12px;padding:10px;border:1px solid #e4e7ec;border-radius:12px;background:#f9fafb}
      #rbac-revendedores .stock-row{display:grid;grid-template-columns:1fr 1fr;gap:8px}
      #rbac-revendedores .price-toolbar{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin:0 0 14px}
      #rbac-revendedores .price-search{flex:1;min-width:240px;display:flex;align-items:center;gap:8px;border:1px solid #dce4ee;background:#fff;border-radius:14px;padding:0 12px}
      #rbac-revendedores .price-search input{width:100%;border:0;outline:0;background:transparent;padding:11px 0;font:inherit;color:#15264a}
      #rbac-revendedores .price-catalog-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;align-items:start}
      #rbac-revendedores .price-compact-card{background:#fff;border:1px solid #dfe7f1;border-radius:18px;padding:14px;box-shadow:0 5px 14px rgba(15,35,70,.07);min-width:0}
      #rbac-revendedores .price-summary{display:grid;grid-template-columns:44px minmax(0,1fr) auto;gap:11px;align-items:center}
      #rbac-revendedores .price-icon{width:44px;height:44px;display:grid;place-items:center;border-radius:14px;background:#f3f7fb;font-size:22px;border:1px solid #e2eaf3}
      #rbac-revendedores .price-title{min-width:0}#rbac-revendedores .price-title h3{margin:0!important;font-size:15px!important;line-height:1.15;color:#16345f}#rbac-revendedores .price-title small{display:block;margin-top:4px;color:#71839a;font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      #rbac-revendedores .price-amount{font-weight:950;color:#15915a;background:#edfbf4;border-radius:12px;padding:8px 10px;white-space:nowrap;font-size:13px}
      #rbac-revendedores .price-tags{display:flex;gap:6px;flex-wrap:wrap;margin:11px 0 8px}.price-tags span{display:inline-flex;align-items:center;gap:4px;padding:5px 8px;border-radius:999px;background:#f5f8fc;border:1px solid #e6edf5;color:#52677f;font-size:10.5px;font-weight:850}.price-tags span.on{background:#eefbf4;color:#148557;border-color:#d7f3e4}.price-tags span.off{background:#fff4f3;color:#c3362d;border-color:#f3d3cf}
      #rbac-revendedores .price-detail-preview{display:flex;gap:6px;flex-wrap:wrap;min-height:29px}.price-detail-preview span{display:inline-flex;align-items:center;max-width:100%;padding:6px 8px;border-radius:9px;background:#f8fafc;color:#4f647b;font-size:10.5px;font-weight:750;line-height:1.25}
      #rbac-revendedores .price-card-actions{display:flex;justify-content:flex-end;gap:7px;margin-top:11px;padding-top:10px;border-top:1px solid #edf1f6}
      #rbac-revendedores .price-editor{display:none;margin-top:12px;padding-top:12px;border-top:1px solid #e5ebf3}#rbac-revendedores .price-editor.open{display:block}#rbac-revendedores .price-editor-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px}#rbac-revendedores .price-editor-grid .wide{grid-column:1/-1}
      #rbac-revendedores .detail-preset-row{display:flex;gap:6px;flex-wrap:wrap;margin:7px 0}.detail-preset-row button{border:1px solid #dbe5ef;background:#fff;border-radius:999px;padding:6px 9px;font:inherit;font-size:10px;font-weight:850;color:#425a73;cursor:pointer}.detail-preset-row button:hover{border-color:#e2231a;color:#c82018;background:#fff6f5}
      #rbac-revendedores .price-helper{display:block;color:#8493a6;font-size:10px;line-height:1.35;margin-top:4px}
      @media(max-width:600px){
        #rbac-revendedores .promo-grid{grid-template-columns:1fr}
        #rbac-revendedores .promo-summary{grid-template-columns:88px minmax(0,1fr)}
        #rbac-revendedores .promo-thumb{width:88px;height:88px}
        #rbac-revendedores .order-metrics,#rbac-revendedores .stock-row,#rbac-revendedores .perm-grid,#rbac-revendedores .price-catalog-grid,#rbac-revendedores .price-editor-grid{grid-template-columns:1fr}
        #rbac-revendedores .order-status-tools{grid-template-columns:1fr}
      }
      /* Editor de promociones: el modal vive fuera de #rbac-revendedores, por eso
         estos estilos son globales y no heredan el prefijo del módulo. */
      .promo-editor-modal{align-items:center!important;justify-content:center!important;padding:18px!important;overflow:hidden!important}
      .promo-editor-modal .cr-sheet.promo-editor-sheet{width:min(1180px,calc(100vw - 36px))!important;max-width:1180px!important;height:min(860px,calc(100dvh - 36px))!important;max-height:calc(100dvh - 36px)!important;padding:0!important;overflow:hidden!important;border-radius:24px!important;background:#f8fafc!important;box-shadow:0 30px 80px rgba(15,23,42,.28)!important;display:grid!important;grid-template-rows:auto minmax(0,1fr) auto!important}
      .promo-editor-modal .promo-editor-head{display:flex;align-items:center;justify-content:space-between;gap:18px;padding:18px 22px;background:#fff;border-bottom:1px solid #e7ebf1}
      .promo-editor-modal .promo-editor-title{min-width:0}
      .promo-editor-modal .promo-editor-kicker{display:block;margin-bottom:3px;color:#e2231a;font-size:10px;font-weight:950;letter-spacing:.11em;text-transform:uppercase}
      .promo-editor-modal .promo-editor-head h2{margin:0!important;color:#15264a;font-size:22px;line-height:1.1}
      .promo-editor-modal .promo-editor-head p{margin:5px 0 0;color:#667085;font-size:12px;line-height:1.35}
      .promo-editor-modal .promo-editor-close{width:40px;height:40px;flex:none;border:1px solid #dce3ec;border-radius:13px;background:#fff;color:#475467;font:900 20px/1 Arial;cursor:pointer;box-shadow:0 4px 14px rgba(15,23,42,.07)}
      .promo-editor-modal .promo-editor-close:hover{border-color:#e2231a;color:#e2231a}
      .promo-editor-modal .promo-editor-body{min-height:0;display:grid;grid-template-columns:minmax(0,1.08fr) minmax(360px,.92fr);overflow:hidden}
      .promo-editor-modal .promo-editor-formpane{min-width:0;overflow:auto;padding:20px 22px 26px;background:#fff;scrollbar-gutter:stable}
      .promo-editor-modal .promo-editor-formpane .cr-form{gap:12px}
      .promo-editor-modal .promo-template-note{grid-column:1/-1;padding:12px 14px;border:1px solid #dbe5f3;background:#f7fbff;border-radius:14px;color:#475467;font-size:12px;line-height:1.45}
      .promo-editor-modal .promo-template-note b{display:block;color:#15264a;margin-bottom:3px}
      .promo-editor-modal .promo-template-library{grid-column:1/-1;padding:13px;border:1px solid #e6eaf0;background:#fff;border-radius:16px;box-shadow:0 4px 16px rgba(15,23,42,.04)}
      .promo-editor-modal .promo-template-library-head{display:flex;align-items:flex-start;justify-content:space-between;gap:10px;margin-bottom:9px}
      .promo-editor-modal .promo-template-library-head b{color:#15264a;font-size:13px}
      .promo-editor-modal .promo-template-library-head small{display:block;margin-top:2px;color:#7b8798;font-size:10px;font-weight:700}
      .promo-editor-modal .promo-template-chips{display:flex;gap:7px;flex-wrap:wrap}
      .promo-editor-modal .promo-template-chip{border:1px solid #dbe2eb;border-radius:999px;background:#fff;color:#344054;padding:7px 10px;font-family:inherit;font-size:11px;font-weight:850;line-height:1.1;cursor:pointer;transition:.16s ease}
      .promo-editor-modal .promo-template-chip:hover,.promo-editor-modal .promo-template-chip.on{border-color:#e2231a;background:#fff5f4;color:#c81f17;transform:translateY(-1px)}
      .promo-editor-modal .cr-field{font-size:11px;font-weight:900;color:#475467}
      .promo-editor-modal .cr-field input,.promo-editor-modal .cr-field select,.promo-editor-modal .cr-field textarea{box-sizing:border-box;width:100%;border:1px solid #d9e0e9;border-radius:12px;background:#fff;color:#15264a;padding:10px 11px;font:inherit;outline:none}
      .promo-editor-modal .cr-field input:focus,.promo-editor-modal .cr-field textarea:focus{border-color:#9bb8dc;box-shadow:0 0 0 3px rgba(32,113,196,.08)}
      .promo-editor-modal .cr-field textarea{min-height:118px;resize:vertical;line-height:1.45}
      .promo-editor-modal .cr-field small{color:#8491a3;font-size:9.5px;line-height:1.35;font-weight:700}
      .promo-editor-modal .promo-existing-image{display:flex;gap:10px;align-items:center;margin-top:8px}
      .promo-editor-modal .promo-existing-image img{width:64px;height:64px;object-fit:contain;border:1px solid #e4e7ec;border-radius:12px;background:#f8fafc}
      .promo-editor-modal .promo-dest-box{display:grid;grid-template-columns:repeat(auto-fit,minmax(145px,1fr));gap:7px;margin-top:8px}
      .promo-editor-modal .promo-preview-pane{min-width:0;overflow:auto;padding:20px;background:#eef3f8;border-left:1px solid #dde5ef;scrollbar-gutter:stable}
      .promo-editor-modal .promo-preview-head{display:flex;align-items:flex-start;justify-content:space-between;gap:10px;margin-bottom:12px}
      .promo-editor-modal .promo-preview-head b{display:block;color:#15264a;font-size:14px}
      .promo-editor-modal .promo-preview-head small{display:block;color:#7c8a9b;font-size:10px;margin-top:2px}
      .promo-editor-modal .promo-preview-tabs{display:flex;gap:5px;padding:4px;background:#e2e9f1;border-radius:12px}
      .promo-editor-modal .promo-preview-tab{border:0;border-radius:9px;background:transparent;color:#667085;padding:7px 9px;font-family:inherit;font-size:10px;font-weight:900;line-height:1;cursor:pointer}
      .promo-editor-modal .promo-preview-tab.on{background:#fff;color:#15264a;box-shadow:0 2px 8px rgba(15,23,42,.08)}
      .promo-editor-modal .promo-preview-canvas{display:grid;place-items:start center}
      .promo-editor-modal .promo-panel-mock{width:min(100%,390px);background:#fff;border:1px solid #e0e6ee;border-radius:20px;overflow:hidden;box-shadow:0 14px 32px rgba(15,23,42,.12)}
      .promo-editor-modal .promo-panel-media{aspect-ratio:1/1;background:linear-gradient(135deg,#f7f8fb,#e9eef5);display:grid;place-items:center;overflow:hidden;color:#8b98aa;font-size:11px;font-weight:850}
      .promo-editor-modal .promo-panel-media img{width:100%;height:100%;object-fit:contain;display:block}
      .promo-editor-modal .promo-panel-content{padding:15px;display:grid;gap:8px}
      .promo-editor-modal .promo-panel-title{display:flex;justify-content:space-between;gap:8px;align-items:flex-start}
      .promo-editor-modal .promo-panel-title h3{margin:0;color:#15264a;font-size:17px;line-height:1.18}
      .promo-editor-modal .promo-panel-badge{flex:none;border-radius:999px;background:#ecfdf3;color:#067647;padding:5px 7px;font-size:9px;font-weight:950}
      .promo-editor-modal .promo-panel-platform{color:#475467;font-size:11px;font-weight:900}
      .promo-editor-modal .promo-panel-meta{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:6px}
      .promo-editor-modal .promo-panel-meta span{padding:8px 9px;border-radius:10px;background:#f6f8fb;color:#475467;font-size:10px;line-height:1.3}
      .promo-editor-modal .promo-panel-benefits{margin:0;padding-left:18px;color:#667085;font-size:10.5px;line-height:1.45;display:grid;gap:3px}
      .promo-editor-modal .promo-telegram-mock{width:min(100%,390px);padding:15px;border-radius:20px;background:#dfe9ef;box-shadow:inset 0 0 0 1px rgba(21,38,74,.05)}
      .promo-editor-modal .promo-tg-bubble{overflow:hidden;border-radius:16px 16px 16px 5px;background:#fff;box-shadow:0 8px 24px rgba(15,23,42,.10)}
      .promo-editor-modal .promo-tg-media{aspect-ratio:1/1;background:#edf2f7;display:grid;place-items:center;color:#8b98aa;font-size:11px;font-weight:850;overflow:hidden}
      .promo-editor-modal .promo-tg-media img{width:100%;height:100%;object-fit:contain;display:block}
      .promo-editor-modal .promo-live-box{padding:13px 14px!important;background:#fff!important;color:#253858!important;border-radius:0!important;font:500 12px/1.48 Arial,sans-serif!important;white-space:pre-wrap;overflow-wrap:anywhere}
      .promo-editor-modal [data-promo-preview-view][hidden]{display:none!important}
      .promo-editor-modal .promo-preview-foot{margin-top:10px;padding:9px 10px;border-radius:11px;background:#fff;color:#758397;font-size:9.5px;line-height:1.35;border:1px solid #e1e7ee}
      .promo-editor-modal .promo-editor-actions{margin:0!important;padding:12px 18px!important;background:#fff!important;border-top:1px solid #e2e8f0;display:flex;justify-content:flex-end;gap:8px;align-items:center;position:static!important}
      .promo-editor-modal .promo-editor-actions .promo-action-note{margin-right:auto;color:#7d8a9a;font-size:10px;font-weight:750}
      @media(max-width:900px){
        .promo-editor-modal{padding:8px!important;align-items:flex-start!important;overflow:auto!important}
        .promo-editor-modal .cr-sheet.promo-editor-sheet{width:100%!important;max-width:none!important;height:auto!important;min-height:calc(100dvh - 16px)!important;max-height:none!important;overflow:visible!important;border-radius:18px!important;display:block!important}
        .promo-editor-modal .promo-editor-body{display:block;overflow:visible}
        .promo-editor-modal .promo-editor-formpane,.promo-editor-modal .promo-preview-pane{overflow:visible}
        .promo-editor-modal .promo-preview-pane{border-left:0;border-top:1px solid #dde5ef}
        .promo-editor-modal .promo-editor-actions{position:sticky!important;bottom:0!important;z-index:10}
      }
      @media(max-width:600px){
        .promo-editor-modal .promo-editor-head{padding:14px}
        .promo-editor-modal .promo-editor-head h2{font-size:19px}
        .promo-editor-modal .promo-editor-formpane,.promo-editor-modal .promo-preview-pane{padding:14px}
        .promo-editor-modal .promo-template-library-head,.promo-editor-modal .promo-preview-head{display:block}
        .promo-editor-modal .promo-preview-tabs{margin-top:8px;width:max-content}
        .promo-editor-modal .promo-panel-meta{grid-template-columns:1fr}
        .promo-editor-modal .promo-editor-actions{padding:10px!important}
        .promo-editor-modal .promo-editor-actions .promo-action-note{display:none}
        .promo-editor-modal .promo-editor-actions .cr-btn{flex:1}
      }
    </style>
    <div class="cr-admin">
      <div class="cr-hero">
        <div><b>🤝 Catálogo Socios</b><span>Precios, vendedores y clientes de toda la red — conectado al Panel de Socios.</span></div>
      </div>
      <div class="cr-tabs">
        <button class="cr-tab on" data-rtab="precios">Precios</button>
        <button class="cr-tab" data-rtab="vendedores">Vendedores</button>
        <button class="cr-tab" data-rtab="clientes">Clientes</button>
        <button class="cr-tab" data-rtab="pedidos">🛒 Pedidos</button>
        <button class="cr-tab" data-rtab="buzon">💬 Buzón socios</button>
        <button class="cr-tab" data-rtab="historial">🗂️ Entregas antiguas</button>
        <button class="cr-tab" data-rtab="promociones">🔥 Promociones</button>
        <button class="cr-tab" data-rtab="recompensas">Recompensas</button>
        <button class="cr-tab" data-rtab="publico">🏷️ Precios para Revendedores</button>
      </div>
      <div id="revBody"></div>
    </div>`;
  h.querySelectorAll('[data-rtab]').forEach(b=>b.onclick=()=>{
    state.tab=b.dataset.rtab;
    h.querySelectorAll('[data-rtab]').forEach(x=>x.classList.toggle('on',x===b));
    render();
  });
}

function status(msg,cls){
  const b=$('#revBody');
  if(b) b.insertAdjacentHTML('afterbegin',`<div class="cr-status ${cls||''}" style="margin-bottom:8px">${esc(msg)}</div>`);
}

function render(){
  ({precios:renderPrecios,vendedores:renderVendedores,clientes:renderClientes,pedidos:renderPedidos,buzon:renderBuzon,historial:renderHistorial,promociones:renderPromociones,recompensas:renderRecompensas,publico:renderPublico}[state.tab]||renderPrecios)();
}

/* ═══════════ PEDIDOS DE SOCIOS ═══════════ */
async function loadPedidos(force){
  if(state.pedidos&&!force)return renderPedidos();
  const b=$('#revBody');if(b)b.innerHTML='<div class="cr-empty">Cargando pedidos…</div>';
  try{const d=await api('GET','compras',undefined,{limit:240});state.pedidos=Array.isArray(d)?d:(d.compras||d.items||[]);renderPedidos()}
  catch(e){if(b)b.innerHTML=`<div class="cr-empty">${esc(e.message)}</div>`}
}
function pedidoEstado(v){const s=String(v||'pendiente').trim().toLowerCase();return ['pendiente','pago confirmado','en proceso','falta información','entregado','cancelado'].includes(s)?s:'pendiente'} /* R203 · «pago confirmado» suma SubliPoints */
function pedidoFecha(v){if(!v)return'—';const d=new Date(typeof v==='number'?v:v._seconds?v._seconds*1000:v.seconds?v.seconds*1000:v);return Number.isNaN(d.getTime())?'—':d.toLocaleString('es-HN',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'})}
function pedidoCard(p){
  const estado=pedidoEstado(p.estado),costo=Number(p.monto)||0;
  const productos=Array.isArray(p.productos)&&p.productos.length?p.productos.map(x=>x.servicio||x.nombre).filter(Boolean).join(' + '):(p.servicio||'Pedido');
  const flujo=entregaCanalLabel(p.entregaCanal||(Array.isArray(p.productos)&&p.productos[0]?.entregaCanal)||'manual');
  return `<article class="cr-card order-card" data-status="${esc(estado)}">
    <div class="cr-row"><h3>🛒 ${esc(productos)}</h3><span class="cr-badge ${estado==='entregado'?'':estado==='cancelado'?'paused':''}">${esc(estado)}</span></div>
    <small>Socio: <b>${esc(p.socio||p.socio_norm||'—')}</b> · ${esc(p.destinoLabel||p.destino||'')} · 🚚 ${esc(flujo)} · ${esc(pedidoFecha(p.ts||p.createdAt))} · Ref ${esc(String(p.id||'').slice(-6))}</small>
    <div class="order-metrics"><div class="order-metric">Pagado a Sublicuentas<b>${money(costo)}</b></div>${p.clientePrincipal?`<div class="order-metric">Cliente principal<b>${esc(`${p.clientePrincipal.nombre||''} ${p.clientePrincipal.apellido||''}`.trim())}</b></div>`:''}</div>
    ${Array.isArray(p.productos)&&p.productos.some(x=>x.clienteNombre||x.dispositivo||x.correo||x.notas||x.detalleServicio)?`<ol class="order-lines" style="margin:0 0 10px;padding-left:18px;font-size:13px;line-height:1.45">${p.productos.map(x=>`<li><b>${esc(x.servicio||'')}</b>${(x.cantidad||1)>1?` ×${x.cantidad}`:''} — para ${esc(x.clienteNombre||x.perfil||'—')}${x.destinatario?.tipo==='otro'?' (otro cliente)':''}${[x.perfil&&x.perfil!==x.clienteNombre?`perfil ${x.perfil}`:'',x.dispositivo,x.marcaTv,x.correo,x.detalleServicio?`${x.datoRequerido||'detalle'}: ${x.detalleServicio}`:'',x.notas?`nota: ${x.notas}`:''].filter(Boolean).map(v=>' · '+esc(v)).join('')}</li>`).join('')}</ol>`:''}
    ${p.detalleEstado?`<div class="cr-status" style="margin:0 0 10px">${esc(p.detalleEstado)}</div>`:''}
    ${p.pagoRevision?`<div class="cr-status bad" style="margin:0 0 10px">⚠️ Posible comprobante repetido (igual al pedido #${esc(p.pagoRevision.pedidoRelacionadoRef||'')}). Revise antes de aprobar.</div>`:''}${p.historicoAnterior?`<div class="cr-status" style="margin:0 0 10px">Histórico anterior: este pedido mezclaba clientes (se conserva tal cual).</div>`:''}
    <div class="order-status-tools">
      <label class="cr-field">Estado<select id="pedidoEstado-${esc(p.id)}"><option value="pendiente" ${estado==='pendiente'?'selected':''}>Pendiente</option><option value="pago confirmado" ${estado==='pago confirmado'?'selected':''}>Pago confirmado (suma SubliPoints)</option><option value="en proceso" ${estado==='en proceso'?'selected':''}>En proceso</option><option value="falta información" ${estado==='falta información'?'selected':''}>Falta información</option><option value="entregado" ${estado==='entregado'?'selected':''}>Entregado</option><option value="cancelado" ${estado==='cancelado'?'selected':''}>Cancelado</option></select></label>
      <label class="cr-field">Mensaje al socio<input id="pedidoDetalle-${esc(p.id)}" maxlength="300" value="${esc(p.detalleEstado||'')}" placeholder="Ej. Listo, revise su correo"></label>
      <button class="cr-btn red" data-pedido-save="${esc(p.id)}">Actualizar</button>
      <button class="cr-btn" data-pedido-entregas="${esc(p.id)}">📦 Entregas${p.entregaResumen&&p.entregaResumen.publicados?` · ${p.entregaResumen.publicados}/${p.entregaResumen.requeridos}`:''}</button>
    </div>
  </article>`;
}
function renderPedidos(){
  const b=$('#revBody');if(!state.pedidos)return loadPedidos();
  const counts={};state.pedidos.forEach(p=>{const e=pedidoEstado(p.estado);counts[e]=(counts[e]||0)+1});
  const filtros=[['todos','Todos'],['pendiente','Pendientes'],['pago confirmado','Pago confirmado'],['en proceso','En proceso'],['falta información','Falta información'],['entregado','Entregados'],['cancelado','Cancelados']];
  const list=state.pedidoFiltro==='todos'?state.pedidos:state.pedidos.filter(p=>pedidoEstado(p.estado)===state.pedidoFiltro);
  b.innerHTML=`<div class="cr-tools" style="flex-wrap:wrap"><div><b>Seguimiento de pedidos</b><br><small>Cambie el estado aquí. El socio lo ve en su panel y recibe aviso en Buzón/Telegram.</small></div><button class="cr-btn ghost" id="pedidoReload">Actualizar</button></div>
    <div class="cr-tabs" style="margin-bottom:12px;overflow:auto">${filtros.map(([k,l])=>`<button class="cr-tab ${state.pedidoFiltro===k?'on':''}" data-pedido-filter="${k}">${l}${k==='todos'?` · ${state.pedidos.length}`:counts[k]?` · ${counts[k]}`:''}</button>`).join('')}</div>
    <div class="order-grid">${list.map(pedidoCard).join('')||'<div class="cr-empty">No hay pedidos en este filtro.</div>'}</div>`;
  $('#pedidoReload').onclick=()=>loadPedidos(true);
  b.querySelectorAll('[data-pedido-filter]').forEach(x=>x.onclick=()=>{state.pedidoFiltro=x.dataset.pedidoFilter;renderPedidos()});
  b.querySelectorAll('[data-pedido-save]').forEach(x=>x.onclick=()=>guardarEstadoPedido(x.dataset.pedidoSave,x));
  b.querySelectorAll('[data-pedido-entregas]').forEach(x=>x.onclick=()=>abrirEntregas(x.dataset.pedidoEntregas));
}
async function guardarEstadoPedido(id,btn){
  const estado=$('#pedidoEstado-'+id)?.value||'pendiente',detalle=$('#pedidoDetalle-'+id)?.value.trim()||'';
  const old=btn.textContent;btn.disabled=true;btn.textContent='Guardando…';
  try{const r=await api('PATCH',`compras/${id}/estado`,{estado,detalle});const sp=r&&r.sublipoints;const spTxt=!sp?'':sp.duplicado?' SubliPoints: ya se habían sumado antes (no se duplican).':sp.omitido==='antes_del_inicio'?' SubliPoints: pedido anterior al inicio del programa, no suma.':sp.puntos>0?` SubliPoints: +${sp.puntos} al socio.`:sp.puntos<0?` SubliPoints: ${sp.puntos} (anulado).`:'';status('✅ Estado actualizado y socio notificado.'+spTxt,'good');await loadPedidos(true)}
  catch(e){status(e.message,'bad');btn.disabled=false;btn.textContent=old}
}

/* ═══════════ PROMOCIONES PARA SOCIOS ═══════════ */
async function loadPromociones(force){
  if(state.promociones&&!force)return renderPromociones();
  const b=$('#revBody');if(b)b.innerHTML='<div class="cr-empty">Cargando promociones…</div>';
  try{const d=await api('GET','promociones');state.promociones=d.promociones||[];renderPromociones()}catch(e){if(b)b.innerHTML=`<div class="cr-empty">${esc(e.message)}</div>`}
}
function promoStatus(p){return p.estado==='publicada'?`Enviada a ${Number(p.enviados)||0}`:'Borrador'}
function renderPromociones(){
  const b=$('#revBody');if(!state.promociones)return loadPromociones();
  b.innerHTML=`<div class="cr-tools"><div><b>Campañas para revendedores</b><br><small>La misma promoción aparecerá en el Panel de Socios y puede enviarse con imagen por Telegram.</small></div><button class="cr-btn red" id="promoNueva">＋ Nueva promoción</button></div>
    <div class="cr-grid promo-grid">${state.promociones.map(p=>`<article class="cr-card promo-card"><div class="promo-summary">${p.imagenUrl?`<a href="${esc(p.imagenUrl)}" target="_blank" rel="noopener" title="Abrir imagen completa"><img class="promo-thumb" src="${esc(p.imagenUrl)}" alt="Imagen de ${esc(p.titulo)}"></a>`:'<div class="promo-thumb" aria-hidden="true"></div>'}<div class="promo-copy"><div class="cr-row"><h3>🔥 ${esc(p.titulo)}</h3><span class="cr-badge ${p.estado==='publicada'?'':'paused'}">${esc(promoStatus(p))}</span></div><div class="promo-platform">🎯 ${esc(p.plataforma)}</div>${promoMetaHtml(p)}${promoTextLines(p.texto).length?`<div class="promo-preview-title">✨ Vista previa del mensaje</div>${promoPreviewHtml(p.texto)}`:''}</div></div><div class="cr-row" style="flex-wrap:wrap"><button class="cr-btn ghost" data-promo-edit="${esc(p.id)}">✏️ Editar</button><button class="cr-btn danger" data-promo-del="${esc(p.id)}">Eliminar</button><button class="cr-btn red" data-promo-send="${esc(p.id)}">${p.estado==='publicada'?'📨 Reenviar Telegram':'🚀 Publicar y enviar'}</button></div>${p.fallidos?`<small style="color:#b42318;display:block">⚠️ ${Number(p.fallidos)} no recibieron Telegram.</small>${Array.isArray(p.erroresTelegram)&&p.erroresTelegram.length?`<div style="margin-top:6px;padding:9px 10px;border-radius:10px;background:#fff3f2;color:#912018;font-size:12px">${p.erroresTelegram.map(e=>`<b>${esc(e.nombre||'Socio')}</b> · TG ${esc(e.telegramId||'—')}<br>${esc(e.motivo||'Error Telegram')}<br><span>${esc(e.diagnostico||'')}</span>`).join('<hr style="border:0;border-top:1px solid #f1c0bc;margin:7px 0">')}</div>`:''}`:''}</article>`).join('')||'<div class="cr-empty">Aún no hay promociones para socios.</div>'}</div>`;
  $('#promoNueva').onclick=nuevaPromocion;
  b.querySelectorAll('[data-promo-edit]').forEach(x=>x.onclick=()=>editarPromocion(x.dataset.promoEdit));
  b.querySelectorAll('[data-promo-send]').forEach(x=>x.onclick=()=>enviarPromocion(x.dataset.promoSend,x));
  b.querySelectorAll('[data-promo-del]').forEach(x=>x.onclick=()=>eliminarPromocion(x.dataset.promoDel));
}

async function imageData(file){
  if(!file)return'';
  if(!/^image\/(jpeg|png|webp)$/i.test(file.type))throw new Error('Use una imagen JPG, PNG o WEBP.');
  const url=URL.createObjectURL(file),img=new Image();
  try{
    await new Promise((resolve,reject)=>{img.onload=resolve;img.onerror=()=>reject(new Error('No se pudo leer la imagen seleccionada.'));img.src=url});
    // Mantener el request muy por debajo del límite de Vercel. Antes una foto
    // podía acercarse a 4.7 MB en base64 y el proxy la rechazaba antes de llegar
    // al Panel de Socios, dejando el botón en “Procesando…”.
    const maxData=1650000;
    let maxSide=1280,quality=.82,data='';
    for(let intento=0;intento<6;intento+=1){
      const scale=Math.min(1,maxSide/Math.max(img.width,img.height));
      const canvas=document.createElement('canvas');
      canvas.width=Math.max(1,Math.round(img.width*scale));canvas.height=Math.max(1,Math.round(img.height*scale));
      const ctx=canvas.getContext('2d');if(!ctx)throw new Error('No se pudo preparar la imagen.');
      ctx.drawImage(img,0,0,canvas.width,canvas.height);
      data=canvas.toDataURL('image/jpeg',quality);
      if(data.length<=maxData)return data;
      maxSide=Math.max(760,Math.round(maxSide*.84));quality=Math.max(.62,quality-.05);
    }
    throw new Error('La imagen sigue demasiado pesada. Use una imagen menor de 5 MB.');
  }finally{URL.revokeObjectURL(url)}
}
const PROMO_APP_TEMPLATES=[
  {id:'netflix',icon:'🎬',name:'Netflix',titulo:'Netflix Premium · Promo para socios',plataforma:'Netflix Premium',texto:'Perfil Premium para 1 pantalla\nSeries, películas y estrenos\nUna opción de alta demanda para su catálogo'},
  {id:'disney',icon:'🏰',name:'Disney+',titulo:'Disney+ Premium · Promo para socios',plataforma:'Disney+ Premium',texto:'Disney, Pixar, Marvel y Star Wars\nPelículas, series y contenido familiar\nPerfil Premium listo para entregar'},
  {id:'max',icon:'🎞️',name:'Max',titulo:'Max · Promo para socios',plataforma:'Max',texto:'Series HBO, Warner Bros. y DC\nPelículas, documentales y estrenos\nExcelente opción para ampliar su catálogo'},
  {id:'prime',icon:'📺',name:'Prime Video',titulo:'Prime Video · Promo para socios',plataforma:'Prime Video',texto:'Series y películas internacionales\nCatálogo variado para toda la familia\nAcceso listo para asignar'},
  {id:'crunchyroll',icon:'🍥',name:'Crunchyroll',titulo:'Crunchyroll · Promo para socios',plataforma:'Crunchyroll',texto:'Anime y estrenos de temporada\nAmplio catálogo de series japonesas\nIdeal para clientes fanáticos del anime'},
  {id:'paramount',icon:'⛰️',name:'Paramount+',titulo:'Paramount+ · Promo para socios',plataforma:'Paramount+',texto:'Películas y series de Paramount\nContenido de entretenimiento internacional\nUna alternativa económica para su catálogo'},
  {id:'vix',icon:'⚽',name:'ViX',titulo:'ViX Premium · Promo para socios',plataforma:'ViX Premium',texto:'Series, películas y entretenimiento en español\nDeportes disponibles según el plan vigente\nIdeal para público latino'},
  {id:'canva',icon:'🎨',name:'Canva',titulo:'Canva Pro · Promo para socios',plataforma:'Canva Pro',texto:'Herramientas premium de diseño\nPlantillas y recursos avanzados\nIdeal para emprendedores, negocios y creadores'},
  {id:'duolingo',icon:'🦉',name:'Duolingo',titulo:'Duolingo Super · Promo para socios',plataforma:'Duolingo Super',texto:'Experiencia sin anuncios\nVidas ilimitadas\nAprendizaje de idiomas y otras materias'},
  {id:'gemini',icon:'✨',name:'Gemini',titulo:'Gemini Pro · Promo para socios',plataforma:'Gemini Pro',texto:'IA para productividad y creación de contenido\nApoyo para investigación, redacción e ideas\nIdeal para estudio y trabajo'},
  {id:'youtube',icon:'▶️',name:'YouTube',titulo:'YouTube Premium · Promo para socios',plataforma:'YouTube Premium',texto:'YouTube sin anuncios\nReproducción en segundo plano\nMúsica y video en una sola suscripción'},
  {id:'spotify',icon:'🎧',name:'Spotify',titulo:'Spotify Premium · Promo para socios',plataforma:'Spotify Premium',texto:'Música sin anuncios\nEscuche sus canciones y playlists favoritas\nProducto de alta rotación'},
  {id:'tv',icon:'📡',name:'TV Digital',titulo:'TV Digital · Promo para socios',plataforma:'TV Digital',texto:'Canales, películas y series\nContenido deportivo disponible según servicio\nOpciones para Android TV y dispositivos compatibles'}
];
function promoTemplateChips(){return PROMO_APP_TEMPLATES.map(t=>`<button type="button" class="promo-template-chip" data-promo-template="${esc(t.id)}">${t.icon} ${esc(t.name)}</button>`).join('')}
function promoDestinatariosHtml(selected=[]){
  const activos=(state.vendedores||[]).filter(v=>v.activo!==false);
  const sel=new Set((selected||[]).map(v=>String(v||'').trim().toLowerCase()));
  if(!activos.length)return '<small>No se encontraron socios activos. Si guarda así, se publicará para todos los socios activos.</small>';
  return activos.map(v=>{const value=String(v.nombre_norm||v.id||'');const checked=sel.has(value.toLowerCase())?' checked':'';return `<label class="cr-check"><input type="checkbox" data-pr-dest value="${esc(value)}"${checked}> ${esc(v.nombre||v.nombre_norm||v.id)}</label>`}).join('');
}
function promoPreviewText(m){
  const titulo=m.querySelector('#prTitulo')?.value.trim()||'PROMOCIÓN PARA SOCIOS';
  const plataforma=m.querySelector('#prPlataforma')?.value.trim()||'Plataforma';
  const normal=Number(m.querySelector('#prNormal')?.value)||0,promo=Number(m.querySelector('#prPromo')?.value)||0,cupos=Number(m.querySelector('#prCupos')?.value)||0;
  const vigencia=m.querySelector('#prVigencia')?.value?fmtDate(new Date(m.querySelector('#prVigencia').value).toISOString()):'';
  const lines=[`🔥 ${titulo}`,`🎯 Plataforma: ${plataforma}`,'','💎 Datos de la oferta'];
  if(normal)lines.push(`• 🧾 Precio normal: L${normal}`);if(promo)lines.push(`• 💰 Precio socio: L${promo}`);if(cupos)lines.push(`• 📦 Cupos disponibles: ${cupos}`);if(vigencia)lines.push(`• ⏳ Vigencia: ${vigencia}`);
  const details=promoTextLines(m.querySelector('#prTexto')?.value||'');if(details.length){lines.push('','✨ Detalles');details.forEach(x=>lines.push(`• ${x}`));}
  lines.push('','📲 Cómo solicitar','• Solicítela desde su Panel de Socios.','• Si necesita apoyo, escriba a Sublicuentas.');
  return lines.join('\n');
}
function promoPanelPreviewHtml(m){
  const titulo=m.querySelector('#prTitulo')?.value.trim()||'Título de la promoción';
  const plataforma=m.querySelector('#prPlataforma')?.value.trim()||'Plataforma';
  const normal=Number(m.querySelector('#prNormal')?.value)||0,promo=Number(m.querySelector('#prPromo')?.value)||0,cupos=Number(m.querySelector('#prCupos')?.value)||0;
  const vigencia=m.querySelector('#prVigencia')?.value?fmtDate(new Date(m.querySelector('#prVigencia').value).toISOString()):'Sin vencimiento';
  const details=promoTextLines(m.querySelector('#prTexto')?.value||'');
  const meta=[];if(normal)meta.push(`<span>🧾 <b>Normal:</b><br>${money(normal)}</span>`);if(promo)meta.push(`<span>💰 <b>Socio:</b><br>${money(promo)}</span>`);if(cupos)meta.push(`<span>📦 <b>Cupos:</b><br>${cupos}</span>`);meta.push(`<span>⏳ <b>Vigencia:</b><br>${esc(vigencia)}</span>`);
  return `<div class="promo-panel-content"><div class="promo-panel-title"><h3>🔥 ${esc(titulo)}</h3><span class="promo-panel-badge">PROMO</span></div><div class="promo-panel-platform">🎯 ${esc(plataforma)}</div><div class="promo-panel-meta">${meta.join('')}</div>${details.length?`<ul class="promo-panel-benefits">${details.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>`:'<small style="color:#98a2b3">Escriba los beneficios para verlos aquí.</small>'}</div>`;
}
function promoSetPreviewImage(m,src=''){
  const panel=m.querySelector('#prPanelMedia'),tg=m.querySelector('#prTgMedia');
  const html=src?`<img src="${esc(src)}" alt="Vista previa de la promoción">`:'<span>La imagen promocional aparecerá aquí</span>';
  if(panel)panel.innerHTML=html;if(tg)tg.innerHTML=html;
}
function refreshPromoPreview(m){
  const live=m.querySelector('#prLiveText');if(live)live.textContent=promoPreviewText(m);
  const panel=m.querySelector('#prPanelContent');if(panel)panel.innerHTML=promoPanelPreviewHtml(m);
}
function applyPromoTemplate(m,id){
  const t=PROMO_APP_TEMPLATES.find(x=>x.id===id);if(!t)return;
  const titulo=m.querySelector('#prTitulo'),plataforma=m.querySelector('#prPlataforma'),texto=m.querySelector('#prTexto');
  if(titulo)titulo.value=t.titulo;if(plataforma)plataforma.value=t.plataforma;if(texto)texto.value=t.texto;
  m.querySelectorAll('[data-promo-template]').forEach(x=>x.classList.toggle('on',x.dataset.promoTemplate===id));
  refreshPromoPreview(m);
}
function bindPromoPreviewTabs(m){m.querySelectorAll('[data-promo-view]').forEach(btn=>btn.onclick=()=>{const view=btn.dataset.promoView;m.querySelectorAll('[data-promo-view]').forEach(x=>x.classList.toggle('on',x===btn));m.querySelectorAll('[data-promo-preview-view]').forEach(x=>x.hidden=x.dataset.promoPreviewView!==view)})}
function editarPromocion(id){const p=(state.promociones||[]).find(x=>x.id===id);if(!p)return alert('Promoción no encontrada.');return abrirPromocion(p)}
function nuevaPromocion(){return abrirPromocion(null)}
async function abrirPromocion(p){
  const editing=!!p;
  const m=modal(`<div class="promo-editor-head"><div class="promo-editor-title"><span class="promo-editor-kicker">Catálogo Socios · promociones</span><h2>${editing?'✏️ Editar promoción':'🔥 Nueva promoción para socios'}</h2><p>Prepare una oferta mayorista para sus vendedores y vea cómo quedará antes de publicarla.</p></div><button type="button" class="promo-editor-close" id="prClose" aria-label="Cerrar">×</button></div>
  <div class="promo-editor-body">
    <section class="promo-editor-formpane">
      <div class="cr-form">
        <div class="promo-template-note"><b>💎 Plantilla Premium conectada a Telegram</b>El precio que coloca aquí es su precio para el socio. No controla ni solicita el precio final que el revendedor cobra a su cliente. Al enviar, la misma promoción se publica en el Panel de Socios y Telegram.</div>
        <div class="promo-template-library"><div class="promo-template-library-head"><div><b>⚡ Plantillas rápidas por app</b><small>Rellenan título, plataforma y beneficios. Los precios, cupos y vigencia quedan bajo su control.</small></div></div><div class="promo-template-chips">${promoTemplateChips()}</div></div>
        <label class="cr-field wide">Imagen promocional<input id="prImagen" type="file" accept="image/jpeg,image/png,image/webp"><small>${editing&&p.imagenUrl?'Si no selecciona otra imagen, se conserva la actual.':'Se optimiza automáticamente para el panel y Telegram.'}</small>${editing&&p.imagenUrl?`<div class="promo-existing-image"><img src="${esc(p.imagenUrl)}" alt="Imagen actual"><span>Imagen actual<br><small>Seleccione otra únicamente si desea reemplazarla.</small></span></div>`:''}</label>
        <label class="cr-field wide">Título<input id="prTitulo" maxlength="120" placeholder="Ej. Disney+ Premium · Promo para socios" value="${esc(p?.titulo||'')}"></label>
        <label class="cr-field wide">Plataforma<input id="prPlataforma" maxlength="100" placeholder="Ej. Disney+ Premium" value="${esc(p?.plataforma||'')}"></label>
        <label class="cr-field">Precio normal para socio<input id="prNormal" type="number" min="0" value="${Number(p?.precioNormal)||''}" placeholder="Ej. 100"></label><label class="cr-field">Precio promo para socio<input id="prPromo" type="number" min="0" value="${Number(p?.precioPromo)||''}" placeholder="Ej. 80"></label>
        <label class="cr-field">Cupos<input id="prCupos" type="number" min="0" value="${Number(p?.cupos)||''}" placeholder="Ej. 10"></label>
        <label class="cr-field">Vigente hasta<input id="prVigencia" type="datetime-local" value="${esc(promoLocalDateValue(p?.vigencia))}"></label>
        <label class="cr-field wide">Beneficios / condiciones<textarea id="prTexto" rows="7" maxlength="1200" placeholder="Una ventaja por línea. Ej.:&#10;Perfil Premium para 1 pantalla&#10;Series, películas y estrenos&#10;Disponibilidad limitada">${esc(p?.texto||'')}</textarea><small>Una línea = un punto limpio en Telegram y en el Panel de Socios.</small></label>
        <div class="cr-field wide"><b>Destinatarios</b><small>Si no marca nombres, se enviará a todos los socios activos.</small><div id="prDestinatarios" class="promo-dest-box"><small>Cargando socios…</small></div></div>
        <label class="cr-check wide"><input type="checkbox" id="prEnviar" ${editing?'':'checked'}> ${editing?'Reenviar por Telegram al guardar los cambios':'Publicar en el Panel de Socios y enviar ahora por Telegram'}</label>
        <div id="prEstado" class="cr-field wide" style="min-height:18px"><small></small></div>
      </div>
    </section>
    <aside class="promo-preview-pane">
      <div class="promo-preview-head"><div><b>👁️ Vista previa real</b><small>Cambie entre Panel de Socios y Telegram.</small></div><div class="promo-preview-tabs"><button type="button" class="promo-preview-tab on" data-promo-view="panel">Panel</button><button type="button" class="promo-preview-tab" data-promo-view="telegram">Telegram</button></div></div>
      <div class="promo-preview-canvas" data-promo-preview-view="panel"><article class="promo-panel-mock"><div class="promo-panel-media" id="prPanelMedia"><span>La imagen promocional aparecerá aquí</span></div><div id="prPanelContent"></div></article></div>
      <div class="promo-preview-canvas" data-promo-preview-view="telegram" hidden><div class="promo-telegram-mock"><div class="promo-tg-bubble"><div class="promo-tg-media" id="prTgMedia"><span>La imagen promocional aparecerá aquí</span></div><div class="promo-live-box" id="prLiveText"></div></div></div></div>
      <div class="promo-preview-foot">La vista de Telegram reproduce la estructura real del mensaje. Si tiene Custom Emoji Premium configurados en el bot, Telegram sustituirá algunos iconos automáticamente.</div>
    </aside>
  </div>
  <div class="cr-actions promo-editor-actions"><span class="promo-action-note">Los precios mostrados son exclusivamente precios de Sublicuentas para sus socios.</span><button class="cr-btn ghost" id="prCancel">Cancelar</button><button class="cr-btn red" id="prGuardar">${editing?'Guardar cambios':'Guardar y enviar'}</button></div>`,{className:'promo-editor-modal',sheetClass:'promo-editor-sheet',wide:true});
  const setEstado=(texto,tipo='')=>{const e=m.querySelector('#prEstado small');if(e){e.textContent=texto;e.style.color=tipo==='bad'?'#b42318':tipo==='good'?'#067647':'#667085'}};
  const btn=m.querySelector('#prGuardar'),enviarCheck=m.querySelector('#prEnviar');
  const closePromo=()=>{if(typeof m._modalClose==='function')m._modalClose();else m.remove()};
  m._modalCleanup=()=>{if(m._promoPreviewUrl)URL.revokeObjectURL(m._promoPreviewUrl)};
  m.querySelector('#prCancel').onclick=closePromo;m.querySelector('#prClose').onclick=closePromo;
  enviarCheck.onchange=()=>{btn.textContent=editing?(enviarCheck.checked?'Guardar y reenviar':'Guardar cambios'):(enviarCheck.checked?'Guardar y enviar':'Guardar promoción')};
  ['#prTitulo','#prPlataforma','#prNormal','#prPromo','#prCupos','#prVigencia','#prTexto'].forEach(sel=>{const el=m.querySelector(sel);if(el)el.addEventListener('input',()=>refreshPromoPreview(m))});
  m.querySelectorAll('[data-promo-template]').forEach(x=>x.onclick=()=>applyPromoTemplate(m,x.dataset.promoTemplate));
  bindPromoPreviewTabs(m);
  const imagenInput=m.querySelector('#prImagen');
  imagenInput.addEventListener('change',()=>{const file=imagenInput.files?.[0];if(m._promoPreviewUrl){URL.revokeObjectURL(m._promoPreviewUrl);m._promoPreviewUrl=''}if(file){m._promoPreviewUrl=URL.createObjectURL(file);promoSetPreviewImage(m,m._promoPreviewUrl)}else promoSetPreviewImage(m,p?.imagenUrl||'')});
  promoSetPreviewImage(m,p?.imagenUrl||'');
  refreshPromoPreview(m);

  (async()=>{
    const box=m.querySelector('#prDestinatarios');
    try{
      if(!state.vendedores){const d=await api('GET','revendedores');state.vendedores=Array.isArray(d)?d:(d.revendedores||[])}
      if(box&&m.isConnected)box.innerHTML=promoDestinatariosHtml(p?.destinatarios||[]);
    }catch(e){
      if(box&&m.isConnected)box.innerHTML='<small>No se pudo cargar la lista. Puede guardar sin marcar nombres para enviar a todos los socios activos.</small>';
      setEstado(`Aviso: ${e.message}`,'bad');
    }
  })();

  btn.onclick=async()=>{
    btn.disabled=true;btn.textContent='Preparando…';setEstado('Validando información…');
    try{
      const titulo=m.querySelector('#prTitulo').value.trim(),plataforma=m.querySelector('#prPlataforma').value.trim();
      if(!titulo||!plataforma)throw new Error('Complete título y plataforma.');
      const imagenData=await imageData(m.querySelector('#prImagen').files[0]);
      const payload=promoPayloadFromModal(m,imagenData,p?.imagenUrl||'',p?.destinatarios||[]);
      setEstado(editing?'Guardando cambios…':'Guardando promoción…');btn.textContent='Guardando…';
      let promoId='';
      if(editing){
        await api('PUT',`promociones/${p.id}`,payload);promoId=p.id;setEstado('✅ Cambios guardados.','good');
      }else{
        const d=await api('POST','promociones',payload);promoId=d.id;setEstado('✅ Promoción guardada.','good');
      }
      if(!enviarCheck.checked){closePromo();await loadPromociones(true);return;}
      btn.textContent='Enviando Telegram…';setEstado(editing?'Cambios guardados. Reenviando promoción…':'Promoción guardada. Enviando a Telegram…','good');
      try{
        const sent=await api('POST',`promociones/${promoId}/enviar`,{});
        closePromo();await loadPromociones(true);
        alert(`${editing?'Promoción actualizada y reenviada':'Promoción publicada'}.\nTelegram enviados: ${sent.enviados||0}${sent.encolados?`\nPor bot principal: ${sent.encolados}`:''}\nPendientes/fallidos: ${sent.fallidos||0}${sent.fallbackTexto?`\nEnvíos recuperados como texto: ${sent.fallbackTexto}`:''}${sent.sinTelegram?.length?'\nSin Telegram: '+sent.sinTelegram.join(', '):''}${Array.isArray(sent.erroresTelegram)&&sent.erroresTelegram.length?'\n\nDetalle Telegram:\n'+sent.erroresTelegram.map(e=>`${e.nombre||'Socio'} (${e.telegramId||'sin ID'}): ${e.motivo||'Error'}\n${e.diagnostico||''}`).join('\n\n'):''}`);
      }catch(sendError){
        closePromo();await loadPromociones(true);
        alert(`✅ Los cambios sí quedaron guardados.\n⚠️ No se pudo completar el envío por Telegram: ${sendError.message}\nPuede usar “Reenviar Telegram” para reintentarlo.`);
      }
    }catch(e){
      alert(e.message);setEstado(e.message,'bad');btn.disabled=false;btn.textContent=editing?(enviarCheck.checked?'Guardar y reenviar':'Guardar cambios'):(enviarCheck.checked?'Guardar y enviar':'Guardar promoción');
    }
  };
}
async function enviarPromocion(id,button){if(!confirm('¿Publicar esta promoción en el panel y enviarla por Telegram?'))return;button.disabled=true;try{const d=await api('POST',`promociones/${id}/enviar`,{});alert(`Enviados: ${d.enviados||0}${d.encolados?`\nPor bot principal: ${d.encolados}`:''}\nPendientes/fallidos: ${d.fallidos||0}${d.sinTelegram?.length?'\nSin Telegram: '+d.sinTelegram.join(', '):''}${Array.isArray(d.erroresTelegram)&&d.erroresTelegram.length?'\n\nDetalle Telegram:\n'+d.erroresTelegram.map(e=>`${e.nombre||'Socio'} (${e.telegramId||'sin ID'}): ${e.motivo||'Error'}\n${e.diagnostico||''}`).join('\n\n'):''}`);await loadPromociones(true)}catch(e){alert(e.message);button.disabled=false}}
async function eliminarPromocion(id){if(!confirm('¿Eliminar esta promoción? Dejará de aparecer en el Panel de Socios.'))return;try{await api('DELETE',`promociones/${id}`);await loadPromociones(true)}catch(e){alert(e.message)}}

/* ═══════════ PRECIOS ═══════════ */
async function loadPrecios(force){
  if(state.precios&&!force) return render();
  const b=$('#revBody'); if(b) b.innerHTML='<div class="cr-empty">Cargando precios…</div>';
  try{ const d=await api('GET','precios',undefined,{tarifa:state.tarifa}); state.precios=d.precios||[]; render(); }
  catch(e){ if(b) b.innerHTML=`<div class="cr-empty">${esc(e.message)}</div>`; }
}
function precioSearchText(p){return [p.nombre,p.variante,p.categoria,p.detalle,p.entregaTipo,p.entregaCanal].filter(Boolean).join(' ').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'')}
function filterPrecioCards(value){
  state.precioQ=String(value||'');const q=state.precioQ.trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'');
  document.querySelectorAll('#revBody [data-price-card]').forEach(card=>{card.style.display=!q||String(card.dataset.search||'').includes(q)?'':'none'});
  document.querySelectorAll('#revBody [data-price-group]').forEach(group=>{const visible=[...group.querySelectorAll('[data-price-card]')].some(x=>x.style.display!=='none');group.style.display=visible?'':'none'});
}
function renderPrecios(){
  const b=$('#revBody'); if(!state.precios) return loadPrecios();
  const grupos={};
  const orden=[];
  state.precios.forEach(p=>{
    const k=p.categoria||'Sin categoría';
    if(!grupos[k]){ grupos[k]=[]; orden.push(k); }
    grupos[k].push(p);
  });
  const vacio=!state.precios.length;
  b.innerHTML=`
    <div class="cr-tools" style="flex-wrap:wrap;gap:8px">
      <div style="display:flex;gap:7px;flex-wrap:wrap">
        <button class="cr-btn ${state.tarifa==='general'?'red':'ghost'}" data-tarifa="general">Tarifa general</button>
        <button class="cr-btn ${state.tarifa===TARIFA_ESPECIAL?'red':'ghost'}" data-tarifa="${TARIFA_ESPECIAL}">Sublicuentas · Relojes · Geisell</button>
      </div>
      <button class="cr-btn red" id="revAddPrecio">＋ Ítem nuevo</button>
    </div>
    <div class="price-toolbar"><label class="price-search">🔎 <input id="revPrecioSearch" value="${esc(state.precioQ||'')}" placeholder="Buscar Netflix, Stella, IPTV, Canva…"></label><small>Vista compacta · abra solo el producto que desea editar.</small></div>
    ${state.tarifa===TARIFA_ESPECIAL?`<div class="cr-card" style="margin-bottom:12px"><h3>Actualización de precios y vendedores</h3><small>Corrige Geissel → Geisell, actualiza sus clientes, asigna esta tarifa y crea Sublicuentas 2 con el teléfono 8946-4328.</small><div class="cr-row" style="margin-top:10px"><button class="cr-btn ghost" id="revPreviewActualizacion">Revisar cambios</button><button class="cr-btn red" id="revAplicarActualizacion">Aplicar actualización</button></div></div>`:''}
    ${vacio?`<div class="cr-empty">Catálogo vacío.<br><br>
      <button class="cr-btn red" id="revImportarInicial">📥 ${state.tarifa==='general'?'Importar catálogo inicial':'Cargar tarifa especial'}</button><br><br>
      <small>${state.tarifa==='general'?'Trae el catálogo general del Panel de Socios.':'Carga los 28 precios definidos para Sublicuentas, Relojes y Geisell.'}</small>
    </div>`:''}
    ${orden.map(cat=>`<section data-price-group><div class="cr-section">${esc(cat)} · ${grupos[cat].length}</div><div class="price-catalog-grid">${grupos[cat].map(precioCard).join('')}</div></section>`).join('')}`;
  $('#revAddPrecio').onclick=nuevoPrecio;
  if(vacio) $('#revImportarInicial').onclick=importarPreciosIniciales;
  b.querySelectorAll('[data-tarifa]').forEach(x=>x.onclick=()=>{state.tarifa=x.dataset.tarifa;state.precios=null;state.precioQ='';loadPrecios(true)});
  if($('#revPreviewActualizacion'))$('#revPreviewActualizacion').onclick=previsualizarActualizacion;
  if($('#revAplicarActualizacion'))$('#revAplicarActualizacion').onclick=aplicarActualizacion;
  b.querySelectorAll('[data-save-precio]').forEach(x=>x.onclick=()=>guardarPrecio(x.dataset.savePrecio));
  b.querySelectorAll('[data-del-precio]').forEach(x=>x.onclick=()=>eliminarPrecio(x.dataset.delPrecio));
  b.querySelectorAll('[data-toggle-precio]').forEach(x=>x.onclick=()=>togglePrecioEditor(x.dataset.togglePrecio));
  b.querySelectorAll('[data-detail-preset]').forEach(x=>x.onclick=()=>addDetallePreset(x.dataset.detailTarget,x.dataset.detailPreset));
  const q=$('#revPrecioSearch');if(q){q.oninput=()=>filterPrecioCards(q.value);filterPrecioCards(state.precioQ)}
}
async function importarPreciosIniciales(){
  const btn=$('#revImportarInicial'); if(btn){ btn.disabled=true; btn.textContent='Importando…'; }
  try{
    const ruta=state.tarifa==='general'?'precios/importar-inicial':'precios/importar-especial';
    const d=await api('POST',ruta,undefined,{tarifa:state.tarifa});
    status(state.tarifa==='general'
      ?`✅ Catálogo importado: ${d.creados||0} nuevos, ${d.actualizados||0} actualizados.`
      :`✅ Tarifa especial cargada: ${d.actualizados||0} precios.`, 'good');
    await loadPrecios(true);
  }catch(e){ status(e.message,'bad'); if(btn){ btn.disabled=false; btn.textContent='📥 Importar catálogo inicial'; } }
}
async function previsualizarActualizacion(){
  try{
    const d=await api('GET','actualizaciones/precios-agosto-2026');
    const pendientes=(d.iptvPendientes||[]).reduce((n,x)=>n+Number(x.cantidad||0),0);
    alert(`Se actualizarán ${d.clientesAActualizar||0} clientes y ${d.serviciosConRegla||0} servicios.\nRegistros Geisell encontrados: ${d.registrosGeisellEncontrados||0}.\nIPTV antiguos pendientes de identificar: ${pendientes}.`);
  }catch(e){status(e.message,'bad')}
}
async function aplicarActualizacion(){
  if(!confirm('¿Aplicar los precios especiales, corregir Geisell y crear Sublicuentas 2? Se guardará un respaldo antes de cambiar clientes.'))return;
  const btn=$('#revAplicarActualizacion');if(btn){btn.disabled=true;btn.textContent='Aplicando…'}
  try{
    const d=await api('POST','actualizaciones/precios-agosto-2026',{});
    state.precios=null;state.vendedores=null;
    await loadPrecios(true);
    const pendientes=(d.iptvPendientes||[]).reduce((n,x)=>n+Number(x.cantidad||0),0);
    status(`✅ Actualización completa: ${d.clientesActualizados||0} clientes y ${d.serviciosConRegla||0} servicios revisados.${pendientes?' '+pendientes+' IPTV antiguos quedaron para identificar.':''}`,'good');
    if(d.sublicuentas2Pin)pinModal('Sublicuentas 2',d.sublicuentas2Pin,'Usuario: sublicuentas 2 · WhatsApp: 8946-4328');
  }catch(e){status(e.message,'bad');if(btn){btn.disabled=false;btn.textContent='Aplicar actualización'}}
}
const PRICE_DETAIL_PRESETS=[
  ['👤','Perfil'],['📱','Dispositivo'],['🤖','Bot TG / código'],['🛡️','Garantía'],['📧','Correo y clave'],['🔐','PIN'],['✉️','Invitación correo'],['📡','IPTV'],['🔑','Serial / key'],['⚡','Entrega']
];
// Oct-2026 · Rediseño Panel de Socios: la modalidad la define el catálogo (no el nombre del producto).
const ENTREGA_TIPOS=[['','Sin definir (el panel la adivina por el nombre)'],['perfil','Perfil (nombre del cliente)'],['correo','Invitación por correo'],['cuenta_completa','Cuenta completa'],['tv_digital','TV digital / IPTV'],['serial','Licencia / serial'],['serial_key','Licencia / KEY'],['detalle','Recarga / detalle'],['acceso','Acceso entregado por el equipo']];
const PIDE_DISPOSITIVO=[['auto','Automático (perfil y TV digital sí)'],['si','Sí, pedir dispositivo'],['no','No pedir dispositivo']];
const ENTREGA_CANALES=[['manual','Manual'],['bot_tg','Bot Telegram / código'],['inventario','Inventario Sublichat'],['invitacion','Invitación al correo'],['iptv','TV Digital / IPTV']];
function adminProductIcon(p){const t=(String(p.nombre||'')+' '+String(p.categoria||'')).toLowerCase();if(t.includes('netflix'))return'🍿';if(t.includes('disney'))return'🏰';if(t.includes('max')||t.includes('hbo'))return'🎬';if(t.includes('prime'))return'📦';if(t.includes('crunchy'))return'🍥';if(t.includes('iptv')||t.includes('oleada')||t.includes('stella')||t.includes('nanotech')||t.includes('lion')||t.includes('latin'))return'📡';if(t.includes('spotify')||t.includes('deezer')||t.includes('eleven'))return'🎵';if(t.includes('autocad')||t.includes('autodesk'))return'📐';/* R196u */if(t.includes('canva'))return'🎨';if(t.includes('gemini')||t.includes('chatgpt'))return'🤖';if(t.includes('office'))return'💼';if(t.includes('antivirus')||t.includes('eset')||t.includes('mcafee'))return'🛡️';return'🧩'}
function detalleLineas(raw){return String(raw||'').split(/\r?\n/).map(x=>x.trim()).filter(Boolean)}
function detalleIconLine(line){const x=String(line||'').trim();if(!x)return'';if(/^[\u{1F300}-\u{1FAFF}\u2600-\u27BF]/u.test(x))return x;const t=x.toLowerCase();let i='ℹ️';if(/perfil/.test(t))i='👤';else if(/dispositivo|pantalla|reproduce/.test(t))i='📱';else if(/bot|c[oó]digo/.test(t))i='🤖';else if(/garant|ca[ií]da/.test(t))i='🛡️';else if(/invitaci[oó]n/.test(t))i='✉️';else if(/correo/.test(t))i='📧';else if(/pin/.test(t))i='🔐';else if(/iptv|tv digital|usuario/.test(t))i='📡';else if(/serial|key|licencia/.test(t))i='🔑';else if(/acceso/.test(t))i='🔐';return `${i} ${x}`}
function detallePreview(raw){const ls=detalleLineas(raw);return ls.length?ls.slice(0,4).map(x=>`<span>${esc(detalleIconLine(x))}</span>`).join(''):'<span>➕ Sin detalles configurados</span>'}
function entregaTipoLabel(v){return ({perfil:'Perfil',correo:'Invitación',cuenta_completa:'Cuenta completa',tv_digital:'TV digital',acceso:'Acceso',serial:'Licencia',serial_key:'Licencia / KEY',detalle:'Recarga / detalle'})[v]||'Según producto'}
function entregaCanalLabel(v){return ({manual:'Manual',bot_tg:'Bot TG',inventario:'Inventario',invitacion:'Invitación',iptv:'TV Digital'})[v]||'Manual'}
function selectOptions(rows,value){return rows.map(([v,l])=>`<option value="${esc(v)}" ${String(value||'')===v?'selected':''}>${esc(l)}</option>`).join('')}
function detailPresetButtons(target){return PRICE_DETAIL_PRESETS.map(([ico,label])=>`<button type="button" data-detail-target="${esc(target)}" data-detail-preset="${esc(ico+' '+label+': ')}">${ico} ${esc(label)}</button>`).join('')}
function addDetallePreset(target,text){const ta=document.getElementById(target);if(!ta)return;const current=ta.value.trimEnd();ta.value=(current?current+'\n':'')+String(text||'');ta.focus();ta.setSelectionRange(ta.value.length,ta.value.length)}
function togglePrecioEditor(id,force){const el=document.getElementById('pxEditor-'+id);if(!el)return;const open=force==null?!el.classList.contains('open'):!!force;el.classList.toggle('open',open);const btn=document.querySelector(`[data-toggle-precio="${CSS.escape(id)}"]`);if(btn)btn.textContent=open?'Cerrar':'✏️ Editar'}
function precioCard(p){
  const id=p.id;
  const titulo=p.nombre+(p.variante?' · '+p.variante:'');
  const stock=p.stockModo==='manual'?(p.stockCantidad!=null?`📦 ${Number(p.stockCantidad)} manual`:'📦 Manual'):'🏬 Bodega';
  const activo=p.activo!==false;
  const canal=p.entregaCanal||'manual';
  return `<article class="price-compact-card" data-price-card data-search="${esc(precioSearchText(p))}">
    <div class="price-summary"><span class="price-icon">${adminProductIcon(p)}</span><div class="price-title"><h3>${esc(p.nombre||'Producto')}</h3><small>${esc(p.variante||p.categoria||'Sin variante')}</small></div><div class="price-amount">${p.precio==null?'Comisión':money(p.precio)}</div></div>
    <div class="price-tags"><span class="${activo?'on':'off'}">${activo?'👁 Visible':'🙈 Oculto'}</span><span>${stock}</span><span>🚚 ${esc(entregaCanalLabel(canal))}</span>${p.entregaTipo?`<span>📋 ${esc(entregaTipoLabel(p.entregaTipo))}</span>`:'<span class="off" title="El Panel de Socios adivina los datos por el nombre. Elija la modalidad en Editar.">⚠️ Falta modalidad</span>'}</div>
    <div class="price-detail-preview">${detallePreview(p.detalle)}</div>
    <div class="price-card-actions"><button class="cr-btn ghost" data-toggle-precio="${esc(id)}">✏️ Editar</button><button class="cr-btn danger" data-del-precio="${esc(id)}">Eliminar</button></div>
    <div class="price-editor" id="pxEditor-${esc(id)}"><div class="price-editor-grid">
      <label class="cr-field">Nombre<input id="pxNombre-${esc(id)}" value="${esc(p.nombre||'')}"></label>
      <label class="cr-field">Variante<input id="pxVariante-${esc(id)}" value="${esc(p.variante||'')}" placeholder="Ej. 3 dispositivos"></label>
      <label class="cr-field">Categoría<input id="pxCategoria-${esc(id)}" value="${esc(p.categoria||'')}" placeholder="Ej. 📺 Streaming"></label>
      <label class="cr-field">Precio (L)<input type="number" min="0" step="1" id="pxPrecio-${esc(id)}" value="${p.precio??''}" placeholder="Vacío = Por comisión"></label>
      <label class="cr-field">Datos para procesar<select id="pxEntregaTipo-${esc(id)}">${selectOptions(ENTREGA_TIPOS,p.entregaTipo||'')}</select><small class="price-helper">Evita que el Panel de Socios tenga que adivinar si debe pedir perfil, correo, serial, etc.</small></label>
      <label class="cr-field">Pedir dispositivo<select id="pxPideDispositivo-${esc(id)}">${selectOptions(PIDE_DISPOSITIVO,p.pideDispositivo||'auto')}</select></label>
      <label class="cr-field">Dato que se pide (recargas)<input id="pxDatoRequerido-${esc(id)}" maxlength="60" value="${esc(p.datoRequerido||'')}" placeholder="Ej. ID de jugador"></label>
      <label class="cr-field">Flujo de entrega<select id="pxEntregaCanal-${esc(id)}">${selectOptions(ENTREGA_CANALES,canal)}</select><small class="price-helper">Este dato viaja a Panel de Socios y Bot TG. No envía credenciales automáticamente todavía.</small></label>
      <label class="cr-field wide">Detalles que verá el socio<div class="detail-preset-row">${detailPresetButtons('pxDetalle-'+id)}</div><textarea id="pxDetalle-${esc(id)}" rows="4">${esc(p.detalle||'')}</textarea><small class="price-helper">Use una línea por dato. Los iconos quedan visibles en el catálogo del socio.</small></label>
      <label class="cr-field">Inventario<select id="pxStockModo-${esc(id)}"><option value="auto" ${String(p.stockModo||'auto')==='auto'?'selected':''}>Automático · Bodega</option><option value="manual" ${String(p.stockModo||'auto')==='manual'?'selected':''}>Manual</option></select></label>
      <label class="cr-field">Estado manual<select id="pxStockEstado-${esc(id)}"><option value="" ${!p.stockEstado?'selected':''}>Según cantidad / consultar</option><option value="disponible" ${p.stockEstado==='disponible'?'selected':''}>Disponible</option><option value="bajo" ${p.stockEstado==='bajo'?'selected':''}>Poco inventario</option><option value="agotado" ${p.stockEstado==='agotado'?'selected':''}>Agotado</option><option value="consultar" ${p.stockEstado==='consultar'?'selected':''}>Consultar</option></select></label>
      <label class="cr-field">Cantidad manual<input type="number" min="0" step="1" id="pxStockCantidad-${esc(id)}" value="${p.stockCantidad??''}" placeholder="Opcional"></label>
      <label class="cr-check" style="align-self:end"><input type="checkbox" id="pxActivo-${esc(id)}" ${activo?'checked':''}> Visible para los socios</label>
    </div><div class="cr-row" style="justify-content:flex-end;margin-top:10px"><button class="cr-btn ghost" type="button" onclick="togglePrecioEditor('${esc(id)}',false)">Cancelar</button><button class="cr-btn red" data-save-precio="${esc(id)}">💾 Guardar cambios</button></div></div>
  </article>`;
}
function leerFormPrecio(id){
  const precioRaw=$('#pxPrecio-'+id)?.value;
  return {
    nombre:$('#pxNombre-'+id)?.value.trim()||'',
    variante:$('#pxVariante-'+id)?.value.trim()||'',
    categoria:$('#pxCategoria-'+id)?.value.trim()||'',
    detalle:$('#pxDetalle-'+id)?.value.trim()||'',
    precio:precioRaw===''||precioRaw==null?null:Number(precioRaw),
    entregaTipo:$('#pxEntregaTipo-'+id)?.value||'',
    entregaCanal:$('#pxEntregaCanal-'+id)?.value||'manual',
    pideDispositivo:$('#pxPideDispositivo-'+id)?.value||'auto',
    datoRequerido:$('#pxDatoRequerido-'+id)?.value.trim()||'',
    stockModo:$('#pxStockModo-'+id)?.value||'auto',
    stockEstado:$('#pxStockEstado-'+id)?.value||'',
    stockCantidad:($('#pxStockCantidad-'+id)?.value??'')===''?null:Number($('#pxStockCantidad-'+id)?.value),
    activo:$('#pxActivo-'+id)?.checked!==false,
  };
}
async function guardarPrecio(id){
  const datos=leerFormPrecio(id);
  if(!datos.nombre){ status('Ponele un nombre al ítem.','bad'); return; }
  try{
    const d=await api('PUT','precios/'+id,datos,{tarifa:state.tarifa});
    status(d.sincronizado?'✅ Guardado y sincronizado con el Panel de Socios.':'✅ Guardado.','good');
    await loadPrecios(true);
  }catch(e){ status(e.message,'bad'); }
}
async function eliminarPrecio(id){
  if(!confirm('¿Eliminar este ítem del catálogo? Ya no lo verán los socios.')) return;
  try{ await api('DELETE','precios/'+id,undefined,{tarifa:state.tarifa}); await loadPrecios(true); }
  catch(e){ status(e.message,'bad'); }
}
function nuevoPrecio(){
  const m=modal(`<h2>Nuevo ítem del catálogo</h2>
    <div class="cr-form">
      <label class="cr-field wide">Categoría<input id="npCategoria" placeholder="Ej. 📺 Streaming"></label>
      <label class="cr-field wide">Nombre<input id="npNombre" placeholder="Ej. Netflix"></label>
      <label class="cr-field wide">Variante (opcional)<input id="npVariante" placeholder="Ej. 3 dispositivos"></label>
      <label class="cr-field wide">Precio (L) — vacío = "Por comisión"<input type="number" min="0" id="npPrecio"></label>
      <label class="cr-field wide">Datos para procesar<select id="npEntregaTipo">${selectOptions(ENTREGA_TIPOS,'')}</select></label>
      <label class="cr-field wide">Pedir dispositivo<select id="npPideDispositivo">${selectOptions(PIDE_DISPOSITIVO,'auto')}</select></label>
      <label class="cr-field wide">Dato que se pide (recargas)<input id="npDatoRequerido" maxlength="60" placeholder="Ej. ID de jugador"></label>
      <label class="cr-field wide">Flujo de entrega<select id="npEntregaCanal">${selectOptions(ENTREGA_CANALES,'manual')}</select></label>
      <label class="cr-field wide">Detalles que verá el socio<div class="detail-preset-row">${detailPresetButtons('npDetalle')}</div><textarea id="npDetalle" rows="4"></textarea></label>
      <label class="cr-field wide">Inventario<select id="npStockModo"><option value="auto">Automático · Bodega</option><option value="manual">Manual</option></select></label>
      <label class="cr-field wide">Estado manual<select id="npStockEstado"><option value="">Según cantidad / consultar</option><option value="disponible">Disponible</option><option value="bajo">Poco inventario</option><option value="agotado">Agotado</option><option value="consultar">Consultar</option></select></label>
      <label class="cr-field wide">Cantidad manual (opcional)<input type="number" min="0" id="npStockCantidad"></label>
    </div>
    <div class="cr-actions"><button class="cr-btn ghost" id="npCancel">Cancelar</button><button class="cr-btn red" id="npOk">Crear</button></div>`);
  m.querySelectorAll('[data-detail-preset]').forEach(x=>x.onclick=()=>addDetallePreset(x.dataset.detailTarget,x.dataset.detailPreset));
  $('#npCancel').onclick=()=>m.remove();
  $('#npOk').onclick=async()=>{
    const categoria=$('#npCategoria').value.trim(), nombre=$('#npNombre').value.trim();
    if(!categoria||!nombre){ alert('Completá al menos categoría y nombre.'); return; }
    const precioRaw=$('#npPrecio').value;
    try{
      await api('POST','precios',{
        categoria, nombre,
        variante:$('#npVariante').value.trim(),
        detalle:$('#npDetalle').value.trim(),
        precio:precioRaw===''?null:Number(precioRaw),
        entregaTipo:$('#npEntregaTipo').value||'',entregaCanal:$('#npEntregaCanal').value||'manual',
        pideDispositivo:$('#npPideDispositivo').value||'auto',datoRequerido:$('#npDatoRequerido').value.trim(),
        stockModo:$('#npStockModo').value||'auto',stockEstado:$('#npStockEstado').value||'',
        stockCantidad:$('#npStockCantidad').value===''?null:Number($('#npStockCantidad').value),
        activo:true,tarifaId:state.tarifa,
      },{tarifa:state.tarifa});
      m.remove(); await loadPrecios(true);
    }catch(e){ alert(e.message); }
  };
}

/* ═══════════ VENDEDORES ═══════════ */
async function loadVendedores(force){
  if(state.vendedores&&!force) return render();
  const b=$('#revBody'); if(b) b.innerHTML='<div class="cr-empty">Cargando vendedores…</div>';
  try{
    const d=await api('GET','revendedores');
    state.vendedores=Array.isArray(d)?d:(d.revendedores||[]);
    if(force&&typeof window.sublichatSincronizarVendedores==='function') window.sublichatSincronizarVendedores(true); // número/nombre nuevo de un socio → listas y fichas
    render();
  }catch(e){ if(b) b.innerHTML=`<div class="cr-empty">${esc(e.message)}</div>`; }
}
/* ═══════════ EQUIPO DE VENTAS (registro único · Oct-2026) ═══════════
   Vendedores del equipo (Relojes, Sublicuentas, Yami…): sin acceso al Panel de Socios.
   Lo que se guarde aquí (o en el Bot) sale en Web, APK, Bot, cobros, renovación, fichas y portal del cliente.
   Si cambia el número, las fichas que tenían el número viejo muestran el nuevo. */
async function regApi(body){
  const r=await fetch('/api/mobile-core',{method:'POST',cache:'no-store',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'vendedores',...body})});
  const d=await r.json().catch(()=>({}));
  if(!r.ok||d.ok===false) throw new Error(d.error||`HTTP ${r.status}`);
  return d;
}
async function loadEquipo(force){
  if(state.equipo&&!force) return;
  try{ const d=await regApi({op:'listar'}); state.equipo=(d.sellersDetail||[]).filter(v=>v.tipo==='equipo'); }
  catch(e){ state.equipo=[]; state.equipoError=e.message; }
  if(typeof window.sublichatSincronizarVendedores==='function') window.sublichatSincronizarVendedores(true);
}
function equipoHtml(){
  const lista=state.equipo||[];
  return `<section class="cr-card" style="margin-bottom:14px;background:#fff">
    <div class="cr-row"><h3>🧑‍💼 Equipo de ventas</h3><button class="cr-btn red" id="regAdd">＋ Vendedor del equipo</button></div>
    <small>Se usan en Web, APK y Bot (cobros, renovación, fichas y portal del cliente). Los socios con acceso al Panel están abajo.</small>
    ${state.equipoError?`<div class="cr-empty">${esc(state.equipoError)}</div>`:''}
    <div style="display:flex;flex-direction:column;gap:6px;margin-top:10px">${lista.map(v=>`<div class="cr-row" style="border-top:1px solid #edf1f6;padding-top:6px">
      <span><b>${esc(v.nombre)}</b> · 📱 ${esc(v.telefono||'sin número')}</span>
      <span style="display:flex;gap:6px"><button class="cr-btn ghost" data-reg-edit="${esc(v.nombre)}" data-tel="${esc(v.telefono||'')}">Editar</button><button class="cr-btn danger" data-reg-del="${esc(v.nombre)}">Eliminar</button></span>
    </div>`).join('')||'<div class="cr-empty">Sin vendedores del equipo.</div>'}</div>
  </section>`;
}
function editarEquipo(nombre='',telefono=''){
  const nuevo=!nombre;
  const m=modal(`<h2>${nuevo?'Nuevo vendedor del equipo':'Editar '+esc(nombre)}</h2>
    <div class="cr-form">
      <label class="cr-field wide">Nombre<input id="regNombre" value="${esc(nombre)}" placeholder="Ej. Sublicuentas 1"></label>
      <label class="cr-field wide">WhatsApp<input id="regTel" inputmode="tel" value="${esc(telefono)}" placeholder="Honduras: 2255-4675 · Otro país: +52 55 1234 5678"></label>
      <small>Honduras: 8 dígitos. Otro país: escriba el código (+52, +1, +34…). Vacío = sin número.</small>
    </div>
    <div class="cr-actions"><button class="cr-btn ghost" id="regCancel">Cancelar</button><button class="cr-btn red" id="regOk">Guardar</button></div>`);
  $('#regCancel').onclick=()=>m.remove();
  $('#regOk').onclick=async()=>{
    const btn=$('#regOk'); btn.disabled=true;
    try{
      await regApi({op:'guardar',nombre:$('#regNombre').value.trim(),telefono:$('#regTel').value.trim(),nombreAnterior:nombre});
      m.remove(); status('✅ Vendedor guardado. Ya se ve en Web, APK y Bot.','good');
      await loadEquipo(true); render();
    }catch(e){ alert(e.message); btn.disabled=false; }
  };
}
async function eliminarEquipo(nombre){
  if(!confirm(`¿Eliminar a ${nombre}? Deja de salir en Web, APK y Bot. Sus clientes NO se borran.`)) return;
  try{ await regApi({op:'eliminar',nombre}); status('🗑️ Vendedor eliminado.','good'); await loadEquipo(true); render(); }
  catch(e){ alert(e.message); }
}

function renderVendedores(){
  const b=$('#revBody'); if(!state.vendedores) return loadVendedores();
  if(!state.equipo){ loadEquipo().then(()=>render()); }
  b.innerHTML=`
    ${equipoHtml()}
    <div class="cr-tools"><span><b>🤝 Socios (Panel de Socios)</b></span><button class="cr-btn red" id="revAddVendedor">＋ Socio</button></div>
    <div class="cr-grid">${state.vendedores.map(vendedorCard).join('')||'<div class="cr-empty">No hay vendedores.</div>'}</div>`;
  $('#regAdd').onclick=()=>editarEquipo();
  b.querySelectorAll('[data-reg-edit]').forEach(x=>x.onclick=()=>editarEquipo(x.dataset.regEdit,x.dataset.tel));
  b.querySelectorAll('[data-reg-del]').forEach(x=>x.onclick=()=>eliminarEquipo(x.dataset.regDel));
  $('#revAddVendedor').onclick=nuevoVendedor;
  b.querySelectorAll('[data-edit-vend]').forEach(x=>x.onclick=()=>editarVendedor(x.dataset.editVend));
  b.querySelectorAll('[data-pin-vend]').forEach(x=>x.onclick=()=>resetPinVendedor(x.dataset.pinVend));
  b.querySelectorAll('[data-test-tg]').forEach(x=>x.onclick=()=>probarTelegramVendedor(x.dataset.testTg,x));
  b.querySelectorAll('[data-del-vend]').forEach(x=>x.onclick=()=>eliminarVendedor(x.dataset.delVend,x.dataset.nombre));
  b.querySelectorAll('[data-toggle-vend]').forEach(x=>x.onclick=()=>toggleActivoVendedor(x.dataset.toggleVend,x.dataset.activo==='1'));
}
function vendedorCard(r){
  const activo=r.activo!==false;
  return `<article class="cr-card">
    <div class="cr-row"><h3>${esc(r.nombre)}</h3><span class="cr-badge ${activo?'':'paused'}">${activo?'Activo':'Inactivo — no puede entrar'}</span></div>
    <small>Usuario: ${esc(r.nombre_norm||r.id)} · WhatsApp: ${esc(r.telefono||'—')} · TG: ${esc(r.telegramId||'—')}</small>
    <div class="cr-row"><small>${r.clientes||0} clientes · ${r.vencidos||0} vencidos · Tarifa: ${esc(r.tarifaId||'general')}</small></div>
    <div class="cr-row"><small>Permisos: ${(r.capabilities?.canViewClients??true)?'Clientes ✓':'Clientes —'} · ${(r.capabilities?.canRenew??true)?'Renovar ✓':'Renovar —'} · ${(r.capabilities?.canBuy??!r.sinCompras)?'Comprar ✓':'Comprar —'} · ${(r.capabilities?.canUseAI??true)?'IA ✓':'IA —'}</small></div>
    <div class="cr-row">
      <button class="cr-btn ghost" data-edit-vend="${esc(r.id)}">Editar</button>
      <button class="cr-btn ghost" data-pin-vend="${esc(r.id)}">🔐 Nuevo PIN</button>
      <button class="cr-btn ghost" data-test-tg="${esc(r.id)}">📨 Probar TG</button>
    </div>
    <div class="cr-row">
      <button class="cr-btn ${activo?'danger':'red'}" data-toggle-vend="${esc(r.id)}" data-activo="${activo?'1':'0'}">${activo?'🔒 Desactivar acceso':'🔓 Reactivar acceso'}</button>
      <button class="cr-btn danger" data-del-vend="${esc(r.id)}" data-nombre="${esc(r.nombre)}">Eliminar</button>
    </div>
  </article>`;
}
async function probarTelegramVendedor(id,button){
  const r=state.vendedores.find(x=>x.id===id);
  if(!r)return;
  if(!r.telegramId){alert(`${r.nombre} no tiene Telegram ID guardado.`);return;}
  const original=button.textContent;button.disabled=true;button.textContent='Probando…';
  try{
    const d=await api('POST',`revendedores/${id}/testtelegram`,{});
    if(d.queued){
      alert(`📨 Prueba enviada al bot principal para ${d.nombre||r.nombre}.\nID: ${d.telegramId||r.telegramId}\n\n${d.diagnostico||'La prueba quedó en cola y debe llegar en segundos.'}`);
    }else{
      alert(`✅ Telegram correcto para ${d.nombre||r.nombre}.\nID: ${d.telegramId||r.telegramId}${d.telegramNombre?`\nCuenta: ${d.telegramNombre}`:''}${d.username?` (@${d.username})`:''}\n\n${d.diagnostico||'Puede recibir mensajes del bot.'}`);
    }
  }catch(e){
    const d=e.data||{};
    const authFail=Number(d.codigo||0)===401||/unauthorized|token/i.test(String(d.error||e.message||''));
    alert(`❌ Telegram de ${r.nombre} falló.\nID guardado: ${d.telegramId||r.telegramId}\n${d.error||e.message}${d.diagnostico?`\n\n${d.diagnostico}`:''}${authFail?'\n\n⚠️ Este error es del BOT_TOKEN, no del ID del vendedor.':'\n\nPídale escribir /id al MISMO bot de Sublicuentas y compare el número con el que aparece aquí.'}`);
  }finally{button.disabled=false;button.textContent=original;}
}

async function toggleActivoVendedor(id,estabaActivo){
  const accion=estabaActivo?'desactivar':'reactivar';
  if(!confirm(estabaActivo?'¿Desactivar a este vendedor? No va a poder entrar al panel hasta que lo reactivés.':'¿Reactivar a este vendedor?')) return;
  try{ await api('PATCH','revendedores/'+id,{activo:!estabaActivo}); status(estabaActivo?'🔒 Acceso desactivado.':'🔓 Acceso reactivado.','good'); await loadVendedores(true); }
  catch(e){ alert(e.message); }
}
function nuevoVendedor(){
  const m=modal(`<h2>Nuevo vendedor</h2>
    <div class="cr-form">
      <label class="cr-field wide">Nombre<input id="nvNombre" placeholder="Ej. Juan Pérez"></label>
      <label class="cr-field wide">WhatsApp<input id="nvTelefono" inputmode="tel" placeholder="Honduras: 8946-4328 · Otro país: +52 55 1234 5678"></label>
      <label class="cr-field wide">ID de Telegram (opcional)<input id="nvTelegram" placeholder="Ej. 123456789"></label>
    </div>
    <div class="cr-actions"><button class="cr-btn ghost" id="nvCancel">Cancelar</button><button class="cr-btn red" id="nvOk">Crear</button></div>`);
  $('#nvCancel').onclick=()=>m.remove();
  $('#nvOk').onclick=async()=>{
    const nombre=$('#nvNombre').value.trim(), telegramId=$('#nvTelegram').value.trim(), telefono=$('#nvTelefono').value.trim();
    if(!nombre||(!telefono&&!telegramId)){ alert('Completá el nombre y al menos WhatsApp o ID de Telegram.'); return; }
    try{
      const d=await api('POST','revendedores',{nombre,telegramId,telefono});
      m.remove();
      pinModal(d.nombre,d.pin,`Usuario de acceso: ${d.nombre_norm}`);
      await loadVendedores(true); loadEquipo(true);
    }catch(e){ alert(e.message); }
  };
}
function editarVendedor(id){
  const r=state.vendedores.find(x=>x.id===id); if(!r) return;
  const c=r.capabilities||r.permisos||{};
  const checked=(k,def=true)=>(typeof c[k]==='boolean'?c[k]:def)?'checked':'';
  const m=modal(`<h2>Editar vendedor</h2>
    <div class="cr-form">
      <label class="cr-field wide">Nombre<input id="evNombre" value="${esc(r.nombre)}"></label>
      <label class="cr-field wide">WhatsApp<input id="evTelefono" value="${esc(r.telefono||'')}"></label>
      <label class="cr-field wide">ID de Telegram (opcional)<input id="evTelegram" value="${esc(r.telegramId||'')}"></label>
      <label class="cr-field wide">Tarifa<select id="evTarifa"><option value="general" ${(r.tarifaId||'general')==='general'?'selected':''}>General</option><option value="${TARIFA_ESPECIAL}" ${r.tarifaId===TARIFA_ESPECIAL?'selected':''}>Sublicuentas · Relojes · Geisell</option></select></label>
      <label class="cr-field wide">Texto del botón de renovación (opcional)<input id="evEtiqueta" maxlength="60" value="${esc(r.etiquetaRenovacion||'')}" placeholder="Ej. Mensaje de renovación"></label>
      <label class="cr-check"><input type="checkbox" id="evActivo" ${r.activo!==false?'checked':''}> Cuenta activa</label>
      <div class="wide"><b style="font-size:13px">Permisos del panel</b><div class="perm-grid" style="margin-top:7px">
        <label class="cr-check"><input type="checkbox" id="evCanClients" ${checked('canViewClients',true)}> Ver clientes</label>
        <label class="cr-check"><input type="checkbox" id="evCanRenew" ${checked('canRenew',true)}> Renovar clientes</label>
        <label class="cr-check"><input type="checkbox" id="evCanBuy" ${checked('canBuy',!r.sinCompras)}> Realizar compras</label>
        <label class="cr-check"><input type="checkbox" id="evCanAI" ${checked('canUseAI',true)}> Subli IA / Aula</label>
        <label class="cr-check"><input type="checkbox" id="evCanRewards" ${checked('recompensas',true)}> Recompensas</label>
        <label class="cr-check"><input type="checkbox" id="evCanInbox" ${checked('buzon',true)}> Buzón</label>
      </div></div>
      <small>Los permisos nuevos se reflejan en sesiones abiertas cuando el panel sincroniza el perfil. El usuario de acceso (${esc(r.nombre_norm)}) no se cambia aquí.</small>
    </div>
    <div class="cr-actions"><button class="cr-btn ghost" id="evCancel">Cancelar</button><button class="cr-btn red" id="evOk">Guardar</button></div>`);
  $('#evCancel').onclick=()=>m.remove();
  $('#evOk').onclick=async()=>{
    const canViewClients=$('#evCanClients').checked,canRenew=$('#evCanRenew').checked,canBuy=$('#evCanBuy').checked,canUseAI=$('#evCanAI').checked;
    const capabilities={inicio:true,clientes:canViewClients,catalogo:true,renovar:canRenew,comprar:canBuy,aula:canUseAI,perfil:true,recompensas:$('#evCanRewards').checked,buzon:$('#evCanInbox').checked,canViewClients,canRenew,canBuy,canUseAI};
    try{
      await api('PATCH','revendedores/'+id,{nombre:$('#evNombre').value.trim(),telefono:$('#evTelefono').value.trim(),telegramId:$('#evTelegram').value.trim(),activo:$('#evActivo').checked,tarifaId:$('#evTarifa').value,etiquetaRenovacion:$('#evEtiqueta').value.trim(),capabilities});
      m.remove(); await loadVendedores(true);
    }catch(e){ alert(e.message); }
  };
}
async function resetPinVendedor(id){
  if(!confirm('¿Generar un PIN nuevo? La clave actual del vendedor queda invalidada.')) return;
  try{ const d=await api('POST','revendedores/'+id+'/resetpin'); pinModal(d.nombre,d.pin,'PIN reiniciado — la clave anterior ya no sirve.'); }
  catch(e){ alert(e.message); }
}
async function eliminarVendedor(id,nombre){
  if(!confirm(`¿Eliminar a ${nombre}? Sus clientes NO se borran, pero quedan sin vendedor asignado.`)) return;
  try{ await api('DELETE','revendedores/'+id); await loadVendedores(true); }
  catch(e){ alert(e.message); }
}
function pinModal(nombre,pin,nota){
  const m=modal(`<h2>👤 ${esc(nombre)}</h2>
    <p>PIN de configuración (de un solo uso) — pásaselo por un canal de confianza. Lo necesita la primera vez que entre al panel:</p>
    <div class="cr-price" style="font-size:32px;text-align:center;letter-spacing:4px">${esc(pin)}</div>
    <small>${esc(nota||'')}</small>
    <div class="cr-actions"><button class="cr-btn red" id="pinOk">Listo</button></div>`);
  $('#pinOk').onclick=()=>m.remove();
}

/* ═══════════ CLIENTES ═══════════ */
async function loadClientesList(){
  const b=$('#revBody');
  try{
    const d=await api('GET','clientes',undefined,state.clienteQ?{q:state.clienteQ}:{});
    state.clientes=d.clientes||[];
    renderClientesList();
  }catch(e){ if(b) b.innerHTML=`<div class="cr-empty">${esc(e.message)}</div>`; }
}
function renderClientes(){
  const b=$('#revBody');
  b.innerHTML=`
    <div class="cr-tools"><input class="cr-search" id="revCliSearch" placeholder="Buscar cliente por nombre o teléfono" value="${esc(state.clienteQ)}"></div>
    <div class="cr-card" style="margin-bottom:12px"><h3>Vendedor por cuenta</h3><small>La migración copia el vendedor actual a cada servicio antiguo y crea un respaldo. Después podrá transferir cuentas individuales sin mover las demás.</small><div class="cr-row" style="margin-top:10px"><button class="cr-btn ghost" id="revPreviewVendedoresServicio">Revisar migración</button><button class="cr-btn red" id="revAplicarVendedoresServicio">Aplicar migración</button></div></div>
    <div id="revCliList"><div class="cr-empty">Escribí para buscar, o dejá vacío y Enter para ver los últimos.</div></div>
    <div id="revCliDetalle"></div>`;
  const inp=$('#revCliSearch');
  inp.onkeydown=e=>{ if(e.key==='Enter'){ state.clienteQ=inp.value.trim(); loadClientesList(); } };
  $('#revPreviewVendedoresServicio').onclick=previsualizarVendedoresServicio;
  $('#revAplicarVendedoresServicio').onclick=aplicarVendedoresServicio;
}
async function previsualizarVendedoresServicio(){
  try{
    const d=await api('GET','actualizaciones/vendedores-por-servicio');
    alert(`Clientes a actualizar: ${d.clientesAActualizar||0}.\nServicios que heredarán vendedor: ${d.serviciosQueHeredaranVendedor||0}.\nServicios sin vendedor para revisión manual: ${d.serviciosSinVendedor||0}.`);
  }catch(e){status(e.message,'bad')}
}
async function aplicarVendedoresServicio(){
  if(!confirm('¿Aplicar el vendedor por cuenta? Se guardará un respaldo antes de modificar cada ficha.'))return;
  const btn=$('#revAplicarVendedoresServicio');if(btn){btn.disabled=true;btn.textContent='Aplicando…'}
  try{
    const d=await api('POST','actualizaciones/vendedores-por-servicio',{});
    status(`✅ Migración completa: ${d.clientesActualizados||0} clientes actualizados. ${d.serviciosSinVendedor||0} servicios quedaron para revisión manual.`,'good');
    await loadClientesList();
  }catch(e){status(e.message,'bad');if(btn){btn.disabled=false;btn.textContent='Aplicar migración'}}
}
function renderClientesList(){
  const box=$('#revCliList'); if(!box) return;
  box.innerHTML=`<div class="cr-grid">${(state.clientes||[]).map(c=>`
    <article class="cr-card">
      <h3>${esc(c.nombre)}</h3>
      <small>${esc(c.telefono||'sin teléfono')} · ${c.clienteCompartido?'🔀 compartido: ':'vendedor: '}${esc(c.vendedor||(Array.isArray(c.vendedores)?c.vendedores.join(' + '):c.vendedor_norm)||'—')}</small>
      <div class="cr-row"><small>${c.servicios} servicio(s)</small><button class="cr-btn ghost" data-ver-cliente="${esc(c.id)}">Ver</button></div>
    </article>`).join('')||'<div class="cr-empty">Sin resultados.</div>'}</div>`;
  box.querySelectorAll('[data-ver-cliente]').forEach(x=>x.onclick=()=>verCliente(x.dataset.verCliente));
}
async function verCliente(id){
  const box=$('#revCliDetalle'); box.innerHTML='<div class="cr-empty">Cargando…</div>';
  try{
    const d=await api('GET','clientes/'+id);
    state.clienteSel=d.cliente;
    if(!state.vendedores) await loadVendedores(); // para el selector de reasignar
    renderClienteDetalle();
  }catch(e){ box.innerHTML=`<div class="cr-empty">${esc(e.message)}</div>`; }
}
function renderClienteDetalle(){
  const box=$('#revCliDetalle'); const c=state.clienteSel; if(!c) return;
  const servicios=Array.isArray(c.servicios)?c.servicios:[];
  const vendedoresResumen=[...new Set(servicios.map(s=>s.vendedor).filter(Boolean))];
  box.innerHTML=`<div class="cr-card" style="margin-top:12px">
    <h2>👤 ${esc(c.nombrePerfil||c.nombre||'Cliente')}</h2>
    <small>${vendedoresResumen.length>1?'🔀 Cliente compartido · ':''}Vendedores por cuenta: ${esc(vendedoresResumen.join(' + ')||c.vendedor||'—')}</small>
    <div class="cr-form">
      <label class="cr-field">Nombre<input id="cdNombre" value="${esc(c.nombrePerfil||c.nombre||'')}"></label>
      <label class="cr-field">Teléfono<input id="cdTelefono" value="${esc(c.telefono||'')}"></label>
    </div>
    <div class="cr-actions">
      <button class="cr-btn danger" id="cdDelete">Eliminar cliente</button>
      <button class="cr-btn red" id="cdSave">💾 Guardar datos</button>
    </div>
    <div class="cr-section">Servicios</div>
    <div class="cr-grid">${servicios.map((s,i)=>servicioCard(s,i,c)).join('')||'<div class="cr-empty">Sin servicios.</div>'}</div>
  </div>`;
  $('#cdSave').onclick=async()=>{
    try{
      await api('PATCH','clientes/'+c.id,{nombrePerfil:$('#cdNombre').value.trim(),telefono:$('#cdTelefono').value.trim()});
      status('✅ Datos guardados.','good'); await verCliente(c.id);
    }catch(e){ alert(e.message); }
  };
  $('#cdDelete').onclick=async()=>{
    if(!confirm('¿Eliminar este cliente por completo? No se puede deshacer.')) return;
    try{ await api('DELETE','clientes/'+c.id); box.innerHTML=''; state.clienteSel=null; await loadClientesList(); }
    catch(e){ alert(e.message); }
  };
  box.querySelectorAll('[data-save-servicio]').forEach(x=>x.onclick=()=>guardarServicio(c.id,x.dataset.saveServicio));
  box.querySelectorAll('[data-del-servicio]').forEach(x=>x.onclick=()=>eliminarServicio(c.id,x.dataset.delServicio));
}
function servicioCard(s,idx,c){
  const actualRaw=String(s.vendedor_norm||s.vendedor||c?.vendedor_norm||c?.vendedor||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ').trim();
  const actual=actualRaw==='geissel'?'geisell':actualRaw;
  const conocidos=state.vendedores||[];
  const tieneActual=conocidos.some(v=>String(v.nombre_norm||v.id||'')===actual);
  const opciones=(tieneActual?'':`<option value="${esc(actual)}" selected>${esc(s.vendedor||actual||'Sin vendedor')}</option>`)+conocidos.map(v=>{
    const vn=String(v.nombre_norm||v.id||'');
    return `<option value="${esc(vn)}" ${vn===actual?'selected':''}>${esc(v.nombre||vn)}</option>`;
  }).join('');
  return `<article class="cr-card">
    <h3>${esc(s.plataforma||'Servicio')}</h3>
    <label class="cr-field">Vendedor responsable<select id="svVendedor-${idx}">${opciones}</select></label>
    <label class="cr-field">Precio<input type="number" min="0" step="1" id="svPrecio-${idx}" value="${s.precio??''}"></label>
    <label class="cr-field">Vencimiento (DD/MM/AAAA)<input id="svFecha-${idx}" value="${esc(s.fechaRenovacion||'')}"></label>
    <label class="cr-field">Correo<input id="svCorreo-${idx}" value="${esc(s.correo||'')}"></label>
    <label class="cr-field">Clave<input id="svClave-${idx}" value="${esc(s.clave||'')}"></label>
    <label class="cr-field">PIN<input id="svPin-${idx}" value="${esc(s.pin||'')}"></label>
    <div class="cr-row">
      <button class="cr-btn danger" data-del-servicio="${idx}">Eliminar servicio</button>
      <button class="cr-btn red" data-save-servicio="${idx}">💾 Guardar</button>
    </div>
  </article>`;
}
async function guardarServicio(clienteId,idx){
  const patch={};
  const precio=Number($('#svPrecio-'+idx)?.value);
  if(Number.isFinite(precio)&&precio>0) patch.precio=precio;
  const fecha=$('#svFecha-'+idx)?.value.trim(); if(fecha) patch.fechaRenovacion=fecha;
  patch.correo=$('#svCorreo-'+idx)?.value.trim()||'';
  patch.clave=$('#svClave-'+idx)?.value.trim()||'';
  patch.pin=$('#svPin-'+idx)?.value.trim()||'';
  patch.vendedor_norm=$('#svVendedor-'+idx)?.value||'';
  const vendedor=(state.vendedores||[]).find(v=>String(v.nombre_norm||v.id)===patch.vendedor_norm);
  patch.vendedor=vendedor?.nombre||patch.vendedor_norm;
  patch.compraId=String(state.clienteSel?.servicios?.[idx]?.compraId||'');
  try{
    await api('PATCH',`clientes/${clienteId}/servicios/${idx}`,patch);
    status('✅ Servicio actualizado.','good');
    await verCliente(clienteId);
  }catch(e){ alert(e.message); }
}
async function eliminarServicio(clienteId,idx){
  if(!confirm('¿Eliminar este servicio del cliente?')) return;
  try{ await api('DELETE',`clientes/${clienteId}/servicios/${idx}`,undefined,{compraId:String(state.clienteSel?.servicios?.[idx]?.compraId||'')}); await verCliente(clienteId); }
  catch(e){ alert(e.message); }
}

/* ═══════════ RECOMPENSAS ═══════════ */
async function loadRecompensas(force){
  if(state.recompensas&&!force)return renderRecompensas();
  const b=$('#revBody');if(b)b.innerHTML='<div class="cr-empty">Cargando recompensas…</div>';
  try{const d=await api('GET','recompensas');state.recompensas=d.recompensas||[];renderRecompensas()}catch(e){if(b)b.innerHTML=`<div class="cr-empty">${esc(e.message)}</div>`}
}
function renderRecompensas(){
  const b=$('#revBody');if(!state.recompensas)return loadRecompensas();
  b.innerHTML=`<div class="cr-tools"><span>Solicitudes de premios de los socios</span><button class="cr-btn ghost" id="rewardReload">Actualizar</button></div><div class="cr-grid">${state.recompensas.map(r=>`<article class="cr-card"><div class="cr-row"><h3>🎁 ${esc(r.recompensa||'Recompensa')}</h3><span class="cr-badge ${r.estado==='entregada'?'':r.estado==='rechazada'?'paused':''}">${esc(r.estado||'pendiente')}</span></div><small>Socio: ${esc(r.socio||r.socio_norm||'—')} · Nivel ${esc(r.nivel||'—')} · ${Number(r.ventas)||0} ventas</small><div class="cr-row"><button class="cr-btn danger" data-reward-status="rechazada" data-reward-id="${esc(r.id)}">Rechazar</button><button class="cr-btn red" data-reward-status="entregada" data-reward-id="${esc(r.id)}">✓ Marcar entregada</button></div></article>`).join('')||'<div class="cr-empty">No hay solicitudes de recompensa.</div>'}</div>`;
  $('#rewardReload').onclick=()=>loadRecompensas(true);
  b.querySelectorAll('[data-reward-id]').forEach(x=>x.onclick=()=>setRewardStatus(x.dataset.rewardId,x.dataset.rewardStatus));
}
async function setRewardStatus(id,estado){try{await api('PATCH','recompensas/'+id,{estado});await loadRecompensas(true)}catch(e){alert(e.message)}}

/* ═══════════ R145 · PRECIOS PARA REVENDEDORES (página pública) ═══════════
   El precio sale de la colección "precios" (tarifa general) del Panel de Socios.
   Aquí solo se decide qué se muestra al público y cómo. Los cambios quedan en
   BORRADOR hasta tocar "Publicar"; el precio socio se edita en su fuente real. */
const PUB_CATS=['Streaming','TV Digital','Música','Herramientas','Inteligencia Artificial','Recargas de juegos'];
const pubUrl=()=>location.origin+'/precios-mayoristas';
const pubItem=id=>{const b=state.pub.borrador;b.items=b.items||{};if(!b.items[id])b.items[id]={publico:false,categoria:'',orden:null,texto:'',disponible:true,usarPrecioSocio:true,precioMostrado:null,precioSugerido:null};return b.items[id];};
const pubFecha=ms=>ms?new Date(ms).toLocaleString('es-HN',{day:'numeric',month:'short',year:'numeric',hour:'numeric',minute:'2-digit'}):'nunca';
async function loadPublico(force){
  if(state.pub&&!force)return renderPublico();
  const b=$('#revBody');if(b)b.innerHTML='<div class="cr-empty">Cargando precios para revendedores…</div>';
  try{state.pub=await api('GET','publico');state.pub.q=state.pub.q||'';renderPublico();}
  catch(e){if(b)b.innerHTML=`<div class="cr-empty">${esc(e.message)}</div>`;}
}
let pubTimer=null;
function pubGuardarLuego(){
  clearTimeout(pubTimer);const st=$('#pubEstado');if(st)st.textContent='Guardando borrador…';
  pubTimer=setTimeout(async()=>{try{const r=await api('PUT','publico',{borrador:state.pub.borrador});state.pub.pendiente=r.pendiente;state.pub.version=r.version;pubPintarEstado();if(r.version!=='r149'){const s3=$('#pubEstado');if(s3)s3.innerHTML='<b style="color:#b42318">⚠️ No se guardó la venta sugerida: el servidor de Vercel está desactualizado.</b>';}}catch(e){const s2=$('#pubEstado');if(s2)s2.textContent='⚠️ '+e.message;}},700);
}
function pubPintarEstado(){
  const st=$('#pubEstado');if(!st)return;
  const n=Object.values(state.pub.borrador.items||{}).filter(x=>x.publico).length;
  st.innerHTML=`${n} producto${n===1?'':'s'} en la lista · publicada: <b>${esc(pubFecha(state.pub.publicadoEn))}</b>${state.pub.pendiente?' · <b style="color:#e2231a">hay cambios sin publicar</b>':' · al día'}`;
}
function pubFila(p){
  const it=pubItem(p.id),busca=[p.nombre,p.variante,p.categoriaSocios].join(' ').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'');
  return `<div class="pub-row" data-pub-row="${esc(p.id)}" data-search="${esc(busca)}">
    <div class="pub-main">
      <div class="pub-name"><b>${esc(p.nombre)}</b>${p.variante?`<small>${esc(p.variante)}</small>`:''}${p.activoSocios?'':'<small style="color:#b42318">Apagado en el Panel de Socios: no sale en la lista</small>'}</div>
      <label class="pub-price">Precio socio<span>L <input type="number" min="0" step="1" inputmode="decimal" data-pub-socio="${esc(p.id)}" value="${p.precioSocio??''}" placeholder="—"></span></label>
      <label class="pub-price">Venta sugerida<span>L <input type="number" min="0" step="1" inputmode="decimal" data-pub-k="precioSugerido" data-id="${esc(p.id)}" value="${it.precioSugerido??''}" placeholder="—"></span></label>
      <label class="pub-sw"><input type="checkbox" data-pub-k="publico" data-id="${esc(p.id)}" ${it.publico?'checked':''}><i></i><span>${it.publico?'ON':'OFF'}</span></label>
      <button class="cr-btn ghost pub-more" data-pub-more="${esc(p.id)}" type="button">Opciones</button>
    </div>
    <div class="pub-opts" hidden>
      <label class="cr-field">Categoría en la lista<input list="pubCats" data-pub-k="categoria" data-id="${esc(p.id)}" value="${esc(it.categoria)}" placeholder="${esc(p.categoriaSugerida)}"></label>
      <label class="cr-field">Orden de aparición<input type="number" data-pub-k="orden" data-id="${esc(p.id)}" value="${it.orden??''}" placeholder="Automático"></label>
      <label class="cr-field wide">Texto secundario (opcional)<input maxlength="90" data-pub-k="texto" data-id="${esc(p.id)}" value="${esc(it.texto)}" placeholder="${esc([p.variante,p.categoriaSub].filter(Boolean).join(' · ')||'Ej. 1 perfil · 1 mes')}"></label>
      <label class="pub-check"><input type="checkbox" data-pub-k="disponible" data-id="${esc(p.id)}" ${it.disponible?'checked':''}> Disponible</label>
      <label class="pub-check"><input type="checkbox" data-pub-k="usarPrecioSocio" data-id="${esc(p.id)}" ${it.usarPrecioSocio?'checked':''}> Usar precio socio actual</label>
      <label class="cr-field">Precio mostrado en página pública<input type="number" min="0" data-pub-k="precioMostrado" data-id="${esc(p.id)}" value="${it.precioMostrado??''}" ${it.usarPrecioSocio?'disabled':''} placeholder="Ej. 140"><small>No cambia el precio real de los socios.</small></label>
    </div>
  </div>`;
}
function renderPublico(){
  const b=$('#revBody');if(!state.pub)return loadPublico();
  const grupos=[];state.pub.productos.forEach(p=>{let g=grupos.find(x=>x.k===p.categoriaSocios);if(!g){g={k:p.categoriaSocios,items:[]};grupos.push(g);}g.items.push(p);});
  const c=state.pub.borrador.contacto||{};
  const cond=state.pub.borrador.condiciones||{minimoMensual:5,mostrar:true,texto:'',puntos:[]};
  b.innerHTML=`<style>
    #rbac-revendedores .pub-top{display:grid;gap:10px;background:#fff;border:1px solid #e4e7ec;border-radius:16px;padding:14px;margin-bottom:12px}
    #rbac-revendedores .pub-actions{display:flex;flex-wrap:wrap;gap:8px}
    #rbac-revendedores .pub-contact{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.4fr);gap:8px}
    #rbac-revendedores .pub-group{margin:16px 0 6px;font-size:12px;font-weight:900;letter-spacing:.05em;text-transform:uppercase;color:#475467}
    #rbac-revendedores .pub-list{background:#fff;border:1px solid #e4e7ec;border-radius:14px;overflow:hidden}
    #rbac-revendedores .pub-row{border-top:1px solid #f0f2f5;padding:10px 12px}
    #rbac-revendedores .pub-row:first-child{border-top:0}
    #rbac-revendedores .pub-main{display:grid;grid-template-columns:minmax(0,1fr) 104px 104px 74px auto;gap:10px;align-items:center}
    #rbac-revendedores .pub-name b{display:block;font-size:14.5px;color:#101828}
    #rbac-revendedores .pub-name small{display:block;font-size:12px;color:#667085;margin-top:2px}
    #rbac-revendedores .pub-price{font-size:10.5px;font-weight:800;color:#667085;display:grid;gap:3px}
    #rbac-revendedores .pub-price span{display:flex;align-items:center;gap:4px;border:1px solid #d9e0e9;border-radius:10px;padding:0 8px;font-size:14px;font-weight:800;color:#101828}
    #rbac-revendedores .pub-price input{width:100%;border:0;outline:0;padding:8px 0;font:inherit;background:transparent}
    #rbac-revendedores .pub-sw{display:flex;align-items:center;gap:6px;cursor:pointer;font-size:12px;font-weight:900;color:#475467}
    #rbac-revendedores .pub-sw input{display:none}
    #rbac-revendedores .pub-sw i{width:38px;height:22px;border-radius:22px;background:#d0d5dd;position:relative;transition:.15s;flex:0 0 auto}
    #rbac-revendedores .pub-sw i::after{content:"";position:absolute;top:3px;left:3px;width:16px;height:16px;border-radius:50%;background:#fff;transition:.15s}
    #rbac-revendedores .pub-sw input:checked+i{background:#12b76a}
    #rbac-revendedores .pub-sw input:checked+i::after{left:19px}
    #rbac-revendedores .pub-more{padding:7px 10px;font-size:12px}
    #rbac-revendedores .pub-opts{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px 10px;margin-top:10px;padding:10px;border-radius:12px;background:#f9fafb}
    #rbac-revendedores .pub-opts[hidden]{display:none}
    #rbac-revendedores .pub-top input,#rbac-revendedores .pub-opts input{box-sizing:border-box;width:100%;min-width:0}
    #rbac-revendedores .pub-top input[type=checkbox],#rbac-revendedores .pub-opts input[type=checkbox]{width:auto;flex:0 0 auto}
    #rbac-revendedores .pub-check{display:flex;align-items:center;gap:7px;font-size:13px;font-weight:700;color:#344054}
    @media(max-width:640px){#rbac-revendedores .pub-main{grid-template-columns:minmax(0,1fr) minmax(0,1fr);}#rbac-revendedores .pub-main .pub-name{grid-column:1/-1}#rbac-revendedores .pub-contact,#rbac-revendedores .pub-opts{grid-template-columns:1fr}}
  </style>
  <div class="pub-top">
    <div><b style="font-size:16px">Lista pública de precios</b><div style="color:#667085;font-size:13px;margin-top:3px">Página sin login para prospectos: <a href="${esc(pubUrl())}" target="_blank" rel="noopener">${esc(pubUrl().replace(/^https?:\/\//,''))}</a>. No da acceso al Panel de Socios.</div></div>
    <div id="pubEstado" style="font-size:13px;color:#475467"></div>
    <div class="pub-actions">
      <button class="cr-btn ghost" id="pubPreview">👁️ Vista previa</button>
      <button class="cr-btn red" id="pubPublicar">Publicar cambios</button>
      <button class="cr-btn ghost" id="pubImagen">🖼️ Generar imagen de precios</button>
      <button class="cr-btn ghost" id="pubCopiar">🔗 Copiar enlace</button>
      <button class="cr-btn ghost" id="pubWa" type="button">💬 Compartir por WhatsApp</button>
    </div>
    <div class="pub-contact">
      <label class="cr-field">Botón "Quiero ser revendedor" → WhatsApp o enlace<input id="pubDestino" value="${esc(c.destino||'')}" placeholder="9999-9999 o https://…"></label>
      <label class="cr-field">Mensaje que llega por WhatsApp<input id="pubMensaje" maxlength="300" value="${esc(c.mensaje||'Hola, quiero ser revendedor de Sublicuentas.')}"></label>
    </div>
    <div style="border-top:1px solid #eef1f4;padding-top:10px"><b style="font-size:14px">Configuración comercial</b><div style="color:#667085;font-size:12.5px;margin-top:2px">Condición para aplicar a precios de revendedor. Es mensual: no obliga a comprar esa cantidad en cada pedido.</div></div>
    <div class="pub-contact">
      <label class="cr-field">Compra mínima mensual (perfiles)<input id="pubMinimo" type="number" min="1" step="1" inputmode="numeric" value="${cond.minimoMensual??''}" placeholder="Ej. 5"></label>
      <label class="pub-check" style="align-self:end;padding-bottom:10px"><input type="checkbox" id="pubCondMostrar" ${cond.mostrar!==false?'checked':''}> Mostrar condición en la página pública</label>
      <label class="cr-field wide" style="grid-column:1/-1">Puntos de la tarjeta de condiciones (uno por línea)<textarea id="pubCondPuntos" rows="4" maxlength="1200" style="box-sizing:border-box;width:100%;border:1px solid #d9e0e9;border-radius:12px;padding:10px 11px;font:inherit;resize:vertical">${esc((cond.puntos||[]).join('\n'))}</textarea><small>La compra mínima mensual se agrega sola como primer punto.</small></label>
      <label class="cr-field wide" style="grid-column:1/-1">Texto adicional de condiciones (opcional)<input id="pubCondTexto" maxlength="400" value="${esc(cond.texto||'')}" placeholder="Ej. Los pedidos se pagan por adelantado."></label>
    </div>
  </div>
  <div class="price-toolbar"><label class="price-search">🔎 <input id="pubBuscar" value="${esc(state.pub.q||'')}" placeholder="Buscar producto…"></label><small>ON = aparece en la lista pública. El precio socio es el mismo del Panel de Socios.</small></div>
  <datalist id="pubCats">${PUB_CATS.map(x=>`<option value="${esc(x)}">`).join('')}</datalist>
  ${state.pub.productos.length?grupos.map(g=>`<div data-pub-group><div class="pub-group">${esc(g.k||'Sin categoría')}</div><div class="pub-list">${g.items.map(pubFila).join('')}</div></div>`).join(''):'<div class="cr-empty">El catálogo del Panel de Socios está vacío. Cárguelo en la pestaña Precios.</div>'}`;
  pubPintarEstado();
  if(state.pub.version!=='r149')b.querySelector('.pub-top').insertAdjacentHTML('afterbegin','<div class="cr-status" style="background:#fef3f2;color:#b42318;border:1px solid #fecdca;border-radius:12px;padding:10px 12px;font-weight:700">⚠️ Vercel todavía no tiene la actualización del servidor (api/). La venta sugerida y la compra mínima NO se van a guardar. Revise en Vercel → Deployments que el último despliegue esté en “Ready”.</div>');
  const filtrar=()=>{const q=String(state.pub.q||'').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'').trim();b.querySelectorAll('[data-pub-row]').forEach(r=>{r.style.display=!q||r.dataset.search.includes(q)?'':'none'});b.querySelectorAll('[data-pub-group]').forEach(g=>{g.style.display=[...g.querySelectorAll('[data-pub-row]')].some(r=>r.style.display!=='none')?'':'none'});};
  $('#pubBuscar').oninput=e=>{state.pub.q=e.target.value;filtrar();};filtrar();
  b.querySelectorAll('[data-pub-more]').forEach(x=>x.onclick=()=>{const o=x.closest('[data-pub-row]').querySelector('.pub-opts');o.hidden=!o.hidden;});
  b.querySelectorAll('[data-pub-k]').forEach(el=>el.addEventListener(el.type==='checkbox'?'change':'input',()=>{
    const it=pubItem(el.dataset.id),k=el.dataset.pubK;
    if(el.type==='checkbox')it[k]=el.checked;else if(k==='orden'||k==='precioMostrado'||k==='precioSugerido')it[k]=el.value===''?null:Number(el.value);else it[k]=el.value;
    if(k==='publico'){const sp=el.parentElement.querySelector('span');if(sp)sp.textContent=el.checked?'ON':'OFF';}
    if(k==='usarPrecioSocio'){const pm=el.closest('.pub-opts').querySelector('[data-pub-k="precioMostrado"]');pm.disabled=el.checked;}
    pubGuardarLuego();
  }));
  const contacto=()=>{state.pub.borrador.contacto={destino:$('#pubDestino').value.trim(),mensaje:$('#pubMensaje').value.trim()};pubGuardarLuego();};
  $('#pubDestino').oninput=contacto;$('#pubMensaje').oninput=contacto;
  // R147: compra mínima mensual editable (sin tocar código).
  const condiciones=()=>{const v=$('#pubMinimo').value;state.pub.borrador.condiciones={minimoMensual:v===''?null:Math.max(1,Math.round(Number(v))||1),mostrar:$('#pubCondMostrar').checked,texto:$('#pubCondTexto').value.trim(),puntos:$('#pubCondPuntos').value.split('\n').map(x=>x.trim()).filter(Boolean)};pubGuardarLuego();};
  $('#pubMinimo').oninput=condiciones;$('#pubCondMostrar').onchange=condiciones;$('#pubCondTexto').oninput=condiciones;$('#pubCondPuntos').oninput=condiciones;
  // Precio socio: se guarda en su FUENTE (Panel de Socios) — se refleja en socios y en la página pública.
  b.querySelectorAll('[data-pub-socio]').forEach(el=>el.addEventListener('change',async()=>{
    const p=state.pub.productos.find(x=>x.id===el.dataset.pubSocio);if(!p)return;
    const nuevo=el.value===''?null:Number(el.value);
    if(nuevo===p.precioSocio)return;
    if(!confirm(`¿Cambiar el precio socio de ${p.nombre}${p.variante?' · '+p.variante:''} de ${money(p.precioSocio)} a ${money(nuevo)}?\n\nEs el precio REAL del Panel de Socios: lo verán todos los socios y la página pública.`)){el.value=p.precioSocio??'';return;}
    el.disabled=true;
    try{await api('PUT','precios/'+p.id,{precio:nuevo},{tarifa:'general'});p.precioSocio=nuevo;state.precios=null;status('✅ Precio socio actualizado en el Panel de Socios y en la lista pública.','ok');}
    catch(e){el.value=p.precioSocio??'';alert(e.message);}
    finally{el.disabled=false;}
  }));
  $('#pubCopiar').onclick=async()=>{try{await navigator.clipboard.writeText(pubUrl());status('🔗 Enlace copiado.','ok');}catch(_){prompt('Copie el enlace:',pubUrl());}};
  $('#pubWa').onclick=()=>window.open('https://wa.me/?text='+encodeURIComponent('Precios para revendedores de Sublicuentas: '+pubUrl()),'_blank','noopener');
  $('#pubPreview').onclick=pubVistaPrevia;
  $('#pubImagen').onclick=pubGenerarImagen;
  $('#pubPublicar').onclick=async()=>{
    const btn=$('#pubPublicar');btn.disabled=true;clearTimeout(pubTimer);
    try{const r=await api('POST','publico/publicar',{borrador:state.pub.borrador});await loadPublico(true);status(r.cambio?'✅ Lista publicada. Ya se ve en la página pública (puede tardar ~1 minuto).':'La lista ya estaba al día: no había cambios que publicar.','ok');}
    catch(e){alert(e.message);}finally{const b2=$('#pubPublicar');if(b2)b2.disabled=false;}
  };
}
async function pubVistaPrevia(){
  clearTimeout(pubTimer);
  let datos;
  try{await api('PUT','publico',{borrador:state.pub.borrador});const d=await api('GET','publico');Object.assign(state.pub,d);datos=d.vistaPrevia;pubPintarEstado();}
  catch(e){return alert(e.message);}
  const m=modal(`<div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:10px"><b>👁️ Vista previa (sin publicar)</b><button class="cr-btn ghost" data-x>Cerrar</button></div>
    <iframe title="Vista previa" src="/precios-revendedores.html?preview=1" style="width:100%;height:70vh;border:1px solid #e4e7ec;border-radius:14px;background:#fff"></iframe>`,{wide:true});
  m.querySelector('.cr-sheet').style.maxWidth='460px';
  m.querySelector('[data-x]').onclick=()=>m._modalClose();
  const fr=m.querySelector('iframe');
  const enviar=()=>{try{fr.contentWindow.postMessage({tipo:'precios-preview',datos},location.origin);}catch(_){}};
  const onMsg=e=>{if(e.origin===location.origin&&e.data&&e.data.tipo==='precios-preview-listo')enviar();};
  window.addEventListener('message',onMsg);fr.addEventListener('load',enviar);
  m._modalCleanup=()=>window.removeEventListener('message',onMsg);
}
function pubCargarScript(src,global){return new Promise((ok,no)=>{if(window[global])return ok(window[global]);const s=document.createElement('script');s.src=src;s.onload=()=>ok(window[global]);s.onerror=()=>no(new Error('No se pudo cargar '+global));document.head.appendChild(s);});}
function pubCargarImg(src){return new Promise((ok,no)=>{const i=new Image();i.onload=()=>ok(i);i.onerror=()=>no(new Error('No se pudo cargar el logo'));i.src=src;});}
async function pubGenerarImagen(){
  const btn=$('#pubImagen');btn.disabled=true;
  try{
    const d=await api('GET','publico');Object.assign(state.pub,d);const lista=d.publicada;
    if(!lista||!lista.total)throw new Error('Primero publique la lista: la imagen usa solo los productos ya publicados.');
    if(d.pendiente&&!confirm('Hay cambios SIN publicar. La imagen usará la lista ya publicada. ¿Continuar?'))return;
    if(!document.querySelector('link[data-inter]')){const l=document.createElement('link');l.rel='stylesheet';l.href='https://fonts.googleapis.com/css2?family=Inter:wght@500;700;800;900&display=swap';l.dataset.inter='1';document.head.appendChild(l);}
    try{await Promise.race([Promise.all(['500 30px Inter','700 30px Inter','800 30px Inter','900 30px Inter'].map(f=>document.fonts.load(f))),new Promise(r=>setTimeout(r,2500))]);}catch(_){}
    const [logo,qrLib]=await Promise.all([pubCargarImg('/assets/sublicuentas-logo-claro.png'),pubCargarScript('/assets/qrcode-generator.js','qrcode')]);
    const F='Inter, system-ui, -apple-system, Segoe UI, Roboto, sans-serif',W=1080,PAD=72;
    const filas=lista.categorias.reduce((n,c)=>n+c.productos.length,0);
    const conSug=lista.categorias.some(c=>c.productos.some(p=>p.precioSugerido!=null)),FILA=conSug?128:104,minimo=lista.condiciones&&lista.condiciones.minimoMensual;
    const H=Math.max(1920,(minimo?610:560)+lista.categorias.length*96+filas*FILA+470);
    const cv=document.createElement('canvas');cv.width=W;cv.height=H;const x=cv.getContext('2d');
    const rr=(X,Y,w,h,r)=>{x.beginPath();x.moveTo(X+r,Y);x.arcTo(X+w,Y,X+w,Y+h,r);x.arcTo(X+w,Y+h,X,Y+h,r);x.arcTo(X,Y+h,X,Y,r);x.arcTo(X,Y,X+w,Y,r);x.closePath();};
    const corta=(t,max)=>{t=String(t||'');if(x.measureText(t).width<=max)return t;while(t.length>1&&x.measureText(t+'…').width>max)t=t.slice(0,-1);return t+'…';};
    x.fillStyle='#fff';x.fillRect(0,0,W,H);
    // Marca
    const lh=78,lw=logo.width*lh/logo.height;x.drawImage(logo,PAD-6,72,lw,lh); // R149: logo para fondo blanco
    x.fillStyle='#0B0B0C';x.font=`900 76px ${F}`;x.fillText('PRECIOS PARA',PAD,268);
    x.fillStyle='#E2231A';x.fillText('REVENDEDORES',PAD,350);
    x.fillStyle='#5B6270';x.font=`500 32px ${F}`;x.fillText('Precios especiales para socios · en Lempiras',PAD,408);
    const f=lista.actualizadoEn?new Intl.DateTimeFormat('es-HN',{timeZone:'America/Tegucigalpa',day:'numeric',month:'long',year:'numeric'}).format(new Date(lista.actualizadoEn)):'';
    x.fillStyle='#00A9C7';x.beginPath();x.arc(PAD+8,452,8,0,Math.PI*2);x.fill();
    x.fillStyle='#0B0B0C';x.font=`700 28px ${F}`;x.fillText(`Actualizado: ${f}`,PAD+28,462);
    let y=540;
    if(minimo){ // R147: la condición sale de la configuración, no de la plantilla
      rr(PAD,492,W-PAD*2,64,14);x.fillStyle='#F6F7F8';x.fill();
      x.fillStyle='#0B0B0C';x.font=`700 28px ${F}`;x.fillText(`Compra mínima mensual: ${minimo} perfil${minimo===1?'':'es'}`,PAD+24,534);
      y=610;
    }
    for(const c of lista.categorias){
      x.fillStyle='#E2231A';x.fillRect(PAD,y-12,28,6);
      x.fillStyle='#0B0B0C';x.font=`800 28px ${F}`;x.fillText(String(c.nombre).toUpperCase(),PAD+42,y);
      x.fillStyle='#8A919C';x.font=`700 20px ${F}`;x.textAlign='right';x.fillText('PRECIO REVENDEDOR',W-PAD,y);x.textAlign='left';
      y+=34;
      c.productos.forEach((p,i)=>{
        const top=y;if(i){x.fillStyle='#ECEEF1';x.fillRect(PAD,top,W-PAD*2,2);}
        const precio=p.precio==null?'Consultar':`L${Number(p.precio).toLocaleString('es-HN')}`;
        x.font=`800 44px ${F}`;const pw=x.measureText(precio).width;
        x.fillStyle=p.disponible?'#0B0B0C':'#8A919C';x.textAlign='right';x.fillText(precio,W-PAD,top+66);x.textAlign='left';
        const sugTxt=p.precioSugerido!=null?`Venta sugerida L${Number(p.precioSugerido).toLocaleString('es-HN')}${p.gananciaSugerida!=null?` · gana L${Number(p.gananciaSugerida).toLocaleString('es-HN')}`:''}`:'';
        x.font=`600 24px ${F}`;const sw=sugTxt?x.measureText(sugTxt).width:0;
        const maxN=W-PAD*2-Math.max(pw,sw)-40;
        x.fillStyle='#0B0B0C';x.font=`700 36px ${F}`;x.fillText(corta(p.nombre,maxN),PAD,top+50);
        x.fillStyle='#5B6270';x.font=`500 26px ${F}`;x.fillText(corta(p.disponible?p.texto:`${p.texto?p.texto+' · ':''}No disponible por ahora`,maxN),PAD,top+86);
        if(sugTxt){x.textAlign='right';x.font=`600 24px ${F}`;x.fillStyle='#007A90';x.fillText(sugTxt,W-PAD,top+104);x.textAlign='left';}
        y+=FILA;
      });
      y+=62;
    }
    // Pie: QR + CTA
    const yQ=Math.max(y+10,H-430);
    x.fillStyle='#ECEEF1';x.fillRect(PAD,yQ-30,W-PAD*2,2);
    const q=qrLib(0,'M');q.addData(pubUrl());q.make();const n=q.getModuleCount(),qs=260,cel=qs/n;
    x.fillStyle='#fff';x.fillRect(PAD,yQ,qs,qs);x.fillStyle='#0B0B0C';
    for(let r=0;r<n;r++)for(let k=0;k<n;k++)if(q.isDark(r,k))x.fillRect(Math.floor(PAD+k*cel),Math.floor(yQ+r*cel),Math.ceil(cel),Math.ceil(cel));
    const tx=PAD+qs+40;
    x.fillStyle='#0B0B0C';x.font=`800 34px ${F}`;x.fillText('Lista siempre actualizada',tx,yQ+56);
    x.fillStyle='#5B6270';x.font=`500 27px ${F}`;x.fillText('Escanee el código o entre a:',tx,yQ+100);
    x.fillStyle='#0B0B0C';x.font=`700 27px ${F}`;x.fillText(corta(pubUrl().replace(/^https?:\/\//,''),W-PAD-tx),tx,yQ+140);
    rr(tx,yQ+176,W-PAD-tx,84,16);x.fillStyle='#E2231A';x.fill();
    x.fillStyle='#fff';x.font=`900 30px ${F}`;x.textAlign='center';x.fillText('QUIERO SER REVENDEDOR',tx+(W-PAD-tx)/2,yQ+229);x.textAlign='left';
    const url=cv.toDataURL('image/png');
    const m=modal(`<div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:10px"><b>🖼️ Imagen de precios</b><button class="cr-btn ghost" data-x>Cerrar</button></div>
      <img src="${url}" alt="Precios para revendedores" style="width:100%;border:1px solid #e4e7ec;border-radius:12px">
      <div style="display:flex;gap:8px;margin-top:12px"><a class="cr-btn red" style="flex:1;text-align:center" download="sublicuentas-precios-revendedores.png" href="${url}">Descargar imagen</a><button class="cr-btn ghost" data-share style="flex:1">Compartir</button></div>
      <small style="display:block;margin-top:8px;color:#667085">Para WhatsApp/Facebook. La referencia de precios vigentes es siempre la página web.</small>`);
    m.querySelector('[data-x]').onclick=()=>m._modalClose();
    m.querySelector('[data-share]').onclick=async()=>{try{const blob=await (await fetch(url)).blob();const file=new File([blob],'sublicuentas-precios-revendedores.png',{type:'image/png'});if(navigator.canShare&&navigator.canShare({files:[file]}))await navigator.share({files:[file],text:'Precios para revendedores: '+pubUrl()});else alert('Su navegador no permite compartir imágenes directo. Use "Descargar imagen".');}catch(_){}};
  }catch(e){alert(e.message);}
  finally{const b2=$('#pubImagen');if(b2)b2.disabled=false;}
}


/* ═══════════ ENTREGAS POR RENGLÓN · BUZÓN · HISTORIAL (brief 30/10/2026) ═══════════
   Preparar → Vincular → Completar → Revisar → Publicar → Informar. Una sola publicación por renglón:
   doble toque no duplica (opId estable por formulario). El aviso de Telegram es aparte de la entrega. */
const opNuevo=()=>(crypto.randomUUID?crypto.randomUUID():String(Date.now())+Math.random().toString(16).slice(2)).replace(/[^A-Za-z0-9_-]/g,'');
const AVISO_TXT={pendiente:'Aviso pendiente',procesando:'Enviando aviso…',aceptado:'Aceptado por Telegram',fallido:'Falló el aviso',incierto:'Resultado incierto (revise antes de reenviar)',sin_vinculo:'Socio sin Telegram vinculado',desconocido:'—'};
const ENT_TXT={borrador:'Borrador (no publicado)',publicada:'Publicada',revocada:'Acceso revocado'};
const fms=v=>v?new Date(v).toLocaleString('es-HN',{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'}):'—';
let entCtx=null;
async function abrirEntregas(compraId){
  if(!document.getElementById('crEntCss')){const st=document.createElement('style');st.id='crEntCss';st.textContent='.cr-sheet [data-rid] .cr-field{display:grid;gap:6px;min-width:0}.cr-sheet [data-rid] input:not([type=checkbox]),.cr-sheet [data-rid] textarea,.cr-sheet [data-rid] select{box-sizing:border-box;width:100%;max-width:100%}.cr-sheet [data-rid] label{line-height:1.4}';document.head.appendChild(st)}
  const m=modal('<div class="cr-empty">Cargando entregas…</div>',{wide:true});
  entCtx={compraId,m,forms:{}};
  await pintarEntregas();
}
async function pintarEntregas(){
  const {compraId,m}=entCtx;const sheet=m.querySelector('.cr-sheet');
  let d;try{d=await api('GET','entregas',undefined,{compraId})}catch(e){sheet.innerHTML=`<div class="cr-empty">${esc(e.message)}</div>`;return}
  entCtx.d=d;
  sheet.innerHTML=`<div class="cr-row" style="align-items:flex-start"><div><h3 style="margin:0">📦 Entregas · Pedido #${esc(d.ref)}</h3>
      <small>Socio <b>${esc(d.socio)}</b>${d.socioVerificado?'':' ⚠️ no verificado'} · Cliente <b>${esc(d.cliente||'—')}</b> · Telegram: <b>${d.telegram==='vinculado'?'vinculado':'sin vincular'}</b></small><br>
      <small>Pago: ${money(d.pago.monto)}${d.pago.banco?' · '+esc(d.pago.banco):''} · ${d.pago.comprobante?'comprobante adjunto':'sin comprobante'}${d.pago.revision?` · <b style="color:#b45309">⚠️ posible comprobante repetido (#${esc(d.pago.revision.pedidoRelacionadoRef||'')})</b>`:''}</small></div>
      <div style="text-align:right"><span class="cr-badge">${esc(d.resumen.texto)}</span><br><button class="cr-btn ghost" data-ent="cerrar" style="margin-top:6px">Cerrar</button></div></div>
    <p style="font-size:13px;color:#475467;margin:8px 0 14px">Marcar “entregado” no ocurre al aprobar el pago ni al enviar un mensaje: solo cuando la entrega se publica y queda accesible al socio. Cada servicio se entrega por separado.</p>
    <div style="display:grid;gap:12px">${d.renglones.map(renglonEntregaHtml).join('')}</div>`;
  sheet.onclick=onEntregaClick;sheet.oninput=onEntregaInput;
}
function renglonEntregaHtml(r){
  const e=r.entrega,f=entCtx.forms[r.renglonId];
  const datos=[r.datos.dispositivo,r.datos.correo,r.datos.detalle,r.datos.notas?'Nota: '+r.datos.notas:''].filter(Boolean).join(' · ');
  return `<article class="cr-card" data-rid="${esc(r.renglonId)}" style="padding:14px">
    <div class="cr-row"><div><b>${esc(r.servicio)}</b><br><small>Para ${esc(r.clienteNombre||'—')}${datos?' · '+esc(datos):''}</small></div>
      <span class="cr-badge ${e?.estado==='publicada'?'':'paused'}">${e?esc(ENT_TXT[e.estado]||e.estado)+(e.version?` · v${e.version}`:''):'Sin entrega'}</span></div>
    ${e?`<small style="display:block;margin-top:6px;color:#475467">${e.publicadaAt?`Publicada ${fms(e.publicadaAt)}`:''}${e.actualizadaAt&&e.actualizadaAt!==e.publicadaAt?` · Actualizada ${fms(e.actualizadaAt)}`:''}${e.fichaResumen?` · Ficha: ${esc(e.fichaResumen.cliente)} / ${esc(e.fichaResumen.plataforma)}${e.fichaResumen.vence?' · vence '+esc(e.fichaResumen.vence):''}`:' · Sin ficha vinculada'} · ${e.visto?`Visto por el socio (v${e.visto.version}) ${fms(e.visto.at)}`:'Sin abrir por el socio'}${e.revocadaAt?` · Revocada: ${esc(e.motivoRevocacion)}`:''}</small>
      ${e.avisos?.length?`<div style="margin-top:6px;font-size:12.5px">${e.avisos.map(a=>`<span class="cr-badge ${a.estado==='aceptado'?'':'paused'}" style="margin:2px 4px 0 0">v${a.version}${a.reenvio?' reenvío '+a.reenvio:''}: ${esc(AVISO_TXT[a.estado]||a.estado)}${a.error?' · '+esc(a.error):''}</span>`).join('')}</div>`:''}`:''}
    <div class="cr-row" style="margin-top:10px;justify-content:flex-start;gap:8px;flex-wrap:wrap">
      ${!f?(e?.estado==='publicada'?`<button class="cr-btn" data-ent="form" data-modo="actualizar">Actualizar entrega</button><button class="cr-btn ghost" data-ent="reenviar">Reenviar aviso de Telegram</button><button class="cr-btn ghost" data-ent="revocar" style="color:#b42318">Revocar acceso a esta entrega</button>`
        :`<button class="cr-btn red" data-ent="form" data-modo="publicar">${e?.estado==='borrador'?'Continuar borrador':e?.estado==='revocada'?'Volver a publicar':'Preparar entrega'}</button>`):''}
    </div>${f?formEntregaHtml(r,f):''}</article>`;
}
function formEntregaHtml(r,f){
  const e=r.entrega;
  return `<div style="border-top:1px solid #e4e7ec;margin-top:12px;padding-top:12px;display:grid;gap:10px">
    <label class="cr-field">1. Vincular ficha de Sublichat (solo servicios de este socio)<input data-ef="q" value="${esc(f.q||'')}" placeholder="Buscar cliente por nombre o teléfono"></label>
    <div data-ef-res>${fichasHtml(f)}</div>
    ${f.ficha?`<div class="cr-status good">Ficha elegida: <b>${esc(f.fichaTxt||'')}</b> <button class="cr-btn ghost" data-ent="sin-ficha">Quitar</button></div>`:'<small>Sin ficha: el socio verá la entrega sin portal.</small>'}
    <label style="display:flex;gap:8px;align-items:center"><input type="checkbox" data-ef="portalAutorizado" ${f.portalAutorizado?'checked':''} ${f.ficha?'':'disabled'}> Mostrar “Abrir portal del cliente” al socio (solo esta persona/servicio)</label>
    <label class="cr-field">Código del portal o de activación (opcional · se guarda cifrado)<input type="password" autocomplete="off" data-ef="codigo" value="${esc(f.codigo||'')}" placeholder="${e?.codigoGuardado?'Código guardado · escriba solo para cambiarlo':'Solo si un admin lo registra'}"></label>
    ${e?.codigoGuardado?`<label style="display:flex;gap:8px;align-items:center"><input type="checkbox" data-ef="quitarCodigo" ${f.quitarCodigo?'checked':''}> Quitar el código guardado</label>`:''}
    <label style="display:flex;gap:8px;align-items:center"><input type="checkbox" data-ef="codigoAutorizado" ${f.codigoAutorizado?'checked':''}> Autorizar que el socio vea/copie el código</label>
    <label class="cr-field">Nota para el socio<textarea data-ef="notaSocio" maxlength="600" rows="2">${esc(f.notaSocio||'')}</textarea></label>
    <label class="cr-field">Mensaje para el cliente (el socio lo copia)<textarea data-ef="mensajeCliente" maxlength="1500" rows="3">${esc(f.mensajeCliente||'')}</textarea></label>
    ${f.modo==='actualizar'?`<label class="cr-field">Motivo de la actualización *<input data-ef="motivo" maxlength="300" value="${esc(f.motivo||'')}" placeholder="Ej. Cambio de clave"></label><label style="display:flex;gap:8px;align-items:center"><input type="checkbox" data-ef="avisar" ${f.avisar!==false?'checked':''}> Avisar del cambio por Telegram (el aviso no lleva códigos)</label>`:''}
    ${f.preview?previewHtml(f.preview):''}
    <div class="cr-row" style="justify-content:flex-end;gap:8px;flex-wrap:wrap">
      <button class="cr-btn ghost" data-ent="cancelar">Cancelar</button>
      ${f.modo!=='actualizar'?'<button class="cr-btn ghost" data-ent="borrador">Guardar borrador</button>':''}
      <button class="cr-btn ghost" data-ent="revisar">Revisar</button>
      <button class="cr-btn red" data-ent="publicar" ${f.preview?'':'disabled title="Revise primero la vista previa"'}>${f.modo==='actualizar'?'Actualizar entrega':'Publicar entrega al socio'}</button>
    </div><div data-ef-msg></div></div>`;
}
function fichasHtml(f){
  if(!f.resultados)return'';
  if(!f.resultados.length)return'<small>Sin fichas de este socio con ese nombre.</small>';
  return `<div style="display:grid;gap:6px;max-height:220px;overflow:auto">${f.resultados.map(c=>c.servicios.map(s=>`<button class="cr-btn ghost" style="text-align:left;justify-content:flex-start" data-ent="elegir-ficha" data-cid="${esc(c.clienteId)}" data-sid="${esc(s.compraId)}" data-ix="${s.index}" data-txt="${esc(`${c.nombre} · ${s.plataforma}${s.vence?' · vence '+s.vence:''}`)}">${esc(c.nombre)} <small>${esc(c.telefono)}</small> · <b>${esc(s.plataforma)}</b>${s.vence?' · vence '+esc(s.vence):''}${s.beneficiario!=='titular'?' · '+esc(s.beneficiario):''}</button>`).join('')).join('')}</div>`;
}
function previewHtml(p){
  return `<div style="border:1px solid #d0d5dd;border-radius:12px;padding:12px;background:#f9fafb;font-size:13px;line-height:1.5">
    <b>Vista previa · lo que verá ${esc(p.socio.nombre)}</b><br>Pedido ${esc(p.verSocio.pedido)} · ${esc(p.verSocio.cliente)} · ${esc(p.verSocio.servicio)}${p.verSocio.vence?' · vence '+esc(p.verSocio.vence):''}<br>
    Portal: ${esc(p.verSocio.portal)}<br>Código: ${esc(p.verSocio.codigo)}${p.verSocio.nota?`<br>Nota: ${esc(p.verSocio.nota)}`:''}${p.verSocio.mensajeCliente?`<br>Mensaje al cliente: ${esc(p.verSocio.mensajeCliente)}`:''}
    <br><b>Telegram:</b> ${p.telegram?`<span style="white-space:pre-wrap;display:block;background:#1f2937;color:#fff;border-radius:10px;padding:8px;margin-top:4px">${esc(p.telegram.replace(/<[^>]+>/g,''))}\n[Ver entrega en mi panel]</span>`:'sin Telegram vinculado: la entrega queda solo en el panel.'}</div>`;
}
function formPayload(rid,accion){
  const f=entCtx.forms[rid];
  return {accion,compraId:entCtx.compraId,renglonId:rid,opId:f.opId,ficha:f.ficha||null,portalAutorizado:!!f.portalAutorizado,codigo:f.codigo||'',quitarCodigo:!!f.quitarCodigo,codigoAutorizado:!!f.codigoAutorizado,notaSocio:f.notaSocio||'',mensajeCliente:f.mensajeCliente||'',motivo:f.motivo||'',avisar:f.avisar!==false};
}
let fichaTimer=null;
function onEntregaInput(ev){
  const art=ev.target.closest('[data-rid]'),k=ev.target.dataset.ef;if(!art||!k)return;
  const rid=art.dataset.rid,f=entCtx.forms[rid];if(!f)return;
  f[k]=ev.target.type==='checkbox'?ev.target.checked:ev.target.value;
  if(k!=='q'&&f.preview){f.preview=null;const b=art.querySelector('[data-ent="publicar"]');if(b){b.disabled=true;b.title='Revise primero la vista previa'}}
  if(k==='q'){clearTimeout(fichaTimer);fichaTimer=setTimeout(async()=>{try{const d=await api('GET','entregas/fichas',undefined,{q:f.q,socio:entCtx.d.socio});f.resultados=d.items||[]}catch(e){f.resultados=[]}const box=art.querySelector('[data-ef-res]');if(box)box.innerHTML=fichasHtml(f)},350)}
}
async function onEntregaClick(ev){
  const b=ev.target.closest('[data-ent]');if(!b)return;
  const a=b.dataset.ent,art=b.closest('[data-rid]'),rid=art?.dataset.rid,r=entCtx.d?.renglones.find(x=>x.renglonId===rid);
  const msg=t=>{const el=art?.querySelector('[data-ef-msg]');if(el)el.innerHTML=t};
  if(a==='cerrar'){entCtx.m._modalClose();loadPedidos(true);return}
  if(a==='form'){const e=r.entrega,fp=r.fichaPagada;entCtx.forms[rid]={modo:b.dataset.modo,opId:opNuevo(),ficha:e?.ficha?{clienteId:e.ficha.clienteId,servicioCompraId:e.ficha.servicioCompraId,servicioIndex:e.ficha.servicioIndex}:fp?{clienteId:fp.clienteId,servicioCompraId:fp.servicioCompraId}:null,fichaTxt:e?.fichaResumen?`${e.fichaResumen.cliente} · ${e.fichaResumen.plataforma}`:fp?`${fp.clienteNombre} · ${fp.plataforma} (amarrada al pago del socio)`:'',portalAutorizado:!!e?.portalAutorizado,codigoAutorizado:!!e?.codigoAutorizado,notaSocio:e?.notaSocio||'',mensajeCliente:e?.mensajeCliente||'',q:''};return rePintarRenglon(rid)}
  if(a==='cancelar'){delete entCtx.forms[rid];return rePintarRenglon(rid)}
  if(a==='elegir-ficha'){Object.assign(entCtx.forms[rid],{ficha:{clienteId:b.dataset.cid,servicioCompraId:b.dataset.sid,servicioIndex:Number(b.dataset.ix)},fichaTxt:b.dataset.txt,resultados:null,preview:null});return rePintarRenglon(rid)}
  if(a==='sin-ficha'){Object.assign(entCtx.forms[rid],{ficha:null,fichaTxt:'',portalAutorizado:false,preview:null});return rePintarRenglon(rid)}
  if(a==='revisar'){b.disabled=true;try{const f=entCtx.forms[rid];f.preview=await api('POST','entregas/vista-previa',formPayload(rid,f.modo));rePintarRenglon(rid)}catch(e){b.disabled=false;msg(`<div class="cr-status bad">${esc(e.message)}</div>`)}return}
  if(a==='borrador'||a==='publicar'){
    const f=entCtx.forms[rid],accion=a==='borrador'?'borrador':f.modo;
    if(accion==='actualizar'&&!String(f.motivo||'').trim()){msg('<div class="cr-status bad">Escriba el motivo de la actualización.</div>');return}
    b.disabled=true;const old=b.textContent;b.textContent=a==='borrador'?'Guardando…':'Publicando…';
    try{const r2=await api('POST','entregas/guardar',formPayload(rid,accion));delete entCtx.forms[rid];await pintarEntregas();status(a==='borrador'?'Borrador guardado: no se publicó ni avisó.':`✅ Entrega ${accion==='actualizar'?'actualizada':'publicada'} (v${r2.version}).${r2.aviso==='sin_vinculo'?' El socio no tiene Telegram: la verá en su panel.':' Aviso de Telegram en cola.'}`,'good')}
    catch(e){b.disabled=false;b.textContent=old;msg(`<div class="cr-status bad">${esc(({ya_publicada_use_actualizar:'Ya está publicada: use “Actualizar entrega”.',ficha_de_otro_socio:'Esa ficha no es de este socio.',cifrado_no_configurado:'Falta ENTREGAS_CODIGOS_KEY en Render: no se puede guardar códigos.',pedido_cancelado:'El pedido está cancelado.'})[e.data?.error]||e.message)}</div>`)}
    return}
  if(a==='reenviar'){if(!confirm('¿Reenviar el aviso de Telegram? No crea otra compra ni cambia la fecha original.'))return;b.disabled=true;try{await api('POST',`entregas/${r.entrega.id}/reenviar`,{opId:opNuevo()});await pintarEntregas()}catch(e){b.disabled=false;alert(({socio_sin_telegram:'El socio no tiene Telegram vinculado.'})[e.data?.error]||e.message)}return}
  if(a==='revocar'){const motivo=prompt('Motivo para revocar el acceso (queda en el historial). No cancela el servicio real y no borra mensajes ya enviados:');if(!motivo||!motivo.trim())return;try{await api('POST',`entregas/${r.entrega.id}/revocar`,{motivo});await pintarEntregas()}catch(e){alert(e.message)}}
}
function rePintarRenglon(rid){const art=entCtx.m.querySelector(`[data-rid="${CSS.escape(rid)}"]`);const r=entCtx.d.renglones.find(x=>x.renglonId===rid);if(art&&r){const t=document.createElement('div');t.innerHTML=renglonEntregaHtml(r);art.replaceWith(t.firstElementChild)}}

/* ── Buzón (consultas de socios, dos vías con Telegram) ── */
async function loadBuzon(force){
  if(state.buzon&&!force)return renderBuzon();
  const b=$('#revBody');if(b)b.innerHTML='<div class="cr-empty">Cargando consultas…</div>';
  try{const d=await api('GET','consultas',undefined,{limit:150});state.buzon=d.items||[];renderBuzon()}catch(e){if(b)b.innerHTML=`<div class="cr-empty">${esc(e.message)}</div>`}
}
const CONS_EST=[['todas','Todas'],['abierta','Abiertas'],['en_atencion','En atención'],['esperando_socio','Esperando al socio'],['resuelta','Resueltas']];
function renderBuzon(){
  const b=$('#revBody');if(!state.buzon)return loadBuzon();
  const fil=state.buzonFiltro||'todas',list=state.buzon.filter(c=>fil==='todas'||c.estado===fil),sel=state.buzon.find(c=>c.id===state.buzonSel);
  b.innerHTML=`<div class="cr-tools" style="flex-wrap:wrap"><div><b>Buzón de socios</b><br><small>Mismo hilo en web y Telegram. Las notas internas nunca se envían al socio.</small></div><button class="cr-btn ghost" id="bzReload">Actualizar</button></div>
    <div class="cr-tabs" style="margin-bottom:12px;overflow:auto">${CONS_EST.map(([k,l])=>`<button class="cr-tab ${fil===k?'on':''}" data-bzf="${k}">${l}</button>`).join('')}</div>
    <div style="display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1.4fr);gap:12px">
      <div style="display:grid;gap:8px;align-content:start">${list.map(c=>`<button class="cr-card" data-bzsel="${esc(c.id)}" style="text-align:left;cursor:pointer;${c.id===state.buzonSel?'outline:2px solid #E2231A':''}"><b>#${esc(c.numero)} · ${esc(c.asunto)}</b>${c.noLeidasEquipo?` <span class="cr-badge">${c.noLeidasEquipo} nuevo(s)</span>`:''}<br><small>${esc(c.socio)} · ${esc(c.estadoLabel)}${c.pedidoRef?' · Pedido #'+esc(c.pedidoRef):''} · ${fms(c.updatedAt)}</small></button>`).join('')||'<div class="cr-empty">Sin consultas.</div>'}</div>
      <div>${sel?hiloAdminHtml(sel):'<div class="cr-empty">Elija una consulta.</div>'}</div></div>`;
  $('#bzReload').onclick=()=>loadBuzon(true);
  b.querySelectorAll('[data-bzf]').forEach(x=>x.onclick=()=>{state.buzonFiltro=x.dataset.bzf;renderBuzon()});
  b.querySelectorAll('[data-bzsel]').forEach(x=>x.onclick=()=>{state.buzonSel=x.dataset.bzsel;state.bzOp=opNuevo();renderBuzon()});
  const send=$('#bzSend');if(send)send.onclick=async()=>{const t=$('#bzTxt').value.trim();if(!t)return;send.disabled=true;try{const r=await api('POST',`consultas/${sel.id}/mensajes`,{texto:t,interna:$('#bzInt').checked,opId:state.bzOp});state.bzOp=opNuevo();status(r.telegram==='sin_vinculo'&&!$('#bzInt').checked?'Respuesta guardada. El socio no tiene Telegram: la verá en su panel.':'Respuesta guardada.','good');await loadBuzon(true)}catch(e){send.disabled=false;alert(e.message)}};
  b.querySelectorAll('[data-ver-pedido]').forEach(x=>x.onclick=()=>abrirEntregas(x.dataset.verPedido));
  const est=$('#bzEstado');if(est)est.onchange=async()=>{try{await api('PATCH',`consultas/${sel.id}/estado`,{estado:est.value});await loadBuzon(true)}catch(e){alert(e.message)}};
}
function hiloAdminHtml(c){
  return `<article class="cr-card"><div class="cr-row"><div><b>#${esc(c.numero)} · ${esc(c.asunto)}</b><br><small>${esc(c.socio)} → ${esc(c.destino)}${c.pedidoRef?` · Pedido #${esc(c.pedidoRef)} <button class="cr-btn ghost" data-ver-pedido="${esc(c.pedidoId)}">Ver entregas</button>`:''}</small></div>
    <label class="cr-field" style="min-width:180px">Estado<select id="bzEstado">${CONS_EST.slice(1).map(([k,l])=>`<option value="${k}" ${c.estado===k?'selected':''}>${l}</option>`).join('')}</select></label></div>
    <div style="display:grid;gap:8px;margin:12px 0;max-height:46vh;overflow:auto">${c.mensajes.map(m=>`<div style="padding:10px 12px;border-radius:12px;${m.interna?'background:#fffbeb;border:1px dashed #f59e0b':m.autor==='equipo'?'background:#f1f5f9;margin-left:24px':'background:#fff;border:1px solid #e4e7ec;margin-right:24px'}"><small><b>${m.interna?'🔒 Nota interna · ':''}${esc(m.nombre||(m.autor==='equipo'?'Equipo':'Socio'))}</b> · ${m.origen==='telegram'?'Telegram':'Web'} · ${fms(Date.parse(m.at))}</small><div style="white-space:pre-wrap;margin-top:4px">${esc(m.texto)}</div></div>`).join('')}</div>
    <label class="cr-field">Responder<textarea id="bzTxt" rows="3" maxlength="3000"></textarea></label>
    <div class="cr-row"><label style="display:flex;gap:8px;align-items:center"><input type="checkbox" id="bzInt"> Nota interna (no se envía al socio)</label><button class="cr-btn red" id="bzSend">Enviar</button></div></article>`;
}

/* ── Historial anterior: simular → importar en silencio → validar muestra → habilitar / revertir ── */
async function renderHistorial(){
  const b=$('#revBody');
  b.innerHTML=`<div class="cr-tools" style="flex-wrap:wrap"><div><b>Entregas antiguas</b><br><small>Primero simule. La importación no avisa a nadie, no cambia fechas originales y no suma ventas ni ingresos. Queda oculta hasta que la habilite.</small></div><button class="cr-btn red" id="hsSim">Simular</button></div><div id="hsOut"></div><h4 style="margin:18px 0 8px">Lotes importados</h4><div id="hsLotes"><div class="cr-empty">Cargando…</div></div>`;
  $('#hsSim').onclick=simularHistorial;
  try{const d=await api('GET','entregas/historico/lotes');$('#hsLotes').innerHTML=(d.items||[]).map(l=>`<div class="cr-card" style="margin-bottom:8px"><div class="cr-row"><div><b>${esc(l.loteId)}</b> · ${l.total} registro(s) · ${l.socios.length?'Socios: '+esc(l.socios.join(', ')):'Todos los socios'}<br><small>${esc(l.creadoPor||'')} · ${fms(l.createdAt)} · ${l.revertido?'Revertido':l.habilitado?'Visible para los socios':'Oculto (validar muestra)'}</small></div><div>${!l.revertido&&!l.habilitado?`<button class="cr-btn" data-hs="habilitar" data-lote="${esc(l.loteId)}">Habilitar</button>`:''}${!l.revertido?`<button class="cr-btn ghost" data-hs="revertir" data-lote="${esc(l.loteId)}">Revertir</button>`:''}</div></div></div>`).join('')||'<div class="cr-empty">Sin lotes.</div>';
    b.querySelectorAll('[data-hs]').forEach(x=>x.onclick=async()=>{if(!confirm(x.dataset.hs==='revertir'?'¿Revertir? Se borran solo los registros importados por este lote; la fuente original no se toca.':'¿Mostrar este lote a los socios? No envía avisos.'))return;try{await api('POST',`entregas/historico/${x.dataset.lote}/${x.dataset.hs}`,{});renderHistorial()}catch(e){alert(e.message)}})}
  catch(e){$('#hsLotes').innerHTML=`<div class="cr-empty">${esc(e.message)}</div>`}
}
async function simularHistorial(){
  const out=$('#hsOut');out.innerHTML='<div class="cr-empty">Simulando…</div>';
  try{const d=await api('GET','entregas/historico/simular');
    const fila=(t,n)=>`<div class="order-metric">${t}<b>${n}</b></div>`;
    const muestra=(arr)=>arr.length?`<ol style="font-size:13px;padding-left:18px">${arr.map(x=>`<li>#${esc(x.ref)} · ${esc(x.socio)} · ${esc(x.cliente||'—')} · ${esc(x.servicios.join(' + '))} · ${esc(x.fecha)}${x.motivo?' · '+esc(x.motivo):''}${x.historicoAnterior?' · Histórico anterior (mezclaba clientes)':''}</li>`).join('')}</ol>`:'<small>—</small>';
    out.innerHTML=`<div class="order-metrics" style="flex-wrap:wrap">${fila('Encontradas',d.encontradas)}${fila('Vinculables',d.vinculables)}${fila('Ya importadas',d.duplicadas)}${fila('Incompletas',d.incompletas)}${fila('Sin socio verificable',d.sinSocio)}${fila('Cliente ambiguo',d.ambiguas)}${fila('Sin fecha confirmada',d.sinFecha)}</div>
      <p><b>Muestra vinculable</b></p>${muestra(d.muestras.vinculables)}<p><b>Incompletas</b> (se importan como “Histórico incompleto”)</p>${muestra(d.muestras.incompletas)}<p><b>Quedan en revisión administrativa</b> (no se muestran a ningún socio)</p>${muestra(d.muestras.revision)}
      <div class="cr-row" style="gap:8px;flex-wrap:wrap;justify-content:flex-start"><label class="cr-field">Importar muestra de un socio<select id="hsSocio">${Object.entries(d.porSocio).map(([s,n])=>`<option value="${esc(s)}">${esc(s)} · ${n}</option>`).join('')}</select></label><button class="cr-btn" id="hsUno">Importar ese socio</button><button class="cr-btn ghost" id="hsTodo">Importar todo</button></div>`;
    const imp=async(socios)=>{if(!confirm('Importar en silencio (oculto hasta habilitar). ¿Continuar?'))return;try{const r=await api('POST','entregas/historico/importar',{confirmar:true,socios});status(`Lote ${r.loteId}: ${r.importadas} registro(s) importados y ocultos. Revise y habilite.`,'good');renderHistorial()}catch(e){alert(e.message)}};
    $('#hsUno').onclick=()=>imp([$('#hsSocio').value]);$('#hsTodo').onclick=()=>imp([]);
  }catch(e){out.innerHTML=`<div class="cr-empty">${esc(e.message)}</div>`}
}
window.__subliAbrirEntregas=(id)=>{if(id)abrirEntregas(id)};

/* ═══════════ util modal ═══════════ */
function modal(innerHtml,opts={}){
  const overlay=document.createElement('div');
  overlay.className=`cr-modal${opts.className?' '+opts.className:''}`;overlay.style.cssText='position:fixed;inset:0;background:rgba(15,23,42,.48);display:flex;align-items:center;justify-content:center;z-index:9999;padding:16px';
  const sheetClass=`cr-sheet${opts.sheetClass?' '+opts.sheetClass:''}`;
  const widthStyle=opts.wide?'max-width:1180px;':'max-width:460px;';
  overlay.innerHTML=`<div class="${sheetClass}" style="background:#fff;border-radius:18px;padding:20px;${widthStyle}width:100%;max-height:85vh;overflow:auto">${innerHtml}</div>`;
  const close=()=>{try{overlay._modalCleanup?.()}catch(_){ }document.removeEventListener('keydown',onKey);overlay.remove()};
  const onKey=e=>{if(e.key==='Escape'&&overlay.isConnected)close()};
  overlay._modalClose=close;
  overlay.addEventListener('click',e=>{if(e.target===overlay)close()});
  document.addEventListener('keydown',onKey);
  document.body.appendChild(overlay);
  return overlay;
}

/* ═══════════ init ═══════════ */
function init(){
  shell();
  const screen=document.getElementById('screen-revendedores');
  if(screen?.classList.contains('active')) loadPrecios();
}
window.SublichatRevendedores={open:()=>{ shell(); loadPrecios(); },reload:()=>{ state.precios=null; state.vendedores=null; state.clientes=null; state.recompensas=null; state.promociones=null; state.pedidos=null; state.pub=null; state.buzon=null; render(); }};
document.addEventListener('DOMContentLoaded',init);
new MutationObserver(()=>{
  const s=document.getElementById('screen-revendedores');
  if(s?.classList.contains('active')){ shell(); if(!state.precios) loadPrecios(); }
}).observe(document.documentElement,{subtree:true,attributes:true,attributeFilter:['class']});
})();
