
const crypto = require("crypto");
/* ════════════════════════════════════════════════════════════════
   server_api.js  ·  API del PANEL DE REVENDEDORES (independiente)
   ────────────────────────────────────────────────────────────────
   Arranca SOLO la API REST del panel. NO inicia el polling del bot
   (reusa Firebase de index_01_core, donde el bot está en polling:false).
   Pensado para correr en un Web Service de Render aparte del Worker.

   Start command en Render:  node server_api.js

   Variables de entorno necesarias (las mismas del bot + las del panel):
     FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL, FIREBASE_PRIVATE_KEY
     BOT_TOKEN            (el mismo; aquí NO hace polling, solo evita warnings)
     JWT_SECRET           (una frase larga aleatoria)
     ADMIN_USER / ADMIN_PASSWORD                 (Sublicuentas)
     RELOJES_ADMIN_USER / RELOJES_ADMIN_PASSWORD (opcional)
     GEISELL_ADMIN_USER / GEISELL_ADMIN_PASSWORD (opcional)
     MAGDIEL_ADMIN_USER / MAGDIEL_ADMIN_PASSWORD (opcional)
     CORS_ALLOWED_ORIGINS (orígenes web permitidos separados por coma)
     STORAGE_BUCKET       (opcional, ej. tu-proyecto.firebasestorage.app o tu-proyecto.appspot.com)
   ════════════════════════════════════════════════════════════════ */

const express = require("express");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

// ✅ Usar módulo de auth compartido (elimina duplicación con index_08_api.js)
const {
  revAuth, revAdminAuth, revParseFecha, revDiasRest, revFechaISO, revParseFechaInput,
  getJwtSecret, revLoginIpLimiter, createRevLoginHandler, esRevSoloCatalogo, capacidadesRevendedor,
} = require("./index_09_api_auth");

const {
  adminPermission, adminAnyPermission, buildCorsOptions, apiSecurityHeaders,
  createAdminAuditMiddleware, createAdminLogoutHandler, createAdminMeHandler,
  adminScopeProfile, isFullAdmin,
} = require("./index_25_api_security");

// Reusa Firebase ya inicializado en el core (no arranca el bot)
const { db, PORT, bot, SUPER_ADMIN, PLATAFORMAS } = require("./index_01_core");
const { enqueueTelegramJob, isUnauthorizedTelegramError } = require("./index_22_telegram_outbox");
const { registrarEventoSorteosSeguro } = require("./index_14_sorteos");
const {
  obtenerCatalogoSocio,
  buscarProductoCatalogo,
  catalogoPlano,
} = require("./index_15_catalogo_socios");
const {
  normVendedor,
  vendedorEfectivoServicio,
  heredarVendedorServicios,
  camposResumenVendedores,
  servicioPerteneceAVendedor,
  filtrarClienteParaVendedor,
  clientePublicoPanel,
} = require("./index_17_vendedores_servicio");
const admin = require("firebase-admin");
const CS = require("./lib_compra_socios"); // Oct-2026 · pedido v2 del Panel de Socios
const STORAGE_BUCKET_CANDIDATES = Array.from(new Set([
  process.env.STORAGE_BUCKET,
  process.env.FIREBASE_STORAGE_BUCKET,
  process.env.GCLOUD_STORAGE_BUCKET,
  process.env.FIREBASE_PROJECT_ID ? `${process.env.FIREBASE_PROJECT_ID}.appspot.com` : "",
  process.env.FIREBASE_PROJECT_ID ? `${process.env.FIREBASE_PROJECT_ID}.firebasestorage.app` : "",
].map((s) => String(s || "").trim()).filter(Boolean)));
const STORAGE_BUCKET = STORAGE_BUCKET_CANDIDATES[0] || "";

// ✅ Sin fallback inseguro: si falta JWT_SECRET, el proceso no arranca (ver index_09_api_auth.js).
const JWT_SECRET = getJwtSecret();

const app = express();
const corsOptions = buildCorsOptions();
app.use(cors(corsOptions));
app.use(apiSecurityHeaders);
app.use(express.json({ limit: "15mb" }));
// La auditoría se registra después de que revAdminAuth identifique al actor.
app.use("/rev/admin", createAdminAuditMiddleware({ db, source: "Panel Socios API" }));

// keepalive / health (para que Render lo mantenga vivo)
const PANEL_API_VERSION = require("./server_api_version"); // R196i (antes socios-20260928-admin-acl-v3)
app.get("/", (_req, res) => res.type("text/plain").send(`Sublicuentas Panel API OK ${PANEL_API_VERSION}`));
app.get("/rev/ping", (_req, res) => res.json({ v: PANEL_API_VERSION, ticketsBridge: true, telegramOutbox: true, gemini: !!process.env.GEMINI_API_KEY, anthropic: !!process.env.ANTHROPIC_API_KEY, storageBuckets: STORAGE_BUCKET_CANDIDATES }));
app.get("/health", (_req, res) => res.json({ ok: true, version: PANEL_API_VERSION, ts: Date.now() }));

// ── perfil/permisos vivos del socio ──
const _revLiveCache = new Map();
function revNormKey(v) {
  return normVendedor(String(v || "")) === "geissel" ? "geisell" : normVendedor(String(v || ""));
}
async function revLiveProfile(tokenRev = {}, maxAgeMs = 30000) {
  const id = String(tokenRev?.id || "").trim();
  const cacheKey = id || revNormKey(tokenRev?.nombre_norm || tokenRev?.nombre || "");
  const now = Date.now();
  const cached = cacheKey ? _revLiveCache.get(cacheKey) : null;
  if (cached && now - cached.at < maxAgeMs) return cached.value;
  let data = {};
  try {
    if (id) {
      const snap = await db.collection("revendedores").doc(id).get();
      if (snap.exists) data = { id: snap.id, ...snap.data() };
    }
    if (!Object.keys(data).length) {
      const key = revNormKey(tokenRev?.nombre_norm || tokenRev?.nombre || "");
      if (key) {
        const snap = await db.collection("revendedores").where("nombre_norm", "==", key).limit(1).get();
        if (!snap.empty) data = { id: snap.docs[0].id, ...snap.docs[0].data() };
      }
    }
  } catch (e) {
    console.error("revLiveProfile", e?.message || e);
  }
  const merged = { ...tokenRev, ...data };
  const capabilities = capacidadesRevendedor(merged);
  const value = {
    ...merged,
    nombre_norm: revNormKey(merged.nombre_norm || merged.nombre || tokenRev?.nombre_norm || ""),
    capabilities,
    permisos: capabilities,
    soloCatalogo: !capabilities.canBuy,
    sinCompras: !capabilities.canBuy,
    tarifaId: String(merged.tarifaId || merged.tarifa_id || tokenRev?.tarifaId || "general"),
    priceTier: String(merged.tarifaId || merged.tarifa_id || tokenRev?.tarifaId || "general"),
  };
  if (cacheKey) _revLiveCache.set(cacheKey, { at: now, value });
  return value;
}
function revCap(profile, key, fallback = true) {
  const caps = profile?.capabilities || profile?.permisos || {};
  return typeof caps[key] === "boolean" ? caps[key] : fallback;
}
function revMoneyNumber(v) {
  if (v == null || v === "") return 0;
  if (typeof v === "number") return Number.isFinite(v) ? v : 0;
  let s = String(v).replace(/[^\d,.-]/g, "").trim();
  if (!s) return 0;
  const c = s.lastIndexOf(","), d = s.lastIndexOf(".");
  if (c > -1 && d > -1) s = c > d ? s.replace(/\./g, "").replace(",", ".") : s.replace(/,/g, "");
  else if (c > -1) s = s.length - c - 1 === 2 ? s.replace(",", ".") : s.replace(/,/g, "");
  else if (d > -1 && s.length - d - 1 !== 2) s = s.replace(/\./g, "");
  const n = Number.parseFloat(s);
  return Number.isFinite(n) ? n : 0;
}
function revDateMs(v) {
  if (!v) return 0;
  if (typeof v === "number") return v < 1e12 ? v * 1000 : v;
  if (typeof v === "object") {
    if (typeof v.toDate === "function") return v.toDate().getTime();
    if (v._seconds) return Number(v._seconds) * 1000;
    if (v.seconds) return Number(v.seconds) * 1000;
  }
  const d = new Date(v);
  return Number.isNaN(d.getTime()) ? 0 : d.getTime();
}
function revCanonInventory(v) {
  const raw = String(v || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
  const key = raw.replace(/[^a-z0-9]/g, "");
  const aliases = {
    netflixpremium:"netflix", netflix:"netflix", netflixvip:"vipnetflix", vipnetflix:"vipnetflix",
    disneyplus:"disney", disneypremium:"disney", disneystandard:"disney", disney:"disney",
    hbomax:"hbomax", max:"hbomax", hbo:"hbomax", primevideo:"primevideo", prime:"primevideo",
    crunchyroll:"crunchyroll", crunchy:"crunchyroll", paramountplus:"paramount", paramount:"paramount",
    vix:"vix", vikirakuten:"viki", viki:"viki", universalplus:"universal", universal:"universal",
    spotify:"spotify", youtube:"youtube", youtubepremium:"youtube", canva:"canva", gemini:"gemini",
    chatgpt:"chatgpt", duolingo:"duolingo", office365:"office", microsoft365:"office", office:"office",
    office2021:"office2021", esetnod32:"nod32", nod32:"nod32", stellatv:"stellatv", stella:"stellatv",
    oleadatv:"oleada", oleada:"oleada", latintv:"latintv", liontv:"liontv", iptv:"iptv",
    nanotech:"evoutouch", evoutouch:"evoutouch", icomplay:"icomplay", icomplaymax:"icomplay"
  };
  if (aliases[key]) return aliases[key];
  const stella = key.match(/^stella(?:tv)?([123])/); if (stella) return `stellatv${stella[1]}`;
  const oleada = key.match(/^oleada(?:tv)?([13])/); if (oleada) return `oleadatv${oleada[1]}`;
  const latin = key.match(/^latintv([1234])/); if (latin) return `latintv${latin[1]}`;
  const lion = key.match(/^liontv([1235])/); if (lion) return `liontv${lion[1]}`;
  const nano = key.match(/^(?:nanotech|evoutouch)([1234])$/); if (nano) return `evoutouch${nano[1] === "4" ? "1" : nano[1]}`;
  const icom = key.match(/^icomplay(?:max)?([1357])$/); if (icom) return `icomplay${icom[1]}`;
  return key;
}
function revCatalogInventoryKeys(item = {}) {
  const text = `${item.n || item.nombre || ""} ${item.s || item.variante || ""}`.trim();
  const base = revCanonInventory(text);
  const raw = String(text).toLowerCase();
  const qty = Number((raw.match(/([1-9])\s*(?:dispositivo|pantalla)/) || [])[1] || 0);
  const keys = [];
  if (raw.includes("netflix") && raw.includes("vip")) keys.push("vipnetflix");
  { const ph = require("./lib_hbo_planes").planDesdeNombreProducto(text); if (ph) return [`hbomax_${ph}`]; } // R196v · Standard y Platinum nunca se mezclan
  if (raw.includes("stella") && qty) keys.push(`stellatv${qty}`);
  if (raw.includes("oleada") && qty) keys.push(`oleadatv${qty}`);
  if (raw.includes("latin") && qty) keys.push(`latintv${qty}`);
  if (raw.includes("lion") && qty) keys.push(`liontv${qty}`);
  if ((raw.includes("nanotech") || raw.includes("evoutouch")) && qty) keys.push(`evoutouch${qty}`);
  if (raw.includes("icomplay") && qty) keys.push(`icomplay${qty}`);
  if (base) keys.push(base);
  if (base === "hbomax") keys.push("hbomax_standard", "hbomax_platinum"); // R196v · producto «HBO Max» genérico anterior: suma todo, como hasta hoy
  if (base && /^(stellatv|oleadatv|latintv|liontv|evoutouch|icomplay)\d$/.test(base)) keys.push(base.replace(/\d$/, ""));
  return [...new Set(keys.filter(Boolean))];
}

// ── helpers ──
// Autenticación y fechas compartidas vienen de index_09_api_auth.js.
function revCampoFechaServicio(s) {
  const keys = ["fechaRenovacion", "vencimiento", "vence", "fechaFin"];
  for (const k of keys) if (s && s[k] != null && s[k] !== "") return k;
  return "fechaRenovacion";
}
function revAddMonths(base, months) {
  const d = new Date(base || Date.now());
  d.setHours(12, 0, 0, 0);
  const day = d.getDate();
  d.setMonth(d.getMonth() + Number(months || 1));
  if (d.getDate() !== day) d.setDate(0);
  return d;
}
function revFechaDMY(d) {
  if (!d) return "";
  const x = new Date(d);
  if (Number.isNaN(x.getTime())) return "";
  x.setHours(12, 0, 0, 0);
  return `${String(x.getDate()).padStart(2, "0")}/${String(x.getMonth() + 1).padStart(2, "0")}/${x.getFullYear()}`;
}
async function revResolverSeleccionCliente({ clienteId, socioNorm, seleccion = [] }) {
  const id = String(clienteId || "").trim();
  if (!id) throw Object.assign(new Error("cliente_no_existe"), { status: 404, publicError: "cliente_no_existe" });
  const snap = await db.collection("clientes").doc(id).get();
  if (!snap.exists) throw Object.assign(new Error("cliente_no_existe"), { status: 404, publicError: "cliente_no_existe" });
  const cliente = snap.data() || {};
  const servicios = heredarVendedorServicios(Array.isArray(cliente.servicios) ? cliente.servicios : [], cliente);
  const resueltos = seleccion.map((item) => {
    const compraId = String(item?.compraId || "").trim();
    const ix = compraId
      ? servicios.findIndex((s) => String(s?.compraId || "").trim() === compraId)
      : Number(item?.servicioIndex);
    if (!Number.isInteger(ix) || ix < 0 || ix >= servicios.length) {
      throw Object.assign(new Error("servicio_no_existe"), { status: 400, publicError: "servicio_no_existe" });
    }
    const servicio = servicios[ix] || {};
    if (!servicioPerteneceAVendedor(servicio, cliente, socioNorm)) {
      throw Object.assign(new Error("servicio_no_permitido"), { status: 403, publicError: "servicio_no_permitido" });
    }
    return {
      ...item,
      servicioIndex: ix,
      compraId: String(servicio.compraId || compraId || ""),
      servicio: item?.servicio || servicio.plataforma || servicio.servicio || servicio.nombre || "Servicio",
      precioCliente: revMoneyNumber(servicio.precioCliente ?? servicio.precioVenta ?? servicio.precio ?? servicio.monto ?? 0),
    };
  });
  const vistos = new Set();
  return resueltos.filter((item) => {
    if (vistos.has(item.servicioIndex)) return false;
    vistos.add(item.servicioIndex);
    return true;
  });
}
async function revActualizarFechaCliente({ clienteId, socioNorm, servicioIndex, compraId, nuevaFecha, meses }) {
  const id = (clienteId || "").toString().trim();
  if (!id) return { actualizado: false };
  const ref = db.collection("clientes").doc(id);
  const mutation = await db.runTransaction(async (transaction) => {
    const snap = await transaction.get(ref);
    if (!snap.exists) throw Object.assign(new Error("cliente_no_existe"), { status: 404, publicError: "cliente_no_existe" });
    const c = snap.data() || {};
    const servicios = heredarVendedorServicios(Array.isArray(c.servicios) ? c.servicios : [], c);
    const compraBuscada = String(compraId || "").trim();
    const ix = compraBuscada
      ? servicios.findIndex((s) => String(s?.compraId || "").trim() === compraBuscada)
      : Number(servicioIndex);
    if (!Number.isInteger(ix) || ix < 0 || ix >= servicios.length) throw Object.assign(new Error("servicio_no_existe"), { status: 400, publicError: "servicio_no_existe" });
    if (!servicioPerteneceAVendedor(servicios[ix], c, socioNorm)) {
      throw Object.assign(new Error("servicio_no_permitido"), { status: 403, publicError: "servicio_no_permitido" });
    }

    const svc = { ...(servicios[ix] || {}) };
    const campo = revCampoFechaServicio(svc);
    const anterior = revParseFecha(svc[campo] || svc.fechaRenovacion || svc.vencimiento || svc.vence || svc.fechaFin);
    let nf = revParseFechaInput(nuevaFecha);
    if (!nf && meses) {
      const base = anterior && revDiasRest(anterior) > 0 ? anterior : new Date();
      nf = revAddMonths(base, Number(meses));
    }
    if (!nf || isNaN(nf)) throw Object.assign(new Error("fecha_invalida"), { status: 400, publicError: "fecha_invalida" });

    const ahora = new Date();
    svc[campo] = revFechaDMY(nf);
    svc.ultimaRenovacionAt = ahora;
    const procesadorNorm = normVendedor(socioNorm);
    svc.ultimaRenovacionProcesadaPor = procesadorNorm === "geissel" ? "geisell" : procesadorNorm;
    servicios[ix] = svc;
    transaction.update(ref, {
      servicios,
      ...camposResumenVendedores(servicios, c),
      updatedAt: ahora,
      ultimaRenovacionAt: ahora,
    });
    return { c, svc, ix, campo, fechaFinal: revFechaDMY(nf), fechaAnterior: anterior ? revFechaDMY(anterior) : "" };
  });
  return revPostRenovacion({ id, socioNorm, meses, ...mutation });
}

// Sorteo + historial de una renovación ya guardada (se usa con o sin pago).
async function revPostRenovacion({ id, socioNorm, meses, c, svc, ix, campo, fechaFinal, fechaAnterior }) {
  const compraEvento = String(svc.compraId || `servicio-${ix}`);
  const sorteo = fechaFinal !== fechaAnterior
    ? await registrarEventoSorteosSeguro({
      tipo: "renovacion", clientId: id, compraId: compraEvento, fechaEvento: fechaFinal,
      eventoId: `renov:${compraEvento}:${fechaFinal}`,
      meses: Math.max(1, Number(meses) || 1),
      clienteNombre: c.nombrePerfil || c.nombre || "Cliente", telefono: c.telefono || "",
      vendedor: vendedorEfectivoServicio(svc, c).vendedor || socioNorm || "", origen: "Panel de socios"
    })
    : { ok: true, creados: 0, omitido: "fecha_sin_cambio" };
  const vendedor = vendedorEfectivoServicio(svc, c).vendedor || socioNorm || "";
  if (fechaFinal !== fechaAnterior) {
    try {
      await db.collection("historial_clientes").add({
        clientId: id,
        tipo: "servicio_renovado",
        compraId: compraEvento,
        servicioIndex: ix,
        descripcion: `Renovación confirmada desde Panel de Socios: ${fechaAnterior || "-"} → ${fechaFinal}`,
        plataforma: svc.plataforma || svc.servicio || svc.nombre || "Servicio",
        fechaAnterior,
        fechaRenovacion: fechaFinal,
        meses: Math.max(1, Number(meses) || 1),
        vendedor,
        procesadoPor: socioNorm || "panel_socios",
        origen: "Panel de socios",
        sorteoOk: sorteo?.ok !== false,
        boletosCreados: Math.max(0, Number(sorteo?.creados) || 0),
        fechaTS: admin.firestore.FieldValue.serverTimestamp(),
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });
    } catch (error) {
      console.error("historial renovación panel", error?.message || error);
    }
  }
  return {
    actualizado: true,
    clienteId: id,
    servicioIndex: ix,
    campo,
    fechaAnterior,
    nuevaFecha: fechaFinal,
    compraId: compraEvento,
    vendedor,
    servicio: svc.plataforma || svc.servicio || svc.nombre || svc.cuenta || "Servicio",
    precioCliente: revMoneyNumber(svc.precioCliente ?? svc.precioVenta ?? svc.precio ?? svc.monto ?? 0),
    sorteo,
  };
}

async function revVerificarRenovacionesCliente(clienteId, renovaciones = []) {
  const id = String(clienteId || "").trim();
  if (!id || !renovaciones.length) return { ok: false, error: "sin_renovaciones" };
  const snap = await db.collection("clientes").doc(id).get();
  if (!snap.exists) return { ok: false, error: "cliente_no_existe" };
  const c = snap.data() || {};
  const servicios = Array.isArray(c.servicios) ? c.servicios : [];
  const detalle = renovaciones.map((r) => {
    const compraId = String(r?.compraId || "").trim();
    const ix = compraId ? servicios.findIndex((x) => String(x?.compraId || "").trim() === compraId) : Number(r?.servicioIndex);
    const svc = ix >= 0 ? servicios[ix] || {} : {};
    const campo = revCampoFechaServicio(svc);
    const fecha = String(svc[campo] || svc.fechaRenovacion || svc.vencimiento || svc.vence || svc.fechaFin || "").trim();
    return { compraId, servicioIndex: ix, esperada: String(r?.nuevaFecha || ""), guardada: fecha, ok: ix >= 0 && fecha === String(r?.nuevaFecha || "") };
  });
  return { ok: detalle.every((x) => x.ok), detalle };
}

// ── LOGIN (revendedor o admin) ── handler compartido: ver index_09_api_auth.js
app.get("/rev/turnstile-config", (_req, res) => { res.set("Cache-Control", "no-store"); res.json(require("./lib_turnstile").turnstileConfigPublica()); }); // R201 · solo la clave PÚBLICA
app.post("/rev/login", revLoginIpLimiter, createRevLoginHandler({ db, bot, SUPER_ADMIN }));
app.get("/rev/admin/me", revAdminAuth, createAdminMeHandler());
app.post("/rev/admin/logout", revAdminAuth, createAdminLogoutHandler({ db }));

// Devuelve permisos/configuración vigentes aunque el JWT se haya emitido antes
// de un cambio hecho desde Sublichat.
app.get("/rev/me", revAuth, async (req, res) => {
  try {
    const live = await revLiveProfile(req.rev, 0);
    res.json({
      id: live.id || req.rev.id || "",
      nombre: live.nombre || req.rev.nombre || "",
      nombre_norm: live.nombre_norm || req.rev.nombre_norm || "",
      nombreMostrar: live.nombreMostrar || "",
      capabilities: live.capabilities,
      permisos: live.capabilities,
      soloCatalogo: live.soloCatalogo,
      sinCompras: live.sinCompras,
      tarifaId: live.tarifaId,
      priceTier: live.tarifaId,
      etiquetaRenovacion: live.etiquetaRenovacion || "",
      ...require("./lib_portal_socios").metasPublicas(live), // R185: meta mensual configurada por Sublicuentas (si existe)
    });
  } catch (e) {
    console.error("rev/me", e);
    res.status(500).json({ error: "server" });
  }
});

// ── CLIENTES del revendedor ──
// Caché corto del escaneo de clientes. Los campos vendedores_norm / vendedor_norm
// son índices de conveniencia, pero la fuente autoritativa sigue siendo servicios[].
// Esto evita que un cliente desaparezca del Panel de Socios cuando el resumen
// superior quedó viejo (caso típico: Telegram sí avisa la renovación, pero el panel
// no la muestra). El escaneo se comparte 30 s entre socios para no multiplicar lecturas.
let _revClientesScanCache = { at: 0, docs: [] };
async function revAllClientDocsCached(maxAgeMs = 30000) {
  const now = Date.now();
  if (_revClientesScanCache.docs.length && now - _revClientesScanCache.at < maxAgeMs) return _revClientesScanCache.docs;
  const snap = await db.collection("clientes").get();
  const docs = snap.docs.slice();
  _revClientesScanCache = { at: now, docs };
  return docs;
}
function revSocioAliases(live = {}, tokenRev = {}) {
  const values = [
    live.nombre_norm, live.nombre, live.usuario, live.username, live.id,
    tokenRev.nombre_norm, tokenRev.nombre, tokenRev.usuario, tokenRev.username, tokenRev.id,
    ...(Array.isArray(live.aliases) ? live.aliases : []),
  ];
  const out = new Set();
  values.forEach((v) => {
    const n = revNormKey(v);
    if (n) out.add(n);
  });
  if (out.has("geisell")) out.add("geissel");
  if (out.has("geissel")) out.add("geisell");
  return [...out];
}
function revFiltrarClientePorAliases(cliente = {}, aliases = []) {
  for (const alias of aliases) {
    const visible = filtrarClienteParaVendedor(cliente, alias);
    if (Array.isArray(visible.servicios) && visible.servicios.length) return visible;
  }
  return { ...cliente, servicios: [] };
}
function revClientePublicoPorAliases(cliente = {}, aliases = []) {
  for (const alias of aliases) {
    const visible = clientePublicoPanel(cliente, alias);
    if (Array.isArray(visible.servicios) && visible.servicios.length) return visible;
  }
  return {
    nombre: String(cliente?.nombre || "").slice(0, 140),
    nombrePerfil: String(cliente?.nombrePerfil || "").slice(0, 140),
    nombre_norm: String(cliente?.nombre_norm || "").slice(0, 140),
    telefono: String(cliente?.telefono || cliente?.telefono_norm || "").slice(0, 40),
    telefono_norm: String(cliente?.telefono_norm || cliente?.telefono || "").slice(0, 40),
    servicios: [],
  };
}
async function revRepairClientVendorSummary(doc, data) {
  try {
    const servicios = heredarVendedorServicios(Array.isArray(data.servicios) ? data.servicios : [], data);
    const resumen = camposResumenVendedores(servicios, data);
    const oldNorm = Array.isArray(data.vendedores_norm) ? data.vendedores_norm.map(revNormKey).filter(Boolean).sort() : [];
    const newNorm = Array.isArray(resumen.vendedores_norm) ? resumen.vendedores_norm.map(revNormKey).filter(Boolean).sort() : [];
    if (JSON.stringify(oldNorm) === JSON.stringify(newNorm) && revNormKey(data.vendedor_norm) === revNormKey(resumen.vendedor_norm)) return;
    await doc.ref.set({ ...resumen, servicios, updatedAt: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
  } catch (e) {
    console.error("revRepairClientVendorSummary", doc.id, e?.message || e);
  }
}

app.get("/rev/clientes", revAuth, async (req, res) => {
  try {
    const live = await revLiveProfile(req.rev);
    if (!revCap(live, "canViewClients", true)) return res.status(403).json({ error: "sin_permiso_clientes" });
    const aliases = revSocioAliases(live, req.rev);
    const vendedorNorm = aliases[0] || revNormKey(req.rev.nombre_norm || req.rev.nombre || "");
    if (!vendedorNorm) return res.json([]);

    // 1) Índices rápidos para la mayoría de los clientes.
    const consultas = await Promise.allSettled(aliases.flatMap(alias => [
      db.collection("clientes").where("vendedores_norm", "array-contains", alias).get(),
      db.collection("clientes").where("vendedor_norm", "==", alias).get(),
    ]));
    const docs = new Map();
    consultas.forEach((resultado) => {
      if (resultado.status !== "fulfilled") return;
      resultado.value.docs.forEach((d) => docs.set(d.id, d));
    });

    // 2) Verificación autoritativa por servicios[]. Se ejecuta para TODOS los socios,
    // no solo Geisell. Así Jimena, Relojes, Yami, etc. ven exactamente las mismas
    // renovaciones que el bot detecta al recorrer servicios[].
    const allDocs = await revAllClientDocsCached();
    const reparaciones = [];
    allDocs.forEach((d) => {
      if (docs.has(d.id)) return;
      const raw = d.data() || {};
      const visible = revFiltrarClientePorAliases(raw, aliases);
      if (!visible.servicios.length) return;
      docs.set(d.id, d);
      if (reparaciones.length < 25) reparaciones.push(revRepairClientVendorSummary(d, raw));
    });
    if (reparaciones.length) Promise.allSettled(reparaciones).catch(() => {});

    const lista = Array.from(docs.values())
      .map((d) => ({ id: d.id, ...revClientePublicoPorAliases(d.data() || {}, aliases) }))
      .filter((cliente) => cliente.servicios.length > 0);
    res.set("Cache-Control", "no-store");
    res.json(lista);
  } catch (e) { console.error("rev/clientes", e); res.status(500).json({ error: "server" }); }
});

// ── PRECIOS ──
// ✅ FIX (v1): antes leía "inventario" (cuentas/capacidad), que no tiene
// campo de precio.
// ✅ FIX (v2): el catálogo real que ya usa este panel — el que ve el socio
// en "Catálogo mayorista" y el que arma el formulario "Nueva compra" — está
// agrupado por categoría con variantes por ítem, no 1 precio por
// plataforma. Ahora lee la colección "precios" (1 doc = 1 ítem, la
// administra Sublichat en /rev/admin/precios, ver index_12_admin_panel.js)
// y la reagrupa en el MISMO formato {cat, sub, items:[{n,s,p,d}]} que ya
// esperan compraProductosCatalogo()/vPrecios() en index.html — así no hace
// falta tocarles la lógica, solo cambiarles la fuente de datos.
app.get("/rev/precios", revAuth, async (req, res) => {
  try {
    // El catálogo se administra desde Sublichat y debe reflejarse de inmediato
    // en los paneles ya abiertos. Nunca permitir una copia HTTP intermedia.
    res.set("Cache-Control", "no-store, no-cache, must-revalidate, proxy-revalidate");
    res.set("Pragma", "no-cache");
    res.set("Expires", "0");
    const live = await revLiveProfile(req.rev);
    const catalogo = await obtenerCatalogoSocio(db, live);
    if (String(catalogo.origen || "").startsWith("respaldo")) {
      return res.status(503).json({ error: "catalogo_no_configurado", detail: "La tarifa debe cargarse desde la configuración real antes de vender." });
    }
    res.set("X-Catalogo-Tarifa", catalogo.tarifaId);
    res.set("X-Catalogo-Origen", catalogo.origen || "firestore");
    res.json(catalogo.grupos);
  } catch (e) { console.error("rev/precios", e); res.status(500).json({ error: "server" }); }
});

// ── INVENTARIO REAL DEL CATÁLOGO ──
// Combina la bodega real (colección inventario) con un override manual que
// puede configurarse por ítem desde Sublichat.
app.get("/rev/inventario", revAuth, async (req, res) => {
  try {
    res.set("Cache-Control", "no-store");
    const live = await revLiveProfile(req.rev);
    const [catalogo, invSnap] = await Promise.all([
      obtenerCatalogoSocio(db, live),
      db.collection("inventario").get(),
    ]);
    if (String(catalogo.origen || "").startsWith("respaldo")) {
      return res.status(503).json({ error: "catalogo_no_configurado", detail: "Inventario bloqueado hasta cargar la tarifa real." });
    }
    const agregados = new Map();
    const HBO = require("./lib_hbo_planes"); // R196v · HBO Standard / Platinum: stock separado y cuentas completas
    invSnap.docs.forEach((doc) => {
      const d = doc.data() || {};
      let key = revCanonInventory(d.plataforma || d.servicio || d.tipo || "");
      if (!key) return;
      if (key === "hbomax" && HBO.planValido(d.planHbo)) key = `hbomax_${HBO.planValido(d.planHbo)}`;
      const estado = String(d.estado || "activa").trim().toLowerCase();
      const cap = Math.max(0, revMoneyNumber(d.capacidad));
      const ocupados = Math.max(0, revMoneyNumber(d.ocupados));
      let disponibles = d.disponibles == null || d.disponibles === "" ? Math.max(0, cap - ocupados) : Math.max(0, revMoneyNumber(d.disponibles));
      if (key.startsWith("hbomax")) disponibles = Math.min(disponibles, HBO.cuposVendibles(d)); // R196v · vendida completa = 0
      if (["inactiva", "inactivo", "suspendida", "suspendido", "bloqueada", "bloqueado"].includes(estado)) disponibles = 0;
      const prev = agregados.get(key) || { docs: 0, disponibles: 0, capacidad: 0, ocupados: 0, vacias: 0 };
      prev.docs += 1; prev.disponibles += disponibles; prev.capacidad += cap; prev.ocupados += ocupados;
      if (disponibles > 0 && ocupados === 0 && !(Array.isArray(d.clientes) && d.clientes.length)) prev.vacias += 1; // R196v · libres para vender como cuenta completa
      agregados.set(key, prev);
    });

    const items = catalogoPlano(catalogo.grupos).map((item) => {
      const stockModo = String(item.stockModo || "auto").toLowerCase();
      const manualEstado = String(item.stockEstado || "").toLowerCase();
      const manualCantidad = item.stockCantidad == null ? null : Number(item.stockCantidad);
      if (stockModo === "manual") {
        let estado = ["disponible", "bajo", "agotado", "consultar"].includes(manualEstado) ? manualEstado : "consultar";
        if (!manualEstado && Number.isFinite(manualCantidad)) estado = manualCantidad <= 0 ? "agotado" : manualCantidad <= 2 ? "bajo" : "disponible";
        return { id:item.id, catalogId:item.id, nombre:item.nombreCompleto, estado, stock:Number.isFinite(manualCantidad)?manualCantidad:null, origen:"manual" };
      }
      const keys = revCatalogInventoryKeys(item);
      const completaHbo = keys.some((k) => /^hbomax_/.test(k)) && /cuentas? completas?/i.test(`${item.n || ""} ${item.s || ""} ${item.categoria || item.cat || ""} ${item.tipoEntrega || ""}`.replace(/_/g, " ")); // R196v
      let docs = 0, disponibles = 0, capacidad = 0, ocupados = 0, plataforma = "";
      for (const key of keys) {
        const row = agregados.get(key);
        if (!row) continue;
        if (!plataforma) plataforma = key;
        docs += row.docs; disponibles += completaHbo ? row.vacias : row.disponibles; capacidad += row.capacidad; ocupados += row.ocupados;
      }
      if (!docs) return { id:item.id, catalogId:item.id, nombre:item.nombreCompleto, estado:"consultar", stock:null, origen:"sin_bodega" };
      const estado = disponibles <= 0 ? "agotado" : disponibles <= 2 ? "bajo" : "disponible";
      return { id:item.id, catalogId:item.id, nombre:item.nombreCompleto, estado, stock:disponibles, capacidad, ocupados, plataforma, origen:"bodega" };
    });
    res.json({ ok:true, tarifaId:catalogo.tarifaId, items, updatedAt:Date.now() });
  } catch (e) {
    console.error("rev/inventario", e);
    res.status(500).json({ error:"server" });
  }
});

// ── MÉTRICAS DEL SOCIO ──
app.get("/rev/metricas", revAuth, async (req, res) => {
  try {
    res.set("Cache-Control", "no-store");
    const live = await revLiveProfile(req.rev);
    const socioNorm = revNormKey(live.nombre_norm || live.nombre || "");
    const aliases = socioNorm === "geisell" ? ["geisell", "geissel"] : [socioNorm];
    const [compraSnaps, renovSnaps] = await Promise.all([
      Promise.all(aliases.map((a) => db.collection("compras").where("socio_norm", "==", a).get())),
      Promise.all(aliases.map((a) => db.collection("renovaciones").where("socio_norm", "==", a).get())),
    ]);
    const dedupe = (snaps) => { const m=new Map(); snaps.forEach(snap=>snap.docs.forEach(d=>m.set(d.id,{id:d.id,...d.data()}))); return [...m.values()]; };
    const compras = dedupe(compraSnaps), renovaciones = dedupe(renovSnaps);
    const now = new Date();
    let start = new Date(now.getFullYear(), now.getMonth(), 1).getTime();
    let end = new Date(now.getFullYear(), now.getMonth()+1, 1).getTime();
    // R185 · ?periodo=YYYY-MM (Metas del mes por mes y año). Misma convención de fechas que el mes actual.
    const perPedido = require("./lib_portal_socios").periodoValido(req.query.periodo);
    let periodo = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,"0")}`;
    if (perPedido) { const r = require("./lib_portal_socios").rangoMesServidor(perPedido); start = r.desde; end = r.hasta; periodo = perPedido.txt; }
    const enMes = (x) => { const t=revDateMs(x.createdAt || x.fecha || x.ts); return t>=start && t<end; };
    const ops = [
      ...compras.filter(enMes).map(x=>({...x,_tipo:"compra"})),
      ...renovaciones.filter(enMes).map(x=>({...x,_tipo:"renovacion"})),
    ];
    const costoMes = ops.reduce((a,x)=>a+Math.max(0,revMoneyNumber(x.monto)),0);
    const counts = new Map();
    ops.forEach(x=>{const k=String(x.servicio||"Servicio").trim()||"Servicio";counts.set(k,(counts.get(k)||0)+1)});
    const topServicio = [...counts.entries()].sort((a,b)=>b[1]-a[1])[0] || null;
    const pendientes = compras.filter(x=>!["entregado","completado","cancelado"].includes(String(x.estado||"pendiente").toLowerCase())).length;
    res.json({
      ok:true,
      periodo,
      operacionesMes:ops.length, comprasMes:ops.filter(x=>x._tipo==="compra").length, renovacionesMes:ops.filter(x=>x._tipo==="renovacion").length,
      costoMes, operadoMes:costoMes,
      pedidosPendientes:pendientes,
      topServicio:topServicio?{nombre:topServicio[0],operaciones:topServicio[1]}:null,
    });
  } catch (e) {
    console.error("rev/metricas", e);
    res.status(500).json({ error:"server" });
  }
});

// ── MIS PEDIDOS / SEGUIMIENTO ──
app.get("/rev/compras/mias", revAuth, async (req, res) => {
  try {
    const live = await revLiveProfile(req.rev);
    if (!revCap(live, "canBuy", true)) return res.json({ ok:true, items:[] });
    const socioNorm = revNormKey(live.nombre_norm || live.nombre || "");
    const aliases = socioNorm === "geisell" ? ["geisell", "geissel"] : [socioNorm];
    const snaps = await Promise.all(aliases.map(a=>db.collection("compras").where("socio_norm","==",a).get()));
    const m=new Map();snaps.forEach(snap=>snap.docs.forEach(d=>m.set(d.id,{id:d.id,...d.data()})));
    const limit=require("./lib_portal_socios").limiteHistorial(req.query.limit,20,500); // R185: historial completo (antes máx. 100)
    // Oct-2026 · Pedidos del Panel de Socios: detalle por renglón (destinatario, datos, notas). Sin imagen ni datos de finanzas.
    const items=[...m.values()].sort((a,b)=>revDateMs(b.createdAt)-revDateMs(a.createdAt)).slice(0,limit).map(x=>({
      ...CS.pedidoPublico(x.id,x), monto:revMoneyNumber(x.monto),
    }));
    res.json({ok:true,items});
  } catch(e){console.error("rev/compras/mias",e);res.status(500).json({error:"server"})}
});

// Oct-2026 · ¿Ya llegó este pedido? Si la conexión se cortó al enviar, el panel pregunta aquí antes de reintentar.
app.get("/rev/compra/estado", revAuth, async (req, res) => {
  try {
    const live = await revLiveProfile(req.rev);
    const requestId = cleanTg(req.query.requestId, 120);
    if (!requestId) return res.status(400).json({ error: "falta_request_id" });
    const docId = `web_${crypto.createHash("sha256").update(`${live.id || live.nombre_norm || "socio"}|${requestId}`).digest("hex").slice(0, 40)}`;
    const snap = await db.collection("compras").doc(docId).get();
    res.set("Cache-Control", "no-store");
    if (!snap.exists) return res.json({ ok: true, existe: false });
    res.json({ ok: true, existe: true, pedido: { ...CS.pedidoPublico(snap.id, snap.data() || {}), monto: revMoneyNumber((snap.data() || {}).monto) } });
  } catch (e) { console.error("rev/compra/estado", e); res.status(500).json({ error: "server" }); }
});

// ── AVISOS — buzón publicado desde Telegram (/aviso) ──
app.get("/rev/avisos", revAuth, async (req, res) => {
  try {
    // ✅ Sin where+orderBy combinado (evita necesitar índice compuesto en Firestore)
    // R185 · ?periodo=YYYY-MM: archivo por mes y año (fecha original del aviso, hora de Honduras). Sin periodo: igual que antes.
    const rangoAv = require("./lib_portal_socios").rangoMesHonduras(String(req.query.periodo || ""));
    const consultaAv = rangoAv
      ? db.collection("avisos").where("createdAt", ">=", rangoAv.desde).where("createdAt", "<", rangoAv.hasta).orderBy("createdAt", "desc").limit(200)
      : db.collection("avisos").orderBy("createdAt", "desc").limit(20);
    const [snap, live] = await Promise.all([
      consultaAv.get(),
      revLiveProfile(req.rev),
    ]);
    const socioNorm = normVendedor(live?.nombre_norm || req.rev?.nombre_norm || req.rev?.nombre || "");
    const leidos = new Set(Array.isArray(live?.avisosLeidos) ? live.avisosLeidos.map(String) : []);
    const lista = snap.docs
      .map((d) => {
        const a = d.data();
        const ts = a.createdAt?._seconds ? a.createdAt._seconds * 1000 :
                   a.createdAt?.seconds ? a.createdAt.seconds * 1000 : Date.now();
        return { id: d.id, texto: a.texto || "", autor: a.autor || "Admin", ts, activo: a.activo !== false, tipo:a.tipo||"aviso", imagenUrl:a.imagenUrl||"", promocionId:a.promocionId||"", destinatarios:Array.isArray(a.destinatarios)?a.destinatarios:[], leido:leidos.has(String(d.id)) };
      })
      .filter((a) => a.activo && (!a.destinatarios.length || a.destinatarios.map(normVendedor).includes(socioNorm)))
      .slice(0, rangoAv ? 200 : 10);
    res.set("Cache-Control", "no-store");
    res.json(lista);
  } catch (e) { console.error("rev/avisos", e); res.status(500).json({ error: "server" }); }
});

app.post("/rev/avisos/leido", revAuth, async (req, res) => {
  try {
    const id = String(req.body?.id || "").trim();
    if (!id || id.length > 180) return res.status(400).json({ error: "aviso_invalido" });
    const live = await revLiveProfile(req.rev, 0);
    if (!live?.id) return res.status(404).json({ error: "socio_no_encontrado" });
    const actuales = Array.isArray(live.avisosLeidos) ? live.avisosLeidos.map(String) : [];
    const avisosLeidos = [...new Set([...actuales, id])].slice(-200);
    await db.collection("revendedores").doc(String(live.id)).set({ avisosLeidos }, { merge: true });
    _revLiveCache.delete(String(live.id));
    res.set("Cache-Control", "no-store");
    res.json({ ok: true, id });
  } catch (e) { console.error("rev/avisos/leido", e); res.status(500).json({ error: "server" }); }
});

// ── SUGERENCIAS — buzón del revendedor, llega directo al admin por Telegram ──
async function getAdminChatIds() {
  try {
    const snap = await db.collection("admins").get();
    const ids = [];
    snap.forEach((d) => {
      const data = d.data() || {};
      if (data.activo !== false && /^\d+$/.test(String(d.id))) ids.push(String(d.id));
    });
    if (ids.length) return ids;
  } catch (_) {}
  return String(process.env.SUPER_ADMIN || "").split(",").map((s) => s.trim()).filter(Boolean);
}
async function sendTelegramMessage(chatId, text) {
  const token = String(process.env.BOT_TOKEN || "").trim();
  if (!token) {
    await enqueueTelegramJob({type:"message",chatId,text,parseMode:"Markdown",source:"panel-api"});
    return true;
  }
  try {
    const r = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, text, parse_mode: "Markdown" }),
    });
    if (r.ok) return true;
    const raw=await r.text().catch(()=>"");
    if (r.status===401 || /unauthorized/i.test(raw)) {
      await enqueueTelegramJob({type:"message",chatId,text,parseMode:"Markdown",source:"panel-api-token-fallback"});
      return true;
    }
    console.error("sendTelegramMessage", r.status, raw);
    return false;
  } catch (e) {
    console.error("sendTelegramMessage", e.message);
    try { await enqueueTelegramJob({type:"message",chatId,text,parseMode:"Markdown",source:"panel-api-network-fallback"}); return true; } catch (_) { return false; }
  }
}

async function sendTelegramPhoto(chatId, photoUrl, caption) {
  const token = String(process.env.BOT_TOKEN || "").trim();
  if (!photoUrl) return false;
  if (!token) {
    await enqueueTelegramJob({type:"photo",chatId,photoUrl,text:caption,parseMode:"Markdown",source:"panel-api"});
    return true;
  }
  try {
    const r = await fetch(`https://api.telegram.org/bot${token}/sendPhoto`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, photo: photoUrl, caption, parse_mode: "Markdown" }),
    });
    if (r.ok) return true;
    const raw=await r.text().catch(()=>r.statusText||"");
    if (r.status===401 || /unauthorized/i.test(raw)) {
      await enqueueTelegramJob({type:"photo",chatId,photoUrl,text:caption,parseMode:"Markdown",source:"panel-api-token-fallback"});
      return true;
    }
    console.error("sendTelegramPhoto",r.status,raw);
    return false;
  } catch (e) { console.error("sendTelegramPhoto", e.message); return false; }
}

async function sendTelegramPhotoBuffer(chatId, imageObj, caption) {
  const token = process.env.BOT_TOKEN;
  if (!token || !imageObj?.buffer) return false;
  try {
    if (typeof FormData !== "function" || typeof Blob !== "function") return false;
    const fd = new FormData();
    fd.append("chat_id", String(chatId));
    fd.append("caption", caption || "");
    fd.append("parse_mode", "Markdown");
    fd.append("photo", new Blob([imageObj.buffer], { type: imageObj.contentType || "image/jpeg" }), imageObj.filename || "comprobante.jpg");
    const r = await fetch(`https://api.telegram.org/bot${token}/sendPhoto`, { method: "POST", body: fd });
    if (r.ok) return true;
    const raw=await r.text().catch(()=>r.statusText||"");
    if (r.status===401 || /unauthorized/i.test(raw)) {
      await enqueueTelegramJob({type:"message",chatId,text:caption,parseMode:"Markdown",source:"panel-api-buffer-token-fallback"});
      return true;
    }
    console.error("sendTelegramPhotoBuffer",r.status,raw);
    return false;
  } catch (e) { console.error("sendTelegramPhotoBuffer", e.message); return false; }
}

async function sendTelegramImageSmart(chatId, imageObj, caption) {
  if (imageObj?.url && await sendTelegramPhoto(chatId, imageObj.url, caption)) return true;
  if (imageObj?.buffer && await sendTelegramPhotoBuffer(chatId, imageObj, caption)) return true;
  await sendTelegramMessage(chatId, caption);
  return false;
}

function cleanTg(v, max = 300) {
  return (v == null ? "" : String(v)).replace(/[\*_`\[\]]/g, "").trim().slice(0, max);
}
const { destinoInfo, getDestinoChatIds } = require("./lib_destinos_tg"); // Oct-2026 · compartido con el bot
const VTG = require("./lib_voucher_tg"); // R195 · comprobantes con entrega verificable a Telegram
function parsePanelImage(imagen) {
  if (!imagen) return null;
  const m = String(imagen).match(/^data:(image\/(?:jpe?g|png|webp));base64,(.+)$/);
  if (!m) return null;
  const contentType = m[1].replace("image/jpg", "image/jpeg");
  const buffer = Buffer.from(m[2], "base64");
  if (buffer.length > 7 * 1024 * 1024) {
    const err = new Error("imagen_muy_grande");
    err.status = 413;
    err.publicError = "imagen_muy_grande";
    throw err;
  }
  const ext = contentType.split("/")[1].replace("jpeg", "jpg");
  return { contentType, buffer, ext, filename: `comprobante_${Date.now()}.${ext}`, dataUri: String(imagen) };
}

async function uploadPanelImage(imagen, folder = "comprobantes") {
  const parsed = parsePanelImage(imagen);
  if (!parsed) return { url: "", buffer: null, contentType: "", filename: "", storageError: "" };

  const path = `${folder}/${Date.now()}_${Math.random().toString(36).slice(2, 8)}.${parsed.ext}`;
  let lastError = null;
  for (const bucketName of STORAGE_BUCKET_CANDIDATES) {
    try {
      const file = admin.storage().bucket(bucketName).file(path);
      await file.save(parsed.buffer, {
        contentType: parsed.contentType,
        resumable: false,
        metadata: { cacheControl: "public,max-age=31536000" },
      });
      const [url] = await file.getSignedUrl({ action: "read", expires: "2099-12-31" });
      return { ...parsed, url, bucketName, storageError: "" };
    } catch (e) {
      lastError = e;
      console.error("uploadPanelImage bucket fail", bucketName, e.message);
    }
  }

  // No botamos la compra/renovación si Storage falla: se manda la foto directo a Telegram.
  return { ...parsed, url: "", bucketName: "", storageError: lastError ? lastError.message : "storage_no_configurado" };
}

// ── Comprobante de renovación: sube la foto + opcionalmente actualiza la fecha del servicio ──

// ===================== R108 · SOCIOS EN EL CENTRO FINANCIERO =====================
// Compra y renovación de socios entran al MISMO libro (finanzas_movimientos) que web, APK y bot.
// El precio lo decide el servidor (catálogo mayorista / precio guardado del servicio) y el banco es obligatorio.
// La renovación de todos los servicios elegidos + su ingreso se guardan en UNA transacción (o todo, o nada).
const R108_CANTIDADES = new Set([...Array.from({ length: 20 }, (_, i) => i + 1), 25, 30, 40, 50]);
function r108Ymd() { return new Date(Date.now() - 6 * 3600000).toISOString().slice(0, 10); }
function r108Fecha(ymd) { const [y, m, d] = ymd.split("-"); return { fecha: `${d}/${m}/${y}`, fechaPago: ymd, mesKey: `${y}-${m}`, monthKey: `${y}-${m}`, fechaTS: admin.firestore.Timestamp.fromDate(new Date(Date.UTC(+y, +m - 1, +d, 12))) }; }
async function r108Banco(bancoId) {
  const methods = await require("./index_31_finanzas_libro").loadMethods();
  return methods.find((m) => m.id === String(bancoId || "").trim()) || null;
}
async function r108CicloId(tx) {
  const snap = await tx.get(db.collection("finanzas_config").doc("libro_mayor"));
  const l = snap.exists ? (snap.data() || {}) : {};
  const desdes = Object.values(l.bases || {}).map((b) => b?.desde).filter(Boolean).sort();
  return l.cicloId || `ciclo_${l.cicloInicio || desdes[0] || "2026-10-01"}`;
}
function r108Movs(tx, { idBase, subtipo, total, banco, cicloId, rel, auditoria }) {
  const now = new Date().toISOString(), f = r108Fecha(r108Ymd());
  const actorSocio = String(rel.socioNombre || rel.socioNorm || "Socio").trim();
  const base = { origen: "socios", origenCanal: "socios", registradoPor: actorSocio, registradoPorNombre: actorSocio, ...f, createdAt: now, updatedAt: now, cicloId, ...rel };
  const venta = db.collection("finanzas_movimientos").doc(`${idBase}_venta`), ing = db.collection("finanzas_movimientos").doc(`${idBase}_cobro`);
  tx.set(venta, { ...base, movimientoId: venta.id, tipo: "venta", subtipo, monto: total, montoRecibido: total, saldoPendiente: 0, estadoPago: "pagado" });
  tx.set(ing, { ...base, movimientoId: ing.id, tipo: "ingreso", subtipo, monto: total, bancoId: banco.id, banco: banco.nombre, metodoPago: banco.nombre, cobradoPor: actorSocio, ...(subtipo === "compra_socio" ? { fichaPendiente: true } : {}) }); // R121: la compra de socio queda "sin ficha" hasta que se arme (Ya pagó por Socios)
  tx.set(db.collection("auditoria_eventos").doc(), { actorUsuario: actorSocio, rol: "socio", origen: "socios", modulo: "socios", resultado: "ok", createdAt: now, monto: total, bancos: [{ bancoId: banco.id, monto: total, direccion: "entrada" }], operationId: rel.operationId || "", movimientoId: ing.id, ...auditoria });
  return { ventaId: venta.id, ingresoId: ing.id };
}

// R121 · El ingreso de una COMPRA de socio lleva el nombre del perfil (antes Finanzas lo mostraba solo como "Ingresos").
// Varios perfiles distintos en el mismo pedido salen juntos; si el producto no lleva perfil se usa el nombre del
// cliente del pedido y, de último, el del socio: nunca queda un ingreso sin nombre.
function r121NombreCompraSocio(productos, cliente, socio) {
  const vistos = new Set(), nombres = [];
  for (const p of Array.isArray(productos) ? productos : []) {
    const n = String(p?.perfil || `${p?.perfilNombre || ""} ${p?.perfilApellido || ""}`.trim() || p?.nombreCliente || "").replace(/\s+/g, " ").trim();
    if (n && !vistos.has(n.toLowerCase())) { vistos.add(n.toLowerCase()); nombres.push(n); }
  }
  return (nombres.join(", ") || String(cliente || "").replace(/\s+/g, " ").trim() || String(socio || "").trim()).slice(0, 80);
}
// Las compras de socios ya guardadas se completan UNA sola vez al arrancar: se agrega el nombre del perfil y la marca
// "sin ficha" (fichaPendiente) que usa la opción "Ya pagó por Socios". No se toca monto, banco ni fecha.
// Queda anotado en finanzas_config/migraciones para no volver a leer nada.
async function r121RellenarNombresCompraSocio() {
  const marca = db.collection("finanzas_config").doc("migraciones");
  try {
    const m = await marca.get();
    if (m.exists && (m.data() || {}).r121NombresCompraSocio) return 0;
    const snap = await db.collection("finanzas_movimientos").where("subtipo", "==", "compra_socio").get();
    const sinMarca = (x) => x.tipo === "ingreso" && x.fichaPendiente === undefined && !x.estadoFinanciero && !x.reversaDe;
    const faltan = snap.docs.filter((d) => !String((d.data() || {}).clienteNombre || "").trim() || sinMarca(d.data() || {}));
    const pedidos = new Map();
    for (const id of new Set(faltan.map((d) => String((d.data() || {}).pedidoId || (d.data() || {}).compraId || "").trim()).filter(Boolean))) {
      const c = await db.collection("compras").doc(id).get();
      if (c.exists) pedidos.set(id, c.data() || {});
    }
    let n = 0;
    for (let i = 0; i < faltan.length; i += 400) {
      const batch = db.batch();
      for (const d of faltan.slice(i, i + 400)) {
        const x = d.data() || {}, ped = pedidos.get(String(x.pedidoId || x.compraId || "").trim()) || {};
        const nombre = r121NombreCompraSocio(ped.productos, ped.cliente, x.socioNombre || x.registradoPorNombre);
        const cambio = { ...(!String(x.clienteNombre || "").trim() && nombre ? { clienteNombre: nombre } : {}), ...(sinMarca(x) ? { fichaPendiente: true } : {}) };
        if (Object.keys(cambio).length) { batch.update(d.ref, cambio); n++; }
      }
      await batch.commit();
    }
    await marca.set({ r121NombresCompraSocio: new Date().toISOString(), r121NombresCompraSocioDocs: n }, { merge: true });
    if (n) console.log(`R121: ${n} movimientos de compra de socios completados (nombre del perfil / marca sin ficha)`);
    return n;
  } catch (e) { console.error("R121 nombres compra socio:", e.message); return 0; }
}

async function revRenovarSeleccionConPago({ clienteId, socioNorm, socioNombre, seleccion, nuevaFecha, meses, banco, operationId }) {
  const id = String(clienteId || "").trim();
  const ref = db.collection("clientes").doc(id);
  const opKey = `socio_renov_${crypto.createHash("sha256").update(`${socioNorm}|${operationId}`).digest("hex").slice(0, 32)}`;
  const ventaRef = db.collection("finanzas_movimientos").doc(`${opKey}_venta`);
  const out = await db.runTransaction(async (tx) => {
    const [snap, ya] = await Promise.all([tx.get(ref), tx.get(ventaRef)]);
    if (ya.exists) return { duplicado: true, previo: ya.data() || {} };
    if (!snap.exists) throw Object.assign(new Error("cliente_no_existe"), { status: 404, publicError: "cliente_no_existe" });
    const cicloId = await r108CicloId(tx);
    const c = snap.data() || {};
    const servicios = heredarVendedorServicios(Array.isArray(c.servicios) ? c.servicios : [], c);
    const ahora = new Date(), items = [];
    for (const sel of seleccion) {
      const compraBuscada = String(sel.compraId || "").trim();
      const ix = compraBuscada ? servicios.findIndex((x) => String(x?.compraId || "").trim() === compraBuscada) : Number(sel.servicioIndex);
      if (!Number.isInteger(ix) || ix < 0 || ix >= servicios.length) throw Object.assign(new Error("servicio_no_existe"), { status: 400, publicError: "servicio_no_existe" });
      if (!servicioPerteneceAVendedor(servicios[ix], c, socioNorm)) throw Object.assign(new Error("servicio_no_permitido"), { status: 403, publicError: "servicio_no_permitido" });
      const svc = { ...(servicios[ix] || {}) };
      // Precio autoritativo = el guardado en el servicio del socio (snapshot). Nunca el que manda el navegador.
      const precio = revMoneyNumber(svc.precioSocio ?? svc.precio ?? svc.precioVenta ?? svc.monto ?? 0);
      if (!(precio > 0)) throw Object.assign(new Error("precio_no_resuelto"), { status: 409, publicError: "precio_no_resuelto", detail: `${svc.plataforma || "Servicio"} no tiene precio guardado; pida a Sublicuentas que lo registre.` });
      const campo = revCampoFechaServicio(svc);
      const anterior = revParseFecha(svc[campo] || svc.fechaRenovacion || svc.vencimiento || svc.vence || svc.fechaFin);
      let nf = revParseFechaInput(nuevaFecha);
      if (!nf && meses) nf = revAddMonths(anterior && revDiasRest(anterior) > 0 ? anterior : new Date(), Number(meses)); // mes calendario
      if (!nf || isNaN(nf)) throw Object.assign(new Error("fecha_invalida"), { status: 400, publicError: "fecha_invalida" });
      svc[campo] = revFechaDMY(nf); svc.ultimaRenovacionAt = ahora;
      const pn = normVendedor(socioNorm); svc.ultimaRenovacionProcesadaPor = pn === "geissel" ? "geisell" : pn;
      servicios[ix] = svc;
      items.push({ c, svc, ix, campo, fechaFinal: revFechaDMY(nf), fechaAnterior: anterior ? revFechaDMY(anterior) : "", precio, compraId: String(svc.compraId || `servicio-${ix}`), servicio: svc.plataforma || svc.servicio || svc.nombre || "Servicio" });
    }
    tx.update(ref, { servicios, ...camposResumenVendedores(servicios, c), updatedAt: ahora, ultimaRenovacionAt: ahora });
    const total = items.reduce((a, x) => a + x.precio, 0);
    const rel = { socioNorm, socioNombre, clienteId: id, clienteNombre: c.nombrePerfil || c.nombre || "", compraId: items.map((x) => x.compraId).join(","), plataforma: items.map((x) => x.servicio).join(", "), tipoOrigen: "renovacion", operationId, serviciosSocio: items.map((x) => ({ compraId: x.compraId, servicio: x.servicio, precio: x.precio, fechaAnterior: x.fechaAnterior, fechaNueva: x.fechaFinal })), meses: nuevaFecha ? 0 : Math.max(1, Number(meses) || 1), fechaPersonalizada: !!nuevaFecha };
    const movs = r108Movs(tx, { idBase: opKey, subtipo: "renovacion_socio", total, banco, cicloId, rel, auditoria: { accion: "renovacion_socio", targetType: "renovacion", targetId: opKey, clienteId: id, detalle: `Socio ${socioNombre} renovó ${items.map((x) => `${x.servicio} ${x.fechaAnterior || "—"}→${x.fechaFinal} (L${x.precio})`).join(" · ")} · total L${total} en ${banco.nombre}`, after: { total, banco: banco.nombre, servicios: rel.serviciosSocio, modo: nuevaFecha ? "fecha personalizada" : `+${Math.max(1, Number(meses) || 1)}m` } } });
    return { duplicado: false, items, total, ...movs };
  });
  if (out.duplicado) return out;
  const renovaciones = [];
  for (const it of out.items) renovaciones.push({ ...(await revPostRenovacion({ id, socioNorm, meses, ...it })), precio: it.precio });
  return { ...out, renovaciones };
}

app.get("/rev/metodos-pago", revAuth, async (req, res) => {
  try {
    // Oct-2026 · además del id/nombre, el titular, número y nota reales (los mismos que ve el cliente en su portal).
    const metodos = await require("./index_31_finanzas_libro").loadMethods();
    const cfg = await db.collection("portal_cliente").doc("configuracion").get().catch(() => null);
    const raw = cfg && cfg.exists && Array.isArray(cfg.data()?.metodos) ? cfg.data().metodos : [];
    const extra = new Map(raw.map((m) => [String(m.id || ""), m]));
    res.json({ ok: true, metodos: metodos.map((m) => { const x = extra.get(m.id) || {}; return { ...m, titular: cleanTg(x.titular, 130), cuenta: cleanTg(x.cuenta, 60), nota: cleanTg(x.nota, 120) }; }) });
  }
  catch (e) { console.error("rev/metodos-pago", e); res.status(500).json({ error: "server" }); }
});

app.post("/rev/renovacion", revAuth, async (req, res) => {
  try {
    const live = await revLiveProfile(req.rev);
    if (!revCap(live, "canRenew", true)) return res.status(403).json({ error: "sin_permiso_renovar" });
    const { clienteId, cliente, servicio, comentario, quien, monto, imagen, servicioIndex, nuevaFecha, meses } = req.body;
    const destino = destinoInfo(req.body?.destino);
    const socio = live.nombre || live.nombre_norm || req.rev.nombre || req.rev.nombre_norm || "Revendedor";
    const com = (comentario || "").toString().trim().slice(0, 600);

    const seleccionRaw=Array.isArray(req.body.servicios)&&req.body.servicios.length?req.body.servicios:[{servicioIndex,servicio}];
    const seleccionEntrada=seleccionRaw.map(x=>({
      servicioIndex:Number(x.servicioIndex),
      compraId:String(x.compraId||"").trim().slice(0,160),
      servicio:String(x.servicio||"").slice(0,120)
    })).filter(x=>(x.compraId||Number.isInteger(x.servicioIndex))&&(x.compraId||x.servicioIndex>=0)).slice(0,30);
    if(!seleccionEntrada.length)return res.status(400).json({error:"sin_servicios"});
    const seleccion=await revResolverSeleccionCliente({clienteId,socioNorm:live.nombre_norm||req.rev.nombre_norm||"",seleccion:seleccionEntrada});
    // R108: banco obligatorio y monto automático (el servidor suma el precio guardado de cada servicio).
    const bancoR108 = await r108Banco(req.body?.bancoId);
    if (!bancoR108) return res.status(400).json({ error: "falta_banco", detail: "Elija el banco donde se hizo el pago." });
    if (!(nuevaFecha || meses)) return res.status(400).json({ error: "fecha_invalida", detail: "Elija +1m/+2m/+3m/+6m o una fecha." });
    const opR108 = cleanTg(req.body?.operationId || req.body?.requestId, 80);
    if (!/^[A-Za-z0-9-]{8,80}$/.test(opR108)) return res.status(400).json({ error: "falta_operation_id", detail: "Actualice el panel." });
    const pagoR108 = await revRenovarSeleccionConPago({ clienteId, socioNorm: live.nombre_norm || req.rev.nombre_norm || "", socioNombre: socio, seleccion, nuevaFecha, meses, banco: bancoR108, operationId: opR108 });
    if (pagoR108.duplicado) return res.json({ ok: true, duplicate: true, total: Number(pagoR108.previo?.monto || 0), renovado: true });
    const renovacionesFecha=pagoR108.renovaciones;
    const renovacionFecha=renovacionesFecha[0]||null;
    const verificacion = renovacionesFecha.length ? await revVerificarRenovacionesCliente(clienteId, renovacionesFecha) : { ok:true, detalle:[] };
    if (renovacionesFecha.length && !verificacion.ok) {
      const err = new Error("renovacion_no_confirmada_en_ficha");
      err.status = 409; err.publicError = "renovacion_no_confirmada";
      throw err;
    }

    const imagenObj = await uploadPanelImage(imagen, "renovaciones");
    const imagenUrl = imagenObj.url || "";

    const doc = {
      clienteId: (clienteId || "").toString(),
      cliente: (cliente || "").toString().slice(0, 120),
      servicio: seleccion.length>1?`${seleccion.length} servicios`:(renovacionFecha?.servicio || seleccion[0]?.servicio || servicio || "").toString().slice(0, 120),
      servicioIndex: seleccion.length===1?seleccion[0].servicioIndex:null,
      servicios: seleccion.map((x,i)=>({
        servicioIndex:x.servicioIndex,
        compraId:renovacionesFecha[i]?.compraId||x.compraId||"",
        servicio:renovacionesFecha[i]?.servicio||x.servicio,
        vendedor:renovacionesFecha[i]?.vendedor||live.nombre_norm||req.rev.nombre_norm||"",
        fechaAnterior:renovacionesFecha[i]?.fechaAnterior||"",
        nuevaFecha:renovacionesFecha[i]?.nuevaFecha||String(nuevaFecha||""),
        meses:Math.max(1,Number(meses)||1),
        sorteoOk:renovacionesFecha[i]?.sorteo?.ok!==false,
        boletosCreados:Math.max(0,Number(renovacionesFecha[i]?.sorteo?.creados)||0)
      })),
      comentario: com,
      quien: (quien || "").toString().slice(0, 120),
      monto: pagoR108.total, montoAutomatico: true, bancoId: bancoR108.id, banco: bancoR108.nombre, operationId: opR108, finanzasIngresoId: pagoR108.ingresoId, // R108
      preciosSnapshot: (pagoR108.items||[]).map(x=>({ compraId:x.compraId, servicio:x.servicio, precio:x.precio })),
      socio,
      socio_norm: live.nombre_norm || req.rev.nombre_norm || "",
      destino: destino.key,
      destinoLabel: destino.label,
      imagenUrl,
      // Si Storage falla, Telegram recibe la foto por buffer; para que Panel Dios también la vea,
      // guardamos una copia liviana en Firestore cuando no hay URL pública.
      imagenData: imagenUrl ? "" : (imagenObj.dataUri && imagenObj.dataUri.length < 850000 ? imagenObj.dataUri : ""),
      imagenStorageError: imagenObj.storageError || "",
      fechaAnterior: renovacionFecha?.fechaAnterior || "",
      nuevaFecha: renovacionFecha?.nuevaFecha || (nuevaFecha || "").toString().slice(0, 20),
      renovado: renovacionesFecha.length>0,
      renovadosCantidad: renovacionesFecha.length,
      operacionDiaKey: `${revNormKey(live.nombre_norm||req.rev.nombre_norm||"")}:${String(clienteId||"").trim()}:${revFechaDMY(new Date())}`,
      verificacionFicha: verificacion.ok === true,
      boletosCreados: renovacionesFecha.reduce((sum,item)=>sum+Math.max(0,Number(item?.sorteo?.creados)||0),0),
      createdAt: new Date(),
    };
    const ref = db.collection("renovaciones").doc(); // R195 · mismo outbox verificable que las compras
    doc.notificacion = VTG.notificacionInicial(ref.id, destino.key === "relojes" ? "relojes" : "sublicuentas");
    await ref.set(doc);

    const cap = [
      `🧾 *RENOVACIÓN RECIBIDA*`,
      `━━━━━━━━━━━━━━`,
      `👤 Socio: ${cleanTg(socio, 80)}`,
      `📍 Pago para: ${destino.label}`,
      `🙍 Cliente: ${cleanTg(doc.cliente || "—", 120)}`,
      `📦 Servicios: ${doc.servicios.map(x=>x.servicio||('Servicio '+(x.servicioIndex+1))).join(', ')}`,
      doc.renovado ? `📅 Nueva fecha: ${cleanTg(doc.nuevaFecha || "—", 30)} · ${doc.renovadosCantidad} renovado(s)` : "",
      `💵 Total (automático): L${doc.monto} · 🏦 ${cleanTg(doc.banco, 40)}`,
      doc.quien ? `🔁 Renovó: ${cleanTg(doc.quien, 80)}` : "",
      com ? `📝 Nota: ${cleanTg(com, 260)}` : "",
      (imagenUrl || imagenObj.buffer) ? `📎 Comprobante adjunto` : `⚠️ Sin comprobante`,
      `🆔 Ref: ${ref.id.slice(-6)}`,
    ].filter(Boolean).join("\n");
    let notifR = { n: doc.notificacion };
    try { notifR = await VTG.entregarVoucher(db, ref.id, { coleccion: "renovaciones", foto: imagenObj, caption: cap }); } catch (e) { console.error("rev/renovacion voucher_tg", ref.id, e?.message || e); }

    res.json({ ok: true, notificacion: VTG.estadoPublico(notifR.n), id: ref.id, imagenUrl, renovado: doc.renovado, renovadosCantidad:doc.renovadosCantidad, nuevaFecha: doc.nuevaFecha, destino: destino.key, destinoLabel: destino.label, verificacionFicha: verificacion.ok === true, operacionDiaKey: doc.operacionDiaKey });
  } catch (e) {
    console.error("rev/renovacion", e);
    res.status(e.status || 500).json({ error: e.publicError || "server", detail: e.message });
  }
});

// ── Renovación directa sin foto: actualiza fecha del servicio del cliente ──
app.post("/rev/renovar-cliente", revAuth, async (req, res) => {
  try {
    const live = await revLiveProfile(req.rev);
    if (!revCap(live, "canRenew", true)) return res.status(403).json({ error: "sin_permiso_renovar" });
    const r = await revActualizarFechaCliente({
      clienteId: req.body.clienteId,
      socioNorm: live.nombre_norm || req.rev.nombre_norm || "",
      servicioIndex: req.body.servicioIndex,
      compraId: req.body.compraId,
      nuevaFecha: req.body.nuevaFecha,
      meses: req.body.meses,
    });
    const verificacion = await revVerificarRenovacionesCliente(req.body.clienteId, [r]);
    if (!verificacion.ok) {
      const err = new Error("renovacion_no_confirmada_en_ficha"); err.status = 409; err.publicError = "renovacion_no_confirmada"; throw err;
    }
    await db.collection("renovaciones").add({
      clienteId: (req.body.clienteId || "").toString(),
      cliente: (req.body.cliente || "").toString().slice(0, 120),
      servicio: r.servicio,
      servicioIndex: r.servicioIndex,
      compraId: r.compraId || "",
      comentario: (req.body.comentario || "Renovación directa desde panel").toString().slice(0, 600),
      quien: (req.body.quien || "Panel socio").toString().slice(0, 120),
      monto: revMoneyNumber(req.body.monto),
      socio: live.nombre || live.nombre_norm || req.rev.nombre || req.rev.nombre_norm || "Revendedor",
      socio_norm: live.nombre_norm || req.rev.nombre_norm || "",
      imagenUrl: "",
      fechaAnterior: r.fechaAnterior || "",
      nuevaFecha: r.nuevaFecha || "",
      renovado: true,
      renovadosCantidad: 1,
      meses: Math.max(1, Number(req.body.meses) || 1),
      sorteoOk: r.sorteo?.ok !== false,
      boletosCreados: Math.max(0, Number(r.sorteo?.creados) || 0),
      createdAt: new Date(),
    });
    res.json({ ok: true, ...r });
  } catch (e) {
    console.error("rev/renovar-cliente", e);
    res.status(e.status || 500).json({ error: e.publicError || "server", detail: e.message });
  }
});


// ── COMPRA NUEVA / COMBO: socio envía solicitud + comprobante; avisa a Telegram según destino ──
app.post("/rev/compra", revAuth, async (req, res) => {
  try {
    const live = await revLiveProfile(req.rev);
    if (!revCap(live, "canBuy", !esRevSoloCatalogo(req.rev))) return res.status(403).json({ error: "sin_permiso_comprar" });
    const b = req.body || {};
    const socio = live.nombre || live.nombre_norm || req.rev.nombre || req.rev.nombre_norm || "Revendedor";
    const requestId = cleanTg(b.requestId, 120);
    const requestDocId = requestId ? `web_${crypto.createHash("sha256").update(`${live.id || live.nombre_norm || "socio"}|${requestId}`).digest("hex").slice(0, 40)}` : "";
    const requestRef = requestDocId ? db.collection("compras").doc(requestDocId) : null;
    if (requestRef) {
      const existente = await requestRef.get();
      if (existente.exists) {
        const d = existente.data() || {};
        return res.json({ ok:true, id:existente.id, duplicate:true, estado:d.estado||"pendiente", destino:d.destino||"", destinoLabel:d.destinoLabel||"", totalCombo:Number(d.totalCombo||0), descuentoCombo:Number(d.descuentoCombo||0), notificacion: VTG.estadoPublico(d.notificacion) });
      }
    }
    // R195 · Pedido v2: el socio DEBE elegir a quién va el comprobante (SUBLICUENTAS | RELOJES). Nunca se asume.
    const destino = destinoInfo(VTG.destinoVoucher(b.destino, { requerido: Number(b.version) === 2 }));
    // El navegador nunca decide el precio final. Se vuelve a consultar la
    // tarifa del socio autenticado para impedir valores viejos o manipulados.
    const catalogoSocio = await obtenerCatalogoSocio(db, live);
    if (String(catalogoSocio.origen || "").startsWith("respaldo")) {
      return res.status(503).json({ error: "catalogo_no_configurado", detail: "La compra se bloqueó porque la tarifa real no está configurada." });
    }

    const productosRaw = Array.isArray(b.productos) && b.productos.length
      ? b.productos.slice(0, 20)
      : [{
          servicio: b.servicio,
          servicioBase: b.servicioBase,
          catalogCategory: b.catalogCategory,
          catalogSub: b.catalogSub,
          catalogDetalle: b.catalogDetalle,
          precioCatalogo: b.precioCatalogo,
          entregaTipo: b.entregaTipo,
          perfilNombre: b.perfilNombre,
          perfilApellido: b.perfilApellido,
          correo: b.correo,
          detalleServicio: b.detalleServicio,
          acceso: b.acceso,
          serial: b.serial,
          key: b.key,
          nombreCliente: b.nombreCliente,
          dispositivo: b.dispositivo,
          marcaTv: b.marcaTv,
        }];

    const productos = productosRaw.map((p) => {
      const productoCatalogo = buscarProductoCatalogo(catalogoSocio.grupos, p);
      if (!productoCatalogo) {
        const err = new Error("producto_fuera_catalogo");
        err.status = 400;
        err.publicError = "producto_fuera_catalogo";
        throw err;
      }
      const servicio = cleanTg(productoCatalogo.nombreCompleto || p.servicio || p.nombre || "", 140);
      const precioCatalogo = productoCatalogo.p == null ? null : Number(productoCatalogo.p);
      const perfilNombre = cleanTg(p.perfilNombre, 80);
      const perfilApellido = cleanTg(p.perfilApellido, 80);
      const correo = cleanTg(p.correo, 160);
      const detalleServicio = cleanTg(p.detalleServicio, 240);
      const acceso = cleanTg(p.acceso, 220);
      const serial = cleanTg(p.serial, 220);
      const key = cleanTg(p.key, 220);
      // ✅ NUEVO: nombre del cliente (para compras tipo "correo" — Gemini,
      // Canva, invitación al correo) y dispositivo (para Disney, HBO/Max,
      // Vix, Paramount, Crunchyroll y Prime Video).
      const nombreCliente = cleanTg(p.nombreCliente, 80);
      const DISP_LABEL = { tv: "📺 TV", celular: "📱 Celular", tablet: "📱 Tablet", computadora: "💻 Computadora" };
      const dispositivo = DISP_LABEL[String(p.dispositivo || "").toLowerCase()] || cleanTg(p.dispositivo, 40);
      const MARCA_LABEL={samsung:"Samsung",lg:"LG",tcl:"TCL",roku:"Roku TV"};
      const marcaTv=MARCA_LABEL[String(p.marcaTv||"").toLowerCase()]||cleanTg(p.marcaTv,80);
      return {
        __raw: p, __item: productoCatalogo,
        id: cleanTg(productoCatalogo.id || p.catalogId || p.id, 90),
        catalogId: cleanTg(productoCatalogo.id || "", 90),
        servicio,
        servicioBase: cleanTg(productoCatalogo.n || p.servicioBase, 100),
        entregaTipo: cleanTg(productoCatalogo.entregaTipo || p.entregaTipo || "", 60),
        // R108: cantidad solo para cuentas completas (1–20, 25, 30, 40, 50); perfiles siempre 1.
        cantidad: String(productoCatalogo.entregaTipo || p.entregaTipo || "").toLowerCase() === "cuenta_completa" && R108_CANTIDADES.has(Number(p.cantidad)) ? Number(p.cantidad) : 1,
        entregaCanal: cleanTg(productoCatalogo.entregaCanal || p.entregaCanal || "manual", 60),
        catalogCategory: cleanTg(productoCatalogo.categoria || p.catalogCategory || "", 120),
        catalogSub: cleanTg(productoCatalogo.s || p.catalogSub || "", 160),
        catalogDetalle: cleanTg(productoCatalogo.d || p.catalogDetalle || "", 500),
        precioCatalogo,
        perfilNombre,
        perfilApellido,
        perfil: `${perfilNombre} ${perfilApellido}`.trim(),
        correo,
        detalleServicio,
        acceso,
        serial,
        key,
        nombreCliente,
        dispositivo,
        marcaTv,
      };
    }).filter((p) => p.servicio);

    if (!productos.length) return res.status(400).json({ error: "falta_servicio" });

    // ── Pedido v2: cliente principal + destinatario, datos y notas por renglón (validados aquí, no solo en el navegador) ──
    const v2 = Number(b.version) === 2;
    let clientePrincipal = null;
    // Brief maestro 30/10/2026 · un pedido = un cliente = un pago. Un servicio "para otro cliente" ya no se acepta:
    // se rechaza aquí aunque el navegador haya sido manipulado. Otro cliente → otro pedido y otro comprobante.
    if (v2 && productosRaw.some((p) => p && p.destinatario && p.destinatario.tipo === "otro")) {
      return res.status(400).json({ error: "cliente_unico", detail: "Un pedido es para un solo cliente. Haga otro pedido (con su propio pago) para la otra persona." });
    }
    if (v2) {
      const cp = b.clientePrincipal && typeof b.clientePrincipal === "object" ? b.clientePrincipal : {};
      clientePrincipal = { clienteId: cleanTg(cp.clienteId, 120), nombre: cleanTg(cp.nombre, 80), apellido: cleanTg(cp.apellido, 80) };
      const errores = CS.validarPrincipal(clientePrincipal);
      productos.forEach((p, i) => {
        const { renglon, errores: e } = CS.normalizarRenglon(p.__raw || {}, { ...(p.__item || {}), categoria: p.__item?.categoria || p.catalogCategory }, clientePrincipal, i);
        errores.push(...e);
        Object.assign(p, {
          renglonId: renglon.renglonId, modalidad: renglon.modalidad, modalidadInferida: renglon.modalidadInferida,
          destinatario: renglon.destinatario, clienteNombre: renglon.clienteNombre, nombreCliente: renglon.clienteNombre,
          perfilNombre: renglon.perfilNombre, perfilApellido: renglon.perfilApellido, perfil: renglon.perfil,
          dispositivo: renglon.dispositivo, correo: renglon.correo, marcaTv: renglon.marcaTv, modeloTv: renglon.modeloTv,
          detalleServicio: renglon.detalleServicio, datoRequerido: renglon.datoRequerido, notas: renglon.notas,
          ...(renglon.planHbo ? { planHbo: renglon.planHbo } : {}), // R196v
          cantidad: renglon.modalidad === "cuenta_completa" ? renglon.cantidad : 1,
        });
      });
      if (errores.length) return res.status(400).json({ error: "datos_incompletos", errores: errores.slice(0, 40) });
      // Los clientes elegidos de la lista deben ser del socio (nunca de otro).
      const aliases = revSocioAliases(live, req.rev);
      const ids = [clientePrincipal.clienteId].filter(Boolean);
      for (const id of ids.slice(0, 25)) {
        const snapCli = await db.collection("clientes").doc(id).get();
        if (!snapCli.exists || !revFiltrarClientePorAliases(snapCli.data() || {}, aliases).servicios.length) return res.status(403).json({ error: "cliente_ajeno" });
      }
    }
    productos.forEach((p) => { if (!p.planHbo) { const ph = require("./lib_hbo_planes").planDesdeNombreProducto(p.servicio || ""); if (ph) p.planHbo = ph; } }); // R196v · también pedidos v1
    productos.forEach((p) => { delete p.__raw; delete p.__item; });

    const comentario = cleanTg(b.comentario, 700);
    const clienteNombre = v2 ? clientePrincipal.nombre : cleanTg(b.clienteNombre, 80);
    const clienteApellido = v2 ? clientePrincipal.apellido : cleanTg(b.clienteApellido, 80);
    const subtotalCatalogo = productos.reduce((a, p) => a + (p.precioCatalogo !== null ? Number(p.precioCatalogo || 0) * (p.cantidad || 1) : 0), 0);
    const conPrecio = productos.reduce((a, p) => a + (p.precioCatalogo !== null ? (p.cantidad || 1) : 0), 0);
    const hayComisionR108 = productos.some((p) => p.precioCatalogo === null);
    const descuentoCombo = Math.min(Math.max(conPrecio - 1, 0), 4) * 10; // 2=10, 3=20, 4=30, 5+=40
    const totalCombo = Math.max(0, subtotalCatalogo - descuentoCombo);
    // R108: con precio fijo el monto es SIEMPRE el total del servidor (nunca el del navegador) y el banco es obligatorio.
    // Si hay productos "por comisión" no se inventa un monto: siguen la regla anterior, fuera del flujo automático.
    // El socio confirmó un total; si el catálogo cambió desde entonces no se registra nada: se le muestra el nuevo total.
    if (v2 && b.totalEsperado !== undefined && b.totalEsperado !== null && b.totalEsperado !== "" && !hayComisionR108 && Number(b.totalEsperado) !== totalCombo) {
      return res.status(409).json({ error: "precio_cambio", subtotalCatalogo, descuentoCombo, totalCombo, precios: productos.map((p) => ({ renglonId: p.renglonId || "", catalogId: p.catalogId, precio: p.precioCatalogo })) });
    }
    // Stock manual con cantidad: se revisa ahora y se descuenta dentro de la misma transacción del pedido.
    const coleccionStock = catalogoSocio.tarifaId === "general" ? "precios" : "precios_especiales";
    const pedidasStock = CS.unidadesPorProducto(productos.map((p) => ({ catalogId: p.catalogId, cantidad: p.cantidad || 1 })));
    const itemsStock = catalogoPlano(catalogoSocio.grupos).filter((it) => it.id && pedidasStock.has(it.id) && String(it.stockModo || "").toLowerCase() === "manual");
    for (const it of itemsStock) if (CS.stockInsuficiente(it, pedidasStock.get(it.id))) return res.status(409).json({ error: "sin_stock", detail: `${it.nombreCompleto || it.n}: no hay disponibilidad suficiente.`, catalogId: it.id });
    const stockRefs = itemsStock.map((it) => ({ ref: db.collection(coleccionStock).doc(String(it.id)), pedidas: pedidasStock.get(it.id), nombre: it.nombreCompleto || it.n }));
    const reservarStock = async (tx) => {
      const snaps = [];
      for (const x of stockRefs) snaps.push(await tx.get(x.ref));
      return () => snaps.forEach((sn, i) => {
        const d = sn.exists ? (sn.data() || {}) : null;
        if (!d) return;
        if (CS.stockInsuficiente(d, stockRefs[i].pedidas)) { const e = new Error("sin_stock"); e.status = 409; e.publicError = "sin_stock"; e.detail = `${stockRefs[i].nombre}: no hay disponibilidad suficiente.`; throw e; }
        if (d.stockCantidad !== null && d.stockCantidad !== undefined && d.stockCantidad !== "") tx.update(stockRefs[i].ref, { stockCantidad: Math.max(0, Number(d.stockCantidad) - stockRefs[i].pedidas), updatedAt: new Date() });
      });
    };
    const monto = hayComisionR108 ? (revMoneyNumber(b.monto) || totalCombo || 0) : totalCombo;
    const bancoR108 = hayComisionR108 ? null : await r108Banco(b.bancoId);
    if (!hayComisionR108 && !bancoR108) return res.status(400).json({ error: "falta_banco", detail: "Elija el banco donde se hizo el pago." });
    if (!hayComisionR108 && !requestRef) return res.status(400).json({ error: "falta_operation_id", detail: "Actualice el panel." });
    // Oct-2026 · Web Socios: el banco también se pide en compras por comisión. Se guarda (y sale en Telegram),
    // pero esas compras siguen fuera del registro automático de ingresos, igual que antes.
    const bancoComision = hayComisionR108 && b.bancoId ? await r108Banco(b.bancoId) : null;
    const servicio = productos.length > 1
      ? `Combo ${productos.length} plataformas`
      : productos[0].servicio;

    const imagenObj = await uploadPanelImage(b.imagen, "compras");
    const imagenUrl = imagenObj.url || "";
    // Un pago = un pedido. Si llega exactamente la misma imagen de otro pedido, no se rechaza ni se deduplica por monto:
    // el pedido se crea marcado para revisión del equipo.
    const comprobanteHash = (() => { const m = String(b.imagen || "").match(/;base64,(.+)$/); return m ? crypto.createHash("sha256").update(Buffer.from(m[1], "base64")).digest("hex") : ""; })();
    let pagoRevision = null;
    if (comprobanteHash) {
      try {
        const rep = await db.collection("compras").where("comprobanteHash", "==", comprobanteHash).limit(3).get();
        const otro = rep.docs.find((x) => x.id !== requestDocId);
        if (otro) pagoRevision = { motivo: "posible_comprobante_repetido", pedidoRelacionado: otro.id, pedidoRelacionadoRef: otro.id.slice(-6).toUpperCase() };
      } catch (e) { console.error("comprobanteHash", e?.message || e); }
    }

    const doc = {
      tipo: "compra",
      version: v2 ? 2 : 1,
      ...(v2 ? { clientePrincipal } : {}),
      requestId,
      servicio,
      productos,
      comboCantidad: productos.length,
      subtotalCatalogo,
      descuentoCombo,
      totalCombo,
      entregaTipo: productos[0].entregaTipo || "",
      entregaCanal: productos[0].entregaCanal || "manual",
      catalogCategory: productos[0].catalogCategory || "",
      catalogSub: productos[0].catalogSub || "",
      catalogDetalle: productos[0].catalogDetalle || "",
      detalleServicio: productos[0].detalleServicio || "",
      precioCatalogo: productos[0].precioCatalogo,
      clienteNombre,
      clienteApellido,
      cliente: `${clienteNombre} ${clienteApellido}`.trim(),
      perfilNombre: productos[0].perfilNombre || "",
      perfilApellido: productos[0].perfilApellido || "",
      perfil: productos[0].perfil || "",
      correo: productos[0].correo || "",
      acceso: productos[0].acceso || "",
      serial: productos[0].serial || "",
      key: productos[0].key || "",
      nombreCliente: productos[0].nombreCliente || "",
      dispositivo: productos[0].dispositivo || "",
      marcaTv: productos[0].marcaTv || "",
      comentario,
      monto, montoAutomatico: !hayComisionR108, ...(bancoR108 ? { bancoId: bancoR108.id, banco: bancoR108.nombre } : bancoComision ? { bancoId: bancoComision.id, banco: bancoComision.nombre } : {}), // R108
      destino: destino.key,
      destinoLabel: destino.label,
      socio,
      socio_norm: live.nombre_norm || req.rev.nombre_norm || "",
      tarifaId: catalogoSocio.tarifaId,
      imagenUrl,
      // Si Storage falla, Telegram recibe la foto por buffer; para que Panel Dios también la vea,
      // guardamos una copia liviana en Firestore cuando no hay URL pública.
      imagenData: imagenUrl ? "" : (imagenObj.dataUri && imagenObj.dataUri.length < 850000 ? imagenObj.dataUri : ""),
      imagenStorageError: imagenObj.storageError || "",
      comprobanteHash, ...(pagoRevision ? { pagoRevision } : {}),
      estado: "pendiente",
      detalleEstado: "Pedido recibido",
      estadoHistorial: [{ estado: "pendiente", detalle: "Pedido recibido", at: new Date().toISOString(), por: "sistema" }],
      createdAt: new Date(),
      estadoUpdatedAt: new Date(),
    };
    // R195 · Outbox durable: el aviso a Telegram nace en la MISMA escritura del pedido (si el envío falla, queda pendiente).
    const compraIdPrevisto = requestDocId || db.collection("compras").doc().id;
    doc.notificacion = VTG.notificacionInicial(compraIdPrevisto, destino.key);
    if (imagenObj.bucketName && imagenObj.url) doc.comprobanteRef = { bucket: imagenObj.bucketName, carpeta: "compras" };
    let ref;
    if (requestRef && bancoR108) {
      // R108: pedido + venta + ingreso del socio en UNA transacción (o todo, o nada); el requestId evita duplicados.
      ref = requestRef;
      const r = await db.runTransaction(async (tx) => {
        const ya = await tx.get(ref);
        if (ya.exists) return { dup: ya.data() || {} };
        const cicloId = await r108CicloId(tx);
        const aplicarStock = await reservarStock(tx);
        aplicarStock();
        tx.set(ref, doc);
        r108Movs(tx, { idBase: `socio_compra_${ref.id}`, subtipo: "compra_socio", total: totalCombo, banco: bancoR108, cicloId,
          rel: { socioNorm: live.nombre_norm || req.rev.nombre_norm || "", socioNombre: socio, clienteNombre: r121NombreCompraSocio(productos, doc.cliente, socio), compraId: ref.id, pedidoId: ref.id, plataforma: productos.map((p) => p.servicio).join(", ").slice(0, 200), tipoOrigen: "compra", operationId: requestId, destino: destino.key,
            productosSocio: productos.map((p) => ({ servicio: p.servicio, perfil: p.perfil || p.nombreCliente || "", cantidad: p.cantidad || 1, precioUnitario: p.precioCatalogo, entregaTipo: p.entregaTipo })), subtotal: subtotalCatalogo, descuento: descuentoCombo },
          auditoria: { accion: "compra_socio", targetType: "compra", targetId: ref.id, detalle: `Socio ${socio} compró ${productos.map((p) => `${p.servicio}${(p.cantidad || 1) > 1 ? ` x${p.cantidad}` : ""} (L${p.precioCatalogo})`).join(" + ")} · subtotal L${subtotalCatalogo} − desc L${descuentoCombo} = L${totalCombo} en ${bancoR108.nombre}`, after: { subtotal: subtotalCatalogo, descuento: descuentoCombo, total: totalCombo, banco: bancoR108.nombre } } });
        return {};
      });
      if (r.dup) { const d = r.dup; return res.json({ ok:true, id:ref.id, duplicate:true, estado:d.estado||"pendiente", destino:d.destino||"", destinoLabel:d.destinoLabel||"", totalCombo:Number(d.totalCombo||0), descuentoCombo:Number(d.descuentoCombo||0), notificacion: VTG.estadoPublico(d.notificacion) }); }
    } else if (requestRef) {
      ref = requestRef;
      try {
        if (stockRefs.length) {
          const dupTx = await db.runTransaction(async (tx) => {
            const ya = await tx.get(ref);
            if (ya.exists) return ya.data() || {};
            const aplicarStock = await reservarStock(tx);
            aplicarStock();
            tx.set(ref, doc);
            return null;
          });
          if (dupTx) { const d = dupTx; return res.json({ ok:true, id:ref.id, duplicate:true, estado:d.estado||"pendiente", destino:d.destino||"", destinoLabel:d.destinoLabel||"", totalCombo:Number(d.totalCombo||0), descuentoCombo:Number(d.descuentoCombo||0), notificacion: VTG.estadoPublico(d.notificacion) }); }
        } else await ref.create(doc);
      } catch (createErr) {
        if (createErr?.code === 6 || createErr?.code === "already-exists" || /already exists/i.test(String(createErr?.message || ""))) {
          const existente = await ref.get();
          const d = existente.data() || {};
          return res.json({ ok:true, id:ref.id, duplicate:true, estado:d.estado||"pendiente", destino:d.destino||"", destinoLabel:d.destinoLabel||"", totalCombo:Number(d.totalCombo||0), descuentoCombo:Number(d.descuentoCombo||0), notificacion: VTG.estadoPublico(d.notificacion) });
        }
        throw createErr;
      }
    } else {
      ref = db.collection("compras").doc(compraIdPrevisto);
      await ref.set(doc);
    }

    const productoLineas = v2 ? CS.lineasTelegram(productos, CS.nombreCompleto(clientePrincipal)) : productos.flatMap((p, i) => {
      const precio = p.precioCatalogo === null ? "Por comisión" : `L${p.precioCatalogo}`;
      const datos = [];
      if (p.perfil) datos.push(`Perfil: ${p.perfil}`);
      if (p.dispositivo) datos.push(`Dispositivo: ${p.dispositivo}`);
      if (p.marcaTv) datos.push(`Marca / sistema TV: ${p.marcaTv}`);
      if (p.nombreCliente) datos.push(`Cliente: ${p.nombreCliente}`);
      if (p.correo) datos.push(`Correo: ${p.correo}`);
      if (p.detalleServicio) datos.push(`Detalle: ${p.detalleServicio}`);
      if (p.acceso) datos.push(`Acceso: ${p.acceso}`);
      if (p.serial) datos.push(`Serial: ${p.serial}`);
      if (p.key) datos.push(`Key: ${p.key}`);
      if (p.entregaCanal && p.entregaCanal !== "manual") {
        const canalLabel = { bot_tg:"Bot TG / código", inventario:"Inventario Sublichat", invitacion:"Invitación al correo", iptv:"TV Digital / IPTV" }[p.entregaCanal] || p.entregaCanal;
        datos.push(`Flujo: ${canalLabel}`);
      }
      if (!datos.length && p.entregaTipo) datos.push(`Entrega: ${p.entregaTipo}`);
      return [
        `${i + 1}) ${p.servicio} — ${precio}`,
        ...datos.slice(0, 4).map((x) => `   • ${cleanTg(x, 150)}`),
      ];
    });

    const capLineas = [
      productos.length > 1 ? `🛒 *COMPRA COMBO*` : `🛒 *COMPRA NUEVA*`,
      `━━━━━━━━━━━━━━`,
      `📍 Avisar: ${destino.label}`,
      `👤 Socio: ${cleanTg(socio, 80)}`,
      v2 ? `🙍 Cliente principal: ${cleanTg(CS.nombreCompleto(clientePrincipal), 80)}` : "",
      `📦 Productos:`,
      ...productoLineas,
      ``,
      productos.length > 1
        ? `💰 Subtotal: L${subtotalCatalogo}\n🏷️ Descuento combo: L${descuentoCombo}\n✅ Total sugerido: L${totalCombo}\n💵 Monto pagado: ${monto ? `L${monto}` : "—"}`
        : `💵 Monto pagado: ${monto ? `L${monto}` : "—"}${productos[0].precioCatalogo !== null ? ` | Catálogo: L${productos[0].precioCatalogo}` : ""}`,
      doc.banco ? `🏦 Banco: ${cleanTg(doc.banco, 40)}` : "",
      pagoRevision ? `⚠️ Posible comprobante repetido (igual al pedido #${pagoRevision.pedidoRelacionadoRef}). Revisar antes de aprobar.` : "",
      comentario ? `📝 Nota: ${cleanTg(comentario, 220)}` : "",
      (imagenUrl || imagenObj.buffer) ? `📎 Comprobante adjunto` : `⚠️ Sin comprobante`,
      `🆔 Ref: ${ref.id.slice(-6)}`,
    ].filter((x) => x !== "");
    const cap = capLineas.join("\n").slice(0, 950);

    // R195 · Entrega verificable: "enviado" solo con message_id de Telegram. Si falla, el pedido y el voucher quedan y se reintenta.
    let notif = { n: doc.notificacion };
    try { notif = await VTG.entregarVoucher(db, ref.id, { coleccion: "compras", foto: imagenObj, caption: cap }); }
    catch (e) { console.error("rev/compra voucher_tg", ref.id, e?.message || e); }

    // Fase 2 · push SOLO al vendedor que eligió el socio (Sublicuentas o Relojes): pedido nuevo, plata esperando entrega.
    // Sin datos de entrega en el aviso.
    const resumenPush = productos.map((p) => `${p.servicioBase || p.servicio}${(p.cantidad || 1) > 1 ? ` ×${p.cantidad}` : ""}`).join(", ");
    await require("./lib_push").avisar(db, admin, {
      usuarios: [destino.key],
      titulo: `🛒 Pedido de ${cleanTg(socio, 40)}`,
      cuerpo: `${resumenPush}${totalCombo ? ` · L${totalCombo}` : ""}`,
      data: { tipo: "pedido", ir: "inicio", id: ref.id },
    });

    res.json({ ok: true, id: ref.id, ref: ref.id.slice(-6).toUpperCase(), imagenUrl, destino: destino.key, destinoLabel: destino.label, subtotalCatalogo, totalCombo, descuentoCombo, estado: "pendiente", comprobante: !!(imagenUrl || imagenObj.buffer), notificacion: VTG.estadoPublico(notif.n) });
  } catch (e) {
    console.error("rev/compra", e);
    res.status(e.status || 500).json({ error: e.publicError || "server", detail: e.detail || e.message });
  }
});

app.get("/rev/sugerencias/mias", revAuth, async (req, res) => {
  try {
    const live = await revLiveProfile(req.rev);
    const aliases = revSocioAliases(live, req.rev);
    const snaps = await Promise.all(aliases.map(alias =>
      db.collection("sugerencias").where("nombre_norm", "==", alias).get()
    ));
    const docs = new Map();
    snaps.forEach(snap => snap.docs.forEach(doc => docs.set(doc.id, doc)));
    const items = Array.from(docs.values()).map(doc => {
      const d = doc.data() || {};
      return {
        id: doc.id,
        texto: String(d.texto || "").slice(0, 4000),
        destino: String(d.destino || ""),
        destinoLabel: String(d.destinoLabel || d.destino || "Equipo"),
        estado: String(d.estado || (d.respuesta ? "respondida" : "enviada")),
        respuesta: String(d.respuesta || d.respuestaTexto || "").slice(0, 4000),
        pedidoId: String(d.pedidoId || ""), pedidoRef: String(d.pedidoRef || ""), renglonId: String(d.renglonId || ""),
        createdAt: d.createdAt || null,
        respondedAt: d.respondedAt || d.respuestaAt || null,
      };
    }).sort((a,b) => {
      const ms = (v) => v?.toMillis ? v.toMillis() : (v?._seconds || v?.seconds) ? Number(v._seconds || v.seconds) * 1000 : new Date(v || 0).getTime() || 0;
      return ms(b.createdAt) - ms(a.createdAt);
    }).slice(0, 60);
    res.set("Cache-Control", "no-store");
    res.json(items);
  } catch (e) { console.error("rev/sugerencias/mias", e); res.status(500).json({ error: "server" }); }
});

app.post("/rev/sugerencia", revAuth, async (req, res) => {
  try {
    const live = await revLiveProfile(req.rev);
    if (!revCap(live, "buzon", true)) return res.status(403).json({ error: "sin_permiso_buzon" });
    const texto = (req.body.texto || "").toString().trim().slice(0, 1000);
    if (!texto) return res.status(400).json({ error: "falta_texto" });
    const nombre = req.rev.nombre || req.rev.nombre_norm || "Revendedor";

    let destino = (req.body.destino || "sublicuentas").toString().trim();
    // Oct-2026 · consulta vinculada a un pedido (y renglón): solo pedidos del mismo socio; va al destino del pedido.
    let pedido = null;
    const pedidoId = cleanTg(req.body.pedidoId, 120);
    if (pedidoId) {
      const ps = await db.collection("compras").doc(pedidoId).get();
      const aliases = revSocioAliases(live, req.rev);
      if (!ps.exists || !aliases.includes(revNormKey((ps.data() || {}).socio_norm || ""))) return res.status(403).json({ error: "pedido_ajeno" });
      pedido = { id: ps.id, ref: ps.id.slice(-6).toUpperCase(), renglonId: cleanTg(req.body.renglonId, 60), servicio: cleanTg((ps.data() || {}).servicio, 120) };
      destino = (ps.data() || {}).destino || destino;
    }
    const destinoCfg = destinoInfo(destino);
    const quien = destinoCfg.label;

    await db.collection("sugerencias").add({
      texto, nombre, nombre_norm: req.rev.nombre_norm || "",
      destino: destinoCfg.key, destinoLabel: destinoCfg.label, estado: "enviada", createdAt: new Date(),
      ...(pedido ? { pedidoId: pedido.id, pedidoRef: pedido.ref, renglonId: pedido.renglonId, tipo: "consulta_pedido" } : {}),
    });

    const aviso = pedido
      ? `🧾 *Consulta de pedido #${pedido.ref}* (${quien})\n👤 ${nombre}\n📦 ${pedido.servicio}\n\n${texto}`
      : `💬 *Nueva sugerencia* (${quien})\n👤 ${nombre}\n\n${texto}`;
    const ids = await getDestinoChatIds(destinoCfg.key);
    await Promise.all(ids.map((id) => sendTelegramMessage(id, aviso)));

    res.json({ ok: true });
  } catch (e) { console.error("rev/sugerencia", e); res.status(500).json({ error: "server" }); }
});
app.get("/rev/admin/revendedores", revAdminAuth, adminPermission("equipo.manage"), async (req, res) => {
  try {
    const [revSnap, cliSnap] = await Promise.all([
      db.collection("revendedores").get(),
      db.collection("clientes").get(),
    ]);
    const porVend = {};
    cliSnap.docs.forEach((d) => {
      const c = d.data();
      (Array.isArray(c.servicios) ? c.servicios : []).forEach((s) => {
        const key = vendedorEfectivoServicio(s, c).vendedor_norm;
        if (!key) return;
        if (!porVend[key]) porVend[key] = { clientesIds: new Set(), servicios: 0, vencidos: 0, porVencer: 0 };
        porVend[key].clientesIds.add(d.id);
        porVend[key].servicios++;
        const n = revDiasRest(revParseFecha(s.fechaRenovacion || s.vencimiento || s.fechaFin));
        if (n != null) { if (n < 0) porVend[key].vencidos++; else if (n <= 5) porVend[key].porVencer++; }
      });
    });
    // "Geissel" fue un alias histórico de "Geisell". Se muestra una sola
    // cuenta y se le asignan también los clientes guardados con el alias.
    const cuentas = new Map();
    revSnap.docs.forEach((d) => {
      const r = d.data() || {};
      const rawKey = normVendedor(r.nombre_norm || r.nombre || d.id);
      const k = rawKey === "geissel" ? "geisell" : rawKey;
      const stats = porVend[k] || { clientesIds: new Set(), servicios: 0, vencidos: 0, porVencer: 0 };
      const capabilities = capacidadesRevendedor({ id: d.id, ...r, nombre_norm: k });
      const item = {
        id: d.id,
        nombre: k === "geisell" ? "Geisell" : (r.nombre || d.id),
        nombre_norm: k,
        nombreMostrar: r.nombreMostrar || "",
        activo: r.activo !== false,
        soloCatalogo: !capabilities.canBuy,
        sinCompras: !capabilities.canBuy,
        capabilities,
        permisos: capabilities,
        telegramId: r.telegramId || "",
        telefono: r.telefono || "",
        tarifaId: r.tarifaId || "general",
        etiquetaRenovacion: r.etiquetaRenovacion || "",
        clientes: stats.clientesIds.size,
        servicios: stats.servicios,
        vencidos: stats.vencidos,
        porVencer: stats.porVencer,
        _rawKey: rawKey,
      };
      const anterior = cuentas.get(k);
      // Si coexistieran ambos documentos, conservar el que ya está escrito
      // correctamente como Geisell; si no, el alias sigue funcionando.
      if (!anterior || (rawKey === "geisell" && anterior._rawKey !== "geisell")) cuentas.set(k, item);
    });
    const lista = Array.from(cuentas.values())
      .map(({ _rawKey, ...item }) => item)
      .sort((a, b) => b.clientes - a.clientes);
    res.json(lista);
  } catch (e) { console.error("rev/admin", e); res.status(500).json({ error: "server" }); }
});

// ── ADMIN: historial de comprobantes con foto para Panel Dios ──
app.get("/rev/admin/comprobantes", revAdminAuth, adminAnyPermission(["socios.pagos.read","socios.pagos.own.read"]), async (req, res) => {
  try {
    const limit = Math.min(Number(req.query.limit) || 120, 300);
    const snap = await db.collection("renovaciones").orderBy("createdAt", "desc").limit(limit).get();
    const lista = snap.docs.map((d) => {
      const r = d.data() || {};
      const ts = r.createdAt?._seconds ? r.createdAt._seconds * 1000 :
                 r.createdAt?.seconds ? r.createdAt.seconds * 1000 :
                 r.createdAt instanceof Date ? r.createdAt.getTime() : Date.now();
      return {
        id: d.id,
        clienteId: r.clienteId || "",
        cliente: r.cliente || "",
        servicio: r.servicio || "",
        comentario: r.comentario || "",
        quien: r.quien || "",
        monto: Number(r.monto) || 0,
        destino: r.destino || "sublicuentas",
        destinoLabel: r.destinoLabel || destinoInfo(r.destino).label,
        socio: r.socio || "",
        socio_norm: r.socio_norm || "",
        imagenUrl: r.imagenUrl || r.imagenData || "",
        renovado: !!r.renovado,
        fechaAnterior: r.fechaAnterior || "",
        nuevaFecha: r.nuevaFecha || "",
        estadoPago: r.estadoPago || "sin_confirmar", // R203
        pagoConfirmadoPor: r.pagoConfirmadoPor || "",
        renovadosCantidad: Math.max(1, Number(r.renovadosCantidad) || 1),
        ts,
      };
    });
    const profile = adminScopeProfile(req);
    const visible = isFullAdmin(req) ? lista : lista.filter((x) => revNormKey(x.destino) === profile);
    res.json(visible);
  } catch (e) { console.error("rev/admin/comprobantes", e); res.status(500).json({ error: "server" }); }
});


// ── R203 · SubliPoints: confirmar/anular el COBRO de una renovación (solo así suma +1 por servicio) ──
app.post("/rev/admin/comprobantes/:id/pago", revAdminAuth, adminAnyPermission(["socios.compras.write","socios.compras.own.write"]), async (req, res) => {
  try {
    const accion = String(req.body?.accion || "").trim().toLowerCase();
    if (!["confirmar", "anular"].includes(accion)) return res.status(400).json({ error: "accion_invalida" });
    const ref = db.collection("renovaciones").doc(String(req.params.id || ""));
    const snap = await ref.get();
    if (!snap.exists) return res.status(404).json({ error: "no_existe" });
    const r = snap.data() || {};
    if (!isFullAdmin(req) && revNormKey(r.destino || "sublicuentas") !== adminScopeProfile(req)) return res.status(403).json({ ok:false, error:"fuera_de_ambito" });
    const SP = require("./lib_sublipoints");
    const por = cleanTg(req.admin?.nombre || "Admin", 80), at = new Date();
    let sublipoints;
    if (accion === "confirmar") {
      if (!r.renovado) return res.status(409).json({ error: "no_renovado" });
      sublipoints = await SP.otorgar(db, { clave: SP.claveRenovacion(ref.id), socio: r.socio, socioNorm: r.socio_norm || r.socio, tipo: "renovacion", unidades: Math.max(1, Number(r.renovadosCantidad) || 1), ref: ref.id.slice(-6), detalle: `${String(r.servicio || "Renovación").slice(0, 80)} · ${String(r.cliente || "").slice(0, 60)}`, fechaEvento: r.createdAt, por });
      if (r.estadoPago !== "confirmado") await ref.update({ estadoPago: "confirmado", pagoConfirmadoPor: por, pagoConfirmadoAt: at, pagoHistorial: admin.firestore.FieldValue.arrayUnion({ accion, por, at: at.toISOString() }) });
    } else {
      sublipoints = await SP.revertir(db, { clave: SP.claveRenovacion(ref.id), motivo: cleanTg(req.body?.motivo || "Pago anulado", 160), por });
      await ref.update({ estadoPago: "anulado", pagoAnuladoPor: por, pagoAnuladoAt: at, pagoHistorial: admin.firestore.FieldValue.arrayUnion({ accion, por, at: at.toISOString() }) });
    }
    res.json({ ok: true, id: ref.id, estadoPago: accion === "confirmar" ? "confirmado" : "anulado", sublipoints });
  } catch (e) { console.error("rev/admin/comprobantes/pago", e); res.status(500).json({ error: "server" }); }
});
// ── R203 · SubliPoints: resumen del socio (solo el suyo) y ranking del mes para administración ──
app.get("/rev/sublipoints", revAuth, async (req, res) => {
  try { const SP = require("./lib_sublipoints"); res.json(await SP.resumenSocio(db, req.rev.nombre_norm || req.rev.nombre || "")); }
  catch (e) { console.error("rev/sublipoints", e); res.status(500).json({ error: "server" }); }
});
app.get("/rev/admin/sublipoints", revAdminAuth, adminAnyPermission(["socios.pagos.read","socios.pagos.own.read","socios.compras.read","socios.compras.own.read"]), async (req, res) => {
  try {
    const SP = require("./lib_sublipoints");
    const mes = /^\d{4}-\d{2}$/.test(String(req.query.mes || "")) ? String(req.query.mes) : SP.mesHN();
    const [cfg, ranking] = await Promise.all([SP.config(db), SP.rankingMes(db, mes)]);
    res.json({ ok: true, mes, inicio: cfg.inicio, ranking });
  } catch (e) { console.error("rev/admin/sublipoints", e); res.status(500).json({ error: "server" }); }
});

// ── ADMIN: historial de compras nuevas con comprobante para Panel Dios ──
app.get("/rev/admin/compras", revAdminAuth, adminAnyPermission(["socios.compras.read","socios.compras.own.read"]), async (req, res) => {
  try {
    const limit = Math.min(Number(req.query.limit) || 120, 300);
    const snap = await db.collection("compras").orderBy("createdAt", "desc").limit(limit).get();
    const lista = snap.docs.map((d) => {
      const r = d.data() || {};
      const ts = r.createdAt?._seconds ? r.createdAt._seconds * 1000 :
                 r.createdAt?.seconds ? r.createdAt.seconds * 1000 :
                 r.createdAt instanceof Date ? r.createdAt.getTime() : Date.now();
      return {
        id: d.id,
        servicio: r.servicio || "",
        productos: Array.isArray(r.productos) ? r.productos : [],
        comboCantidad: Number(r.comboCantidad) || (Array.isArray(r.productos) ? r.productos.length : 1),
        subtotalCatalogo: Number(r.subtotalCatalogo) || 0,
        descuentoCombo: Number(r.descuentoCombo) || 0,
        totalCombo: Number(r.totalCombo) || 0,
        entregaTipo: r.entregaTipo || "",
        catalogCategory: r.catalogCategory || "",
        catalogSub: r.catalogSub || "",
        catalogDetalle: r.catalogDetalle || "",
        detalleServicio: r.detalleServicio || "",
        precioCatalogo: r.precioCatalogo === null || r.precioCatalogo === undefined ? null : Number(r.precioCatalogo) || 0,
        cliente: r.cliente || `${r.clienteNombre || ""} ${r.clienteApellido || ""}`.trim(),
        clientePrincipal: r.clientePrincipal || null, version: Number(r.version) || 1,
        entregaResumen: CS.pedidoPublico(d.id, r).entregaResumen, historicoAnterior: CS.pedidoPublico(d.id, r).historicoAnterior, pagoRevision: r.pagoRevision || null,
        perfil: r.perfil || `${r.perfilNombre || ""} ${r.perfilApellido || ""}`.trim(),
        correo: r.correo || "",
        acceso: r.acceso || "",
        serial: r.serial || "",
        key: r.key || "",
        comentario: r.comentario || "",
        monto: revMoneyNumber(r.monto),
        destino: r.destino || "sublicuentas",
        destinoLabel: r.destinoLabel || destinoInfo(r.destino).label,
        socio: r.socio || "",
        socio_norm: r.socio_norm || "",
        imagenUrl: r.imagenUrl || r.imagenData || "",
        estado: r.estado || "pendiente",
        detalleEstado: r.detalleEstado || "",
        estadoUpdatedAt: r.estadoUpdatedAt || r.updatedAt || r.createdAt || "",
        estadoHistorial: Array.isArray(r.estadoHistorial) ? r.estadoHistorial.slice(-15) : [],
        notificacion: r.notificacion ? { estado: r.notificacion.estado, intentos: r.notificacion.intentos || 0, lastError: r.notificacion.lastError || "", entregadoAt: r.notificacion.entregadoAt || null, fuente: r.notificacion.fuente || "" } : null, // R195
        ts,
      };
    });
    const profile = adminScopeProfile(req);
    const visible = isFullAdmin(req) ? lista : lista.filter((x) => revNormKey(x.destino) === profile);
    res.json(visible);
  } catch (e) { console.error("rev/admin/compras", e); res.status(500).json({ error: "server" }); }
});

// ── R195 · ADMIN: comprobantes que NO constan como entregados en Telegram (incluye pedidos anteriores sin registro) ──
app.get("/rev/admin/comprobantes-telegram", revAdminAuth, adminAnyPermission(["socios.compras.read","socios.compras.own.read"]), async (req, res) => {
  try {
    const desdeMs = Date.parse(String(req.query.desde || "")) || (Date.now() - 45 * 86400000);
    const filas = [];
    for (const coleccion of ["compras", "renovaciones"]) {
      const snap = await db.collection(coleccion).orderBy("createdAt", "desc").limit(Math.min(Number(req.query.limit) || 400, 1000)).get();
      snap.docs.forEach((d) => { const f = VTG.filaReporte(d.id, d.data() || {}, coleccion); if (Date.parse(f.fecha || 0) >= desdeMs && f.estado !== "enviado") filas.push(f); });
    }
    const profile = adminScopeProfile(req);
    const visibles = isFullAdmin(req) ? filas : filas.filter((x) => x.destino.toLowerCase() === profile);
    res.set("Cache-Control", "no-store");
    res.json({ ok: true, desde: new Date(desdeMs).toISOString(), total: visibles.length, porEstado: visibles.reduce((a, x) => ((a[x.estado] = (a[x.estado] || 0) + 1), a), {}), items: visibles.sort((a, b) => String(b.fecha).localeCompare(String(a.fecha))) });
  } catch (e) { console.error("rev/admin/comprobantes-telegram", e); res.status(500).json({ error: "server" }); }
});
// Diagnóstico de rutas (sin token ni ids completos): fuente de cada chat y si el bot puede escribir ahí.
app.get("/rev/admin/comprobantes-telegram/diagnostico", revAdminAuth, async (req, res) => {
  try { if (!isFullAdmin(req)) return res.status(403).json({ error: "solo_admin_general" }); res.set("Cache-Control", "no-store"); res.json({ ok: true, ...(await VTG.diagnostico()) }); }
  catch (e) { console.error("rev/admin/comprobantes-telegram/diagnostico", e); res.status(500).json({ error: "server" }); }
});
// Reenvío VERIFICADO: el admin confirma que revisó el chat y no llegó. Nunca reenvía uno con message_id.
app.post("/rev/admin/comprobantes-telegram/:id/reenviar", revAdminAuth, adminAnyPermission(["socios.compras.write","socios.compras.own.write"]), async (req, res) => {
  try {
    const coleccion = req.body?.coleccion === "renovaciones" ? "renovaciones" : "compras";
    if (req.body?.confirmoNoLlego !== true) return res.status(400).json({ error: "confirmar_no_llego", detail: "Revise el chat del destino y confirme que el comprobante no llegó." });
    const ref = db.collection(coleccion).doc(String(req.params.id || ""));
    const snap = await ref.get(); if (!snap.exists) return res.status(404).json({ error: "no_existe" });
    const d = snap.data() || {};
    const destinoK = VTG.destinoVoucher((d.notificacion && d.notificacion.destino) || d.destino || "sublicuentas", { requerido: false });
    if (!isFullAdmin(req) && destinoK !== adminScopeProfile(req)) return res.status(403).json({ error: "fuera_de_su_destino" });
    if (d.notificacion && d.notificacion.estado === "enviado" && d.notificacion.telegramMessageId) return res.status(409).json({ error: "ya_entregado", entregadoAt: d.notificacion.entregadoAt });
    if (!d.notificacion) await ref.set({ notificacion: { ...VTG.notificacionInicial(ref.id, destinoK), origen: "reenvio_admin_pedido_anterior" } }, { merge: true });
    else await ref.set({ notificacion: { ...d.notificacion, estado: "pendiente", leaseHasta: null } }, { merge: true });
    const actor = `admin:${req.admin?.usuario || req.rev?.usuario || req.rev?.nombre_norm || "panel"}`;
    let foto = null;
    if (d.comprobanteRef && d.imagenUrl) { try { const m = /\/o\/([^?]+)|\.com\/[^/]+\/([^?]+)/.exec(d.imagenUrl); const p = m && decodeURIComponent(m[1] || m[2]); if (p) { const [buf] = await admin.storage().bucket(d.comprobanteRef.bucket).file(p).download(); foto = { buffer: buf, contentType: "image/jpeg", filename: "comprobante.jpg" }; } } catch (_) {} }
    const r = await VTG.entregarVoucher(db, ref.id, { coleccion, actor, forzar: true, foto });
    res.json({ ok: r.estado === "enviado", estado: r.estado, publico: VTG.estadoPublico(r.n), error: r.estado === "enviado" ? "" : (r.n && r.n.lastError) || "" });
  } catch (e) { console.error("rev/admin/comprobantes-telegram reenviar", e); res.status(e.status || 500).json({ error: e.publicError || "server" }); }
});

// ── ADMIN: cambiar estado de un pedido y avisar al socio ──
app.patch("/rev/admin/compras/:id/estado", revAdminAuth, adminAnyPermission(["socios.compras.write","socios.compras.own.write"]), async (req, res) => {
  try {
    const estado = String(req.body?.estado || "").trim().toLowerCase();
    const allowed = new Set(["pendiente", "pago confirmado", "en proceso", "falta información", "entregado", "cancelado"]); // R203 · «pago confirmado» = cobro verificado (SubliPoints)
    if (!allowed.has(estado)) return res.status(400).json({ error: "estado_invalido" });
    const detalle = cleanTg(req.body?.detalle || "", 300);
    const ref = db.collection("compras").doc(String(req.params.id || ""));
    const snap = await ref.get();
    if (!snap.exists) return res.status(404).json({ error: "no_existe" });
    const compra = snap.data() || {};
    if (!isFullAdmin(req) && revNormKey(compra.destino || "sublicuentas") !== adminScopeProfile(req)) {
      return res.status(403).json({ ok:false, error:"fuera_de_ambito" });
    }
    const at = new Date();
    const hist = { estado, detalle, at: at.toISOString(), por: cleanTg(req.admin?.nombre || "Admin", 80) };
    await ref.update({
      estado,
      detalleEstado: detalle,
      estadoUpdatedAt: at,
      estadoHistorial: admin.firestore.FieldValue.arrayUnion(hist),
      updatedAt: at,
      ...(estado === "pago confirmado" && !compra.pagoConfirmadoAt ? { pagoConfirmadoAt: at, pagoConfirmadoPor: hist.por } : {}),
    });

    // R203 · SubliPoints: +2 por servicio al confirmar el cobro (o al entregar, que implica pago verificado). Una sola vez.
    let sublipoints = null;
    try {
      const SP = require("./lib_sublipoints");
      if (estado === "pago confirmado" || estado === "entregado") sublipoints = await SP.otorgar(db, { clave: SP.claveCompra(ref.id), socio: compra.socio, socioNorm: compra.socio_norm || compra.socio, tipo: "venta_nueva", unidades: SP.unidadesCompra(compra), ref: ref.id.slice(-6), detalle: String(compra.servicio || "Pedido").slice(0, 120), fechaEvento: compra.createdAt || compra.ts, por: hist.por });
      else if (estado === "cancelado") sublipoints = await SP.revertir(db, { clave: SP.claveCompra(ref.id), motivo: `Pedido cancelado${detalle ? ` · ${detalle}` : ""}`, por: hist.por });
    } catch (e) { console.error("sublipoints compra", e?.message || e); sublipoints = { ok: false, error: "sublipoints" }; }

    const socioNorm = revNormKey(compra.socio_norm || compra.socio || "");
    const estadoLabel = estado.charAt(0).toUpperCase() + estado.slice(1);
    const texto = `🛒 Pedido ${String(compra.servicio || "").trim() || ref.id.slice(-6)}: ${estadoLabel}${detalle ? ` · ${detalle}` : ""}`;
    if (socioNorm) {
      await db.collection("avisos").add({
        texto, autor:"Sublicuentas", tipo:"pedido_estado", compraId:ref.id,
        destinatarios:[socioNorm], activo:true, createdAt:admin.firestore.FieldValue.serverTimestamp(),
      }).catch(()=>{});
      try {
        const revAliases = socioNorm === "geisell" ? ["geisell", "geissel"] : [socioNorm];
        let revDoc = null;
        for (const alias of revAliases) {
          const revSnap = await db.collection("revendedores").where("nombre_norm", "==", alias).limit(1).get();
          if (!revSnap.empty) { revDoc = revSnap.docs[0]; break; }
        }
        if (revDoc) {
          const rd = revDoc.data() || {};
          const chatId = String(rd.telegramId || "").trim();
          if (chatId) await sendTelegramMessage(chatId, `🛒 *Actualización de pedido*\n${cleanTg(compra.servicio || "Pedido", 120)}\nEstado: *${cleanTg(estadoLabel, 80)}*${detalle ? `\n${detalle}` : ""}`);
        }
      } catch (_) {}
    }
    res.json({ ok:true, id:ref.id, estado, detalleEstado:detalle, estadoUpdatedAt:at.toISOString(), sublipoints });
  } catch(e){console.error("rev/admin/compras estado",e);res.status(500).json({error:"server"})}
});


// ── ADMIN: canal Telegram para Tickets y Avisos de Sublichat ───────────────
// Sublichat guarda la conversación en Firestore, pero el envío se ejecuta en
// este servicio porque aquí ya vive el bot real y BOT_TOKEN. De esta forma no
// hace falta duplicar TELEGRAM_BOT_TOKEN en Vercel y los errores de Telegram
// se devuelven con su causa real por destinatario.
function revTicketDestKey(value = "") {
  const raw = revNormKey(value);
  return raw === "geissel" ? "geisell" : raw;
}
function revTicketAliasSet(data = {}, docId = "") {
  const out = new Set();
  [docId, data.nombre_norm, data.nombre, data.usuario, data.username].forEach((value) => {
    const full = revTicketDestKey(value);
    if (!full) return;
    out.add(full);
    const first = full.split(/\s+/)[0];
    if (first) out.add(first);
  });
  if (out.has("geissel")) out.add("geisell");
  return out;
}
const REV_TICKET_CHAT_IDS = {
  sublicuentas: String(process.env.TELEGRAM_CHAT_ID_SUBLICUENTAS || SUPER_ADMIN || "").trim(),
  relojes: String(process.env.TELEGRAM_CHAT_ID_RELOJES || "").trim(),
  geisell: String(process.env.TELEGRAM_CHAT_ID_GEISELL || process.env.TELEGRAM_CHAT_ID_GEISSEL || "").trim(),
  magdiel: String(process.env.TELEGRAM_CHAT_ID_MAGDIEL || "").trim(),
};
async function revResolveTicketTelegram(role) {
  const wanted = revTicketDestKey(role);
  if (!wanted) return { chatId:"", source:"missing", reason:"destino_invalido" };
  const envId = String(REV_TICKET_CHAT_IDS[wanted] || "").trim();
  if (envId) return { chatId:envId, source:"env" };

  try {
    // Ruta rápida: nombre_norm exacto.
    const aliases = wanted === "geisell" ? ["geisell", "geissel"] : [wanted];
    for (const alias of aliases) {
      const snap = await db.collection("revendedores").where("nombre_norm", "==", alias).limit(2).get();
      for (const doc of snap.docs) {
        const d = doc.data() || {};
        if (d.activo === false) continue;
        const tg = String(d.telegramId || d.telegramID || d.telegramChatId || d.chatId || d.userId || "").trim();
        if (tg) return { chatId:tg, source:"revendedores", revendedorId:doc.id };
      }
    }

    // Compatibilidad con documentos viejos o nombres completos: acepta el
    // nombre completo y también su primer nombre (Heber, Jimena, etc.).
    const snap = await db.collection("revendedores").get();
    let found = null;
    snap.forEach((doc) => {
      if (found) return;
      const d = doc.data() || {};
      if (d.activo === false) return;
      const aliasesDoc = revTicketAliasSet(d, doc.id);
      if (!aliasesDoc.has(wanted)) return;
      const tg = String(d.telegramId || d.telegramID || d.telegramChatId || d.chatId || d.userId || "").trim();
      if (tg) found = { chatId:tg, source:"revendedores", revendedorId:doc.id };
    });
    return found || { chatId:"", source:"missing", reason:"chat_id_missing" };
  } catch (e) {
    console.error("revResolveTicketTelegram", wanted, e?.message || e);
    return { chatId:"", source:"error", reason:"resolver_error", error:String(e?.message || e).slice(0,240) };
  }
}
function revTelegramFriendlyError(err) {
  const description = String(err?.response?.body?.description || err?.message || err || "Error desconocido de Telegram").trim();
  const lower = description.toLowerCase();
  let code = "telegram_error";
  if (lower.includes("unauthorized")) code = "bot_token_invalido";
  else if (lower.includes("bot was blocked") || lower.includes("blocked by the user")) code = "bot_bloqueado";
  else if (lower.includes("chat not found")) code = "chat_no_encontrado";
  else if (lower.includes("user is deactivated")) code = "usuario_desactivado";
  else if (lower.includes("forbidden")) code = "telegram_prohibido";
  else if (lower.includes("wrong file identifier") || lower.includes("failed to get http url content")) code = "imagen_no_disponible";
  return { code, error:description.slice(0,300) };
}
async function revSendTicketTelegramOne(chatId, payload = {}) {
  const text = String(payload.text || "").slice(0, 3900);
  const imageUrl = String(payload.imageUrl || "").trim();
  const replyMarkup = payload.replyMarkup && typeof payload.replyMarkup === "object" ? payload.replyMarkup : undefined;
  const opts = { parse_mode:"HTML", ...(replyMarkup ? { reply_markup:replyMarkup } : {}) };
  try {
    if (imageUrl) {
      const msg = await bot.sendPhoto(chatId, imageUrl, { ...opts, caption:text.slice(0,1000) });
      return { ok:true, messageId:Number(msg?.message_id || 0) };
    }
    const msg = await bot.sendMessage(chatId, text, { ...opts, disable_web_page_preview:true });
    return { ok:true, messageId:Number(msg?.message_id || 0) };
  } catch (e) {
    if (!isUnauthorizedTelegramError(e)) throw e;
    const job = await enqueueTelegramJob({
      type:imageUrl?"photo":"message", chatId, photoUrl:imageUrl, text, parseMode:"HTML",
      replyMarkup, source:"sublichat-ticket-aviso", reference:String(payload.reference||""),
    });
    return { ok:true, queued:true, jobId:job.id, via:"bot_principal" };
  }
}

app.post("/rev/admin/tickets-telegram", revAdminAuth, adminPermission("tickets.bridge"), async (req, res) => {
  try {
    const body = req.body || {};
    const destinos = [...new Set((Array.isArray(body.destinos) ? body.destinos : [body.destino])
      .map(revTicketDestKey).filter(Boolean))].slice(0,100);
    if (!destinos.length) return res.status(400).json({ ok:false, error:"sin_destinatarios" });
    const text = String(body.text || "").trim();
    if (!text) return res.status(400).json({ ok:false, error:"sin_texto" });

    // Lotes de 5 en paralelo (mismo criterio que las promociones): con muchos
    // socios el envío secuencial pasaba de los 10 s y Vercel cortaba la petición.
    const enviarRol = async (role) => {
      const resolved = await revResolveTicketTelegram(role);
      if (!resolved.chatId) {
        return { ok:false, skipped:true, reason:resolved.reason || "chat_id_missing", error:resolved.error || "", roles:[role], source:resolved.source };
      }
      try {
        const sent = await revSendTicketTelegramOne(resolved.chatId, body);
        return { ...sent, chatId:String(resolved.chatId), roles:[role], source:resolved.source };
      } catch (e) {
        const detail = revTelegramFriendlyError(e);
        return { ok:false, reason:detail.code, error:detail.error, roles:[role], source:resolved.source };
      }
    };
    const results = [];
    for (let i = 0; i < destinos.length; i += 5) {
      results.push(...(await Promise.all(destinos.slice(i, i + 5).map(enviarRol))));
    }
    const deliveredRoles = destinos.filter(role => results.some(r => r.ok && (r.roles || []).includes(role)));
    const failedRoles = destinos.filter(role => !deliveredRoles.includes(role));
    return res.json({
      ok: failedRoles.length === 0,
      partial: deliveredRoles.length > 0 && failedRoles.length > 0,
      results,
      deliveredRoles,
      failedRoles,
    });
  } catch (e) {
    console.error("rev/admin/tickets-telegram", e);
    return res.status(500).json({ ok:false, error:"telegram_bridge_error", detail:String(e?.message || e).slice(0,240) });
  }
});

// ── Oct-2026 · Entregas publicadas por renglón, Buzón de dos vías, vínculo de Telegram e historial anterior ──
// R158 · Excel de finanzas (con hojas por plataforma). ÚNICO generador: el mismo de "📤 Excel por rango" del Bot TG.
// Lo pide la Web (Sublichat HQ · /api/finanzas → accion exportar_excel_finanzas) con el token de administración.
app.get("/rev/admin/finanzas/excel", revAdminAuth, async (req, res) => {
  try {
    if (!isFullAdmin(req)) return res.status(403).json({ ok: false, error: "sin_permiso" });
    const re = /^\d{4}-\d{2}-\d{2}$/;
    const desde = String(req.query.desde || ""), hasta = String(req.query.hasta || "");
    if (!re.test(desde) || !re.test(hasta) || desde > hasta) return res.status(400).json({ ok: false, error: "rango_invalido" });
    if ((Date.parse(`${hasta}T12:00:00Z`) - Date.parse(`${desde}T12:00:00Z`)) / 86400000 > 731) return res.status(400).json({ ok: false, error: "rango_muy_largo" });
    const P = require("./lib_finanzas_plataformas");
    const dmy = (y) => `${y.slice(8, 10)}/${y.slice(5, 7)}/${y.slice(0, 4)}`;
    const raw = await require("./index_10_reportes_excel").generarReporteExcelPorRango(dmy(desde), dmy(hasta));
    const buf = Buffer.isBuffer(raw) ? raw : Buffer.from(raw || []);
    res.set("Cache-Control", "no-store");
    return res.json({ ok: true, filename: P.nombreArchivo(desde, hasta), version: P.VERSION, bytes: buf.length, base64: buf.toString("base64") });
  } catch (e) {
    console.error("finanzas_excel", e?.message || e);
    return res.status(500).json({ ok: false, error: "no_se_pudo_generar" });
  }
});

require("./rev_entregas_api").registrar(app, {
  db, bot, revAuth, revAdminAuth, adminAnyPermission, isFullAdmin, adminScopeProfile, revLiveProfile, revSocioAliases, revNormKey,
  revFiltrarClientePorAliases, destinoInfo, getDestinoChatIds, allClientDocs: () => revAllClientDocsCached(30000),
  invalidarSocio: (id) => _revLiveCache.delete(String(id)),
});

// ── ADMIN: "ver como" ──
app.post("/rev/admin/impersonate", revAdminAuth, adminPermission("admin.impersonate"), async (req, res) => {
  try {
    const id = (req.body.id || "").trim();
    const nombre_norm = (req.body.nombre_norm || "").trim().toLowerCase();
    let doc = null;

    // 1) por ID de documento (siempre confiable)
    if (id) {
      const d = await db.collection("revendedores").doc(id).get();
      if (d.exists) doc = d;
    }
    // 2) respaldo: por nombre_norm
    if (!doc && nombre_norm) {
      const aliases = [nombre_norm];
      if (nombre_norm === "geisell") aliases.push("geissel");
      const snaps = await Promise.all(aliases.map(alias =>
        db.collection("revendedores").where("nombre_norm", "==", alias).limit(1).get()
      ));
      const snap = snaps.find(s => !s.empty);
      if (snap) doc = snap.docs[0];
    }
    if (!doc) return res.status(404).json({ error: "no_existe" });

    const data = doc.data();
    const rawNorm = normVendedor(data.nombre_norm || data.nombre || doc.id);
    const nn = rawNorm === "geissel" ? "geisell" : rawNorm;
    const nombre = nn === "geisell" ? "Geisell" : (data.nombre || doc.id);
    const capabilities = capacidadesRevendedor({ id: doc.id, ...data, nombre_norm: nn });
    const soloCatalogo = !capabilities.canBuy;
    const sinCompras = !capabilities.canBuy;
    const tarifaId = String(data.tarifaId || data.tarifa_id || "general");
    const token = jwt.sign({ id: doc.id, nombre, nombre_norm: nn, soloCatalogo, sinCompras, capabilities, tarifaId, nombreMostrar:data.nombreMostrar||"", etiquetaRenovacion:data.etiquetaRenovacion||"" }, JWT_SECRET, { expiresIn: "6h" });
    res.json({ token, nombre, nombre_norm: nn, soloCatalogo, sinCompras, capabilities, tarifaId, priceTier:tarifaId, nombreMostrar:data.nombreMostrar||"", etiquetaRenovacion:data.etiquetaRenovacion||"" });
  } catch (e) { console.error("rev/impersonate", e); res.status(500).json({ error: "server" }); }
});

// ── IA: generar mensajes (Gemini o Claude según la llave configurada) ──
async function aiGenerate(prompt) {
  const sys = "Sos un asistente de ventas para un negocio de suscripciones digitales en Honduras (Sublicuentas). Escribí en español hondureño, trato de usted, claro, cálido y profesional. Nunca inventes precios. Devolvé solo el mensaje pedido, sin explicaciones.";
  if (typeof fetch !== "function") throw new Error("fetch_no_disponible_node_viejo");

  if (process.env.GEMINI_API_KEY) {
    const modelos = ["gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-flash-latest"];
    let ultimoError = "gemini_sin_respuesta";
    for (const m of modelos) {
      try {
        const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${m}:generateContent?key=${process.env.GEMINI_API_KEY}`, {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ contents: [{ parts: [{ text: sys + "\n\n" + prompt }] }] })
        });
        const j = await r.json();
        const t = j?.candidates?.[0]?.content?.parts?.[0]?.text;
        if (t) return t.trim();
        ultimoError = (j?.error?.message || "sin_texto") + " [" + m + "]";
      } catch (err) { ultimoError = err.message + " [" + m + "]"; }
    }
    throw new Error(ultimoError);
  }

  if (process.env.ANTHROPIC_API_KEY) {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-api-key": process.env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: "claude-haiku-4-5-20251001", max_tokens: 600, system: sys, messages: [{ role: "user", content: prompt }] })
    });
    const j = await r.json();
    const t = j?.content?.[0]?.text;
    if (t) return t.trim();
    throw new Error(j?.error?.message || "claude_sin_respuesta");
  }

  throw new Error("no_api_key");
}

app.post("/rev/ask", revAuth, async (req, res) => {
  try {
    const live = await revLiveProfile(req.rev);
    if (!revCap(live, "canUseAI", true)) return res.status(403).json({ error: "sin_permiso_ia" });
    const prompt = (req.body.prompt || "").toString().slice(0, 4000);
    if (!prompt) return res.status(400).json({ error: "falta_prompt" });
    const text = await aiGenerate(prompt);
    res.json({ text });
  } catch (e) {
    console.error("rev/ask", e.message);
    res.status(500).json({ error: "ia_error", detail: e.message });
  }
});

// ── Panel admin (precios / vendedores / clientes) — para Sublichat HQ ──
require("./index_12_admin_panel")(app);
require("./index_13_gamificacion")(app);

// R161 · Tareas de arranque del panel (también las llama index.js cuando la Panel API va unificada).
function iniciarTareasPanel() {
  if (iniciarTareasPanel.hecho) return; iniciarTareasPanel.hecho = true;
  r121RellenarNombresCompraSocio();
  // R195 · reintentos de comprobantes no entregados (solo errores definitivos de Telegram, con espera creciente)
  const barrer = () => VTG.barrerPendientes(db).catch((e) => console.error("R195 barrer comprobantes", e?.message || e));
  setTimeout(barrer, 30000); setInterval(barrer, 120000).unref?.();
  try { require("./index_31_finanzas_libro").iniciarCosteoAutomatico(); } catch (e) { console.error("R137 costeo", e?.message || e); } // R137
}
// R161 · `node server_api.js` (servicio aparte, como hasta hoy) escucha el puerto. Si index.js lo carga con
// UNIFICAR_PANEL_API=1, solo se exporta la app y la monta index_08_api.js: un único app.listen(PORT).
if (require.main === module) {
  app.listen(PORT, () => { console.log("🌐 Panel API (revendedores) activa en puerto", PORT); iniciarTareasPanel(); });
}
module.exports = { app, iniciarTareasPanel, PANEL_API_VERSION };
