# SubliPoints · Billetera · Tienda — Fase 0 (auditoría) y Fase 1 (SubliPoints)
Edición 23/11/2026 · R203

## Fase 0 · Lo que existe hoy
| Tema | Dónde está hoy | Hallazgo |
|---|---|---|
| Pedidos del socio | bot `server_api.js` → `POST /rev/compra`, colección `compras` | Estados: pendiente → en proceso → falta información → entregado / cancelado. **No había paso de “pago recibido”.** Idempotencia por `requestId` ya existe. Destino SUBLICUENTAS o RELOJES. |
| Cambio de estado del pedido | `PATCH /rev/admin/compras/:id/estado` (se usa desde Sublichat › Revendedores) | Avisa al socio por Buzón y Telegram. |
| Renovaciones | `renovaciones` (comprobante con foto desde el Panel o `/rev/renovar-cliente` directo) | Quedan `renovado: true` **sin validar el dinero**. |
| Recompensas actuales | `index_13_gamificacion.js` + `recompensas_socios` | Niveles por ventas TOTALES (1/10/26), 9 premios distintos, 1 por nivel en toda la vida. |
| Billetera / saldo | — | No existe. |
| Descuentos | `lib_compra_socios.js` | Solo descuento por combo (L10 por unidad, máx L40). |
| Finanzas | `index_31_finanzas_libro.js`, `finanzas_movimientos` | Libro por banco; no se toca en Fase 1. |
| Entregas | `rev_entregas_api.js` | Ya son manuales (fichas publicadas por admin). |

## Decisiones del dueño (23/11/2026)
1. Renovación cobrada = el admin toca **«Confirmar pago»** en el comprobante.
2. Venta nueva cobrada = nuevo estado **«Pago confirmado»** (también suma si se marca «Entregado» sin pasar por él; nunca dos veces).
3. Billetera con **dos saldos separados**: Sublicuentas y Relojes (Fase 3).
4. SubliPoints empieza **desde que se publique** (la fecha queda guardada la primera vez que corre).
5. Productos elegibles para Gift Card / descuento de billetera: **todos menos Netflix** (Fases 2 y 4).

## Fase 1 · Entregado
- Motor `lib_sublipoints.js`: +2 por servicio en venta nueva, +1 por renovación, niveles mensuales (0–9 / 10–24 / 25–49 / 50+), mes en hora de Honduras, **una clave por evento** (no se duplica con reintentos, doble clic ni Telegram), reverso compensatorio al cancelar/anular, sin retroactivo.
- Colecciones nuevas (se crean solas, sin migración): `sublipoints_movimientos` (solo se agregan registros) y `sublipoints_config/general` (`inicio`, `excluidos`).
- Rutas: `GET /rev/sublipoints` (el socio ve solo lo suyo), `GET /rev/admin/sublipoints?mes=`, `POST /rev/admin/comprobantes/:id/pago` (confirmar/anular), estado «pago confirmado» en pedidos.
- Pantallas: Inicio (puntos, nivel, barra y lo que falta), Recompensas (los 3 niveles y meses anteriores), Panel Dios › Comprobantes (Confirmar/Anular pago + ranking del mes), Sublichat › Revendedores (estado «Pago confirmado» y aviso de puntos).
- No se tocó: precios, Control Maestro, Finanzas, premios ya entregados, entregas.

## Pruebas Fase 1
- Bot: 9 pruebas nuevas (QA-02, QA-03, QA-04, QA-05, caso del PDF 8+16=32 Leyenda, reversos, sin retroactivo, hora de Honduras). Suite completa 291/291.
- Panel de Socios: 17/17 de siempre + vistas 390/1440 con SubliPoints en Inicio/Recompensas y botón de confirmar en Panel Dios.
- Sublichat HQ: sin fallas nuevas (las 16 de siempre).
- Simulador con datos ficticios: no son pruebas de producción.

## Pendiente para las siguientes fases
- Fase 2: cambiar el catálogo a los 9 premios nuevos (1 por mes, del nivel más alto) y Gift Card L100. Hasta entonces, la sección vieja de premios sigue debajo.
- Fase 3: billetera (dos saldos), recargas con aprobación.
- Fase 4: pagar con saldo, descuento ≤5% (sin Netflix) con margen mínimo.
- Pregunta abierta: ¿Sublicuentas y Relojes (los dueños) también ganan puntos? Hoy sí; se apagan poniéndolos en `excluidos`.

## Rollback
Bot: volver a subir `server_api.js` del commit 148e2db y borrar `lib_sublipoints.js` (los movimientos guardados se quedan, no estorban). Panel: `index.html`, `service-worker.js`, `bloques-3d.css` del commit 0784361 y borrar `sublipoints.js`. HQ: `revendedores-admin.js` e `index.html` del commit 114cfd9.
